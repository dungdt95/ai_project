# Chương 5: Bạch Chỉ Quyết

Sáng sớm hôm sau, Lục Trầm bị đánh thức bởi một tiếng gào trong đầu.

*"Dậy! Mặt trời lên cao ba sào rồi mà còn ngủ! Bản tọa năm xưa mỗi canh năm đã…"*

— Ngài vừa nhớ ra năm xưa?

*"…Không. Nhưng chắc chắn là như vậy."*

Hắn ngồi dậy, xoa gáy. Cả người đau nhức vì nằm trên nền đá, trong bụng trống rỗng, khẩu phần cuối cùng của hắn chỉ có nửa miếng đậu phụ Vương đại nương nhét vào tay mấy hôm trước. Hắn ăn nốt, nhai rất chậm, như thể đang ăn thứ gì đó thiêng liêng. Ăn xong, hắn rửa mặt bằng nước đọng trên lá, rồi ngồi xếp bằng đối diện mảnh giấy đặt trên một tảng đá bằng.

— Ngài nói ta là trang trắng. — Hắn mở lời. — Vậy bây giờ ta nên làm gì?

*"Trước hết, quỳ xuống…"*

— Lão Chỉ.

*"…Được, được. Sư phụ không câu nệ lễ nghi. Cứ để đó, dập đầu bù sau."*

Mặt giấy sáng lên, từng dòng chữ hiện ra. Lần này nét bút nghiêm chỉnh hơn hẳn, như đang dạy học thật sự. Lão Chỉ giải thích rằng thiên hạ tu luyện, bất kể tông môn nào, đều bắt đầu từ cùng một cửa: *dẫn khí nhập thể*. Linh khí giữa trời đất phiêu tán khắp nơi, người có linh căn thì kinh mạch tự mở một khe nhỏ, hút khí vào đan điền, tích tụ thành linh lực. Khe nhỏ ấy là do Thiên Thư ghi sẵn: sinh ra có căn cốt gì thì mở được khe ấy, như cửa có sẵn then, chỉ cần người có chìa là mở.

*"Ngươi không có chìa."* Lão Chỉ viết. *"Nhưng đã đến đây thì thử xem. Bản tọa nhớ một môn công pháp bình thường nhất thiên hạ, gọi là* Thái Thanh Dẫn Khí Quyết*. Ngay cả đứa trẻ lên năm ở tông môn nhỏ cũng học được. Ngươi ngồi xuống, theo khẩu quyết mà hô hấp."*

— Nhỡ không được?

*"Không được thì thôi. Nhưng bản tọa tin chắc ngươi sẽ… khụ… cũng không đến nỗi nào."*

Lục Trầm nhìn nó thêm một lúc, rồi nhắm mắt, theo khẩu quyết mà thở.

Hít vào ba nhịp, giữ một nhịp, thở ra năm nhịp. Ý niệm theo hơi thở chìm xuống bụng dưới, quan tưởng một đóa sen xanh nhạt đang nở trong đan điền. Mặt trời xuyên qua khe dây leo, rọi lên mí mắt hắn một vệt ấm. Gió núi thổi qua. Chim hót.

Một chén trà trôi qua.

Hai chén trà.

Nửa nén hương.

Hắn mở mắt.

— Ta có cảm giác như đang ngồi trong sân, nhìn người ta ăn cơm. — Hắn nói thẳng.

*"…Ngươi không cảm nhận được linh khí sao?"*

— Cảm nhận được. Nó ở đó. Nhạt nhạt, mát mát, trôi qua trôi lại. Nhưng nó không vào.

*"Làm sao nó không vào?"*

— Nó đến trước cửa, nhìn ta, rồi đi vòng qua.

Mảnh giấy im lặng.

*"…Thử lại."*

Hắn thử lại. Lần này cố gắng hơn, thở sâu hơn, ép ý niệm dồn xuống đan điền mạnh hơn. Hắn thử bốn lần, mỗi lần đổi một tư thế, thậm chí còn thử trụ một chân trên tảng đá theo lời Lão Chỉ nói là "thế Kim Kê Độc Lập có thể thông kinh mạch". Kết quả là hắn ngã nhào xuống đất, đập mông, bị một con kiến bò lên mắt cá chân.

*"Không thể nào!"* Lão Chỉ rống lên. *"Dẫn Khí Quyết đến cả heo cũng tu được!"*

— Ta không phải heo.

*"Đúng, heo còn có tên trong Thiên Thư!"*

Lục Trầm vừa phủi đất trên quần vừa nghiêng đầu.

— Thế là ngài vừa thừa nhận, heo hơn ta ở chỗ này.

*"Bản tọa… bản tọa không có ý đó! Ý bản tọa là… khụ, đây là vấn đề căn bản."*

Mảnh giấy rung lên, rồi lặng đi rất lâu. Khi nó viết tiếp, giọng điệu đã bình thản lại, thậm chí mang một chút trầm ngâm như người nhớ ra điều gì:

*"Đúng rồi. Ngươi không có tên trong sổ. Thiên Đạo ghi sổ cho mỗi người một khe cửa. Ngươi không có sổ, nên không có cửa. Mọi công pháp thiên hạ đều dạy người ta cách đi qua cánh cửa đó. Cho nên với ngươi, tất cả đều vô dụng."*

— Vậy là hết?

*"Không."* Lão Chỉ viết. *"Không có cửa thì… tự mở một cánh."*

---

Lão Chỉ dạy hắn một câu khẩu quyết ngắn.

Chỉ có tám chữ:

*Thiên vô thư, ngã tự thư. Bạch chỉ vô cương.*

Dịch ra là: *Trời không viết, ta tự viết. Giấy trắng không có ranh giới.*

— Đây là gì? — Lục Trầm hỏi.

*"Tên là* Bạch Chỉ Quyết*."* Giọng Lão Chỉ có chút ngập ngừng, như thể chính nó cũng ngạc nhiên khi những chữ ấy tự tuôn ra. *"Bản tọa không nhớ nó từ đâu đến. Chỉ biết, khi ngươi cầm ta lên, nó tự hiện trong đầu, rõ như chữ khắc trên đá. Có lẽ vạn năm trước, bản tọa chính là chuẩn bị cho ngày hôm nay."*

— Lại nói như tiên đoán.

*"Là thật! Đừng cười!"*

— Ta chưa cười.

*"Rồi cũng cười!"*

Hắn hắng giọng, nghiêm mặt trở lại.

Theo lời Lão Chỉ, công pháp bình thường dẫn linh khí qua *kinh mạch có sẵn*. Bạch Chỉ Quyết thì ngược lại: người tu tự *viết* một con đường lên thân thể mình, nét bút này nối nét bút kia, mỗi nét là một đoạn kinh mạch mới. Linh khí không còn đi theo "sổ sách" của Thiên Đạo, mà đi theo chính những nét chữ hắn tự viết. Kinh mạch của người thường có hàng trăm điểm, mà Bạch Chỉ Quyết đòi hỏi hắn *tự tay vẽ lại từng điểm*.

*"Có ba quy tắc."* Mảnh giấy viết, từng dòng ngay ngắn.

*"Một: không sao chép. Ngươi không thể chép con đường của người khác. Mỗi nét, ngươi phải hiểu nó, rồi mới viết được. Nét nào không hiểu mà cố viết, nét đó là vết sẹo."*

*"Hai: không xóa. Viết rồi là viết rồi. Giấy trắng chỉ có một lần để viết."*

*"Ba: ban đầu rất chậm. Người thường mở một khiếu huyệt trong nửa canh giờ. Ngươi, có lẽ là nửa ngày. Đổi lại, con đường của ngươi không có bình cảnh định sẵn, vì chẳng ai viết sẵn nó cả."*

Lục Trầm nghe xong, im lặng suy nghĩ một lúc.

— Nghe như một món hàng rất đắt, bán cho người không có tiền.

*"Cũng có thể nói vậy."* Lão Chỉ thở dài, nghe thật lòng. *"Còn một chuyện bản tọa phải nói trước. Việc này… sẽ rất đau."*

— Đau thế nào?

*"Như có người cầm đục khắc chữ lên xương của ngươi."*

— Nghe không dễ chịu.

*"Vì nó đúng là như vậy."*

— …Được. — Lục Trầm đáp.

*"Ngươi không hỏi thêm?"*

— Ta có ba lựa chọn: không tu, bị hạc giấy tìm thấy rồi chết. Tu theo cách thường, không tu được rồi chết. Hoặc tu cái này, đau rồi có thể sống. — Hắn nói. — Câu hỏi này không khó.

*"Ngươi thật sự mới mười lăm tuổi à?"*

— Là mười lăm tuổi và vừa mất cái quán.

Lão Chỉ không nói gì nữa.

---

Nét đầu tiên là nét ngang.

Lão Chỉ chỉ cho hắn: nhắm mắt, quan tưởng tay phải cầm một cây bút vô hình, đầu bút là một điểm sáng nhỏ. Điểm sáng ấy chạm vào đan điền, rồi kéo từ rốn sang phải, một đường thẳng, dài chừng ba tấc. Linh khí quanh động được "mời" vào đúng nét bút ấy, lấp đầy nó như mực đổ vào rãnh khắc.

Lục Trầm cầm bút vô hình. Hắn chạm đầu bút vào đan điền.

Đau.

Không phải kiểu đau của ngã sưng đầu gối, hay đau của bị roi quất. Đó là một cơn đau nằm *bên trong* xương cốt, lạnh buốt, sắc nhọn, đúng như tiếng đục nhỏ gõ lên từng đốt, từng đốt, rồi khắc xuống. Hắn cắn chặt răng, môi bật máu, hai tay bấu xuống nền đá đến móng tay nứt ra.

Nét ngang đầu tiên kéo dài ba tấc, mất trọn một canh giờ.

Khi bút vô hình rời khỏi cuối nét, Lục Trầm đổ vật ra đất, thở hổn hển như vừa chạy qua cả ngọn núi. Mồ hôi thấm ướt từ đầu đến chân, từng thớ cơ trong người cứ giật liên hồi.

*"Được rồi, được rồi."* Giọng Lão Chỉ cuống quýt, không còn chút bộ dạng cao nhân. *"Đừng cố nữa! Nghỉ đi! Bản tọa không có ý bắt ngươi chết!"*

— Mới… nét đầu. — Hắn thở. — Còn bao nhiêu nét nữa?

*"…Một trăm lẻ tám, nét sơ khởi. Mở linh khiếu đầu tiên."*

— Một trăm lẻ tám.

*"Đúng."*

— Ngài có thể nói thẳng một chút ngay từ đầu.

*"Ngươi cũng đâu có hỏi!"*

Lục Trầm nằm ngửa nhìn trần động, khóe miệng giật giật. Hắn bỗng phát hiện, trong cơn đau tê người, cái miệng vẫn có sức để châm chọc. Hắn nghĩ lão Hoàng nếu biết hẳn rất vui: thằng nhóc này, cái gì cũng chết được trừ cái mồm.

Hắn cắn răng, ngồi dậy.

— Nghỉ thêm nửa chén trà. Rồi nét thứ hai.

---

Ba ngày ba đêm.

Hắn không biết mình đã sống sót thế nào. Ban ngày ngồi viết trong động, ban đêm hái quả dại, uống nước suối, dùng cành thông gãy làm gậy chống. Có hai lần tiếng chó săn vọng lại từ phía sườn bên kia núi, và một lần Chỉ Hạc lại bay qua, nhưng lần này Lão Chỉ đã dạy hắn cách thu liễm khí tức, dù chỉ thô sơ, hắn vẫn ngồi nín thở sau tảng đá mà đợi bầy hạc bay đi.

Một trăm lẻ tám nét. Mỗi nét như một tấc vết khắc.

Nét thứ ba mươi bảy, hắn viết sai. Nét ấy chưa hiểu mà ép viết, cả cánh tay phải của hắn bỗng tê dại, trên da hiện lên một vệt đỏ thẫm, rất giống vết bỏng. Hắn mất cả nửa ngày để nằm thở. Lão Chỉ không mắng, chỉ lẳng lặng viết một dòng: *"Nét nào chưa hiểu, thà bỏ trống. Giấy trắng không sợ trống."*

Từ đó, hắn không dám vội nữa.

Nét thứ sáu mươi, hắn thấy một thứ rất lạ. Mỗi khi bút vô hình rời khỏi giấy, linh khí giữa trời đất cũng khẽ nghiêng về phía hắn, rất nhẹ, như đàn cá chầm chậm bơi vào dòng nước mới được đào. Không phải hấp thu. Mà là *được mời*.

Nét thứ chín mươi, hắn bắt đầu quen với đau. Tức là cơn đau vẫn còn, nhưng hắn biết nó sẽ đến lúc nào và rút đi lúc nào, như một người khách khó tính nhưng đúng giờ.

Đến nét cuối cùng, hoàng hôn hôm thứ ba đã nhuộm đỏ cả cửa động.

Lục Trầm ngồi thẳng người, nhắm mắt. Trong tay phải vô hình, bút đang kéo nét phẩy sau cùng, một nét cong nhẹ, từ vai phải xuống cổ tay. Khi đầu bút sắp dứt, hắn bỗng cảm thấy một luồng khí lạnh, thuần khiết như sương sớm, xoáy vào từ khắp bốn phương tám hướng.

Không còn đi vòng nữa.

Chúng chảy vào.

Linh khí nhập vào từng nét, như nước tràn đầy rãnh, bắt đầu chuyển động theo con đường hắn đã viết ra. Đan điền của hắn, trống rỗng bấy lâu, bỗng ấm lên, dần dần có một điểm sáng nhỏ như hạt gạo xoay tròn.

Trong lòng bàn tay mảnh giấy rung lên.

*"Xong rồi."* Giọng Lão Chỉ vang trong đầu hắn, khẽ khàng, dường như chính nó cũng không dám tin. *"Luyện Khí… tầng một."*

Lục Trầm mở mắt.

Cả sơn động tối đi một chút, rồi sáng lên. Không phải thật sự sáng lên, mà là hắn nhìn thấy rõ hơn: từng sợi gân lá trên dây leo, từng hạt bụi bay trong luồng nắng cuối ngày, thậm chí cả vệt rêu trên vách đá cách xa năm trượng. Hắn giơ tay lên nhìn.

Tay phải trần của hắn, từ cổ tay đến khuỷu, đang phát sáng.

Không phải ánh sáng của linh lực thông thường, mà là những nét chữ. Chằng chịt như mạng nhện, vàng nhạt, nổi lên ngay dưới da, hàng trăm nét xếp thành một hình vẽ phức tạp mà hắn không hiểu. Chúng sáng lên như đang thở, hơi thở vàng, rồi từng nét một mờ dần, tắt lịm, không để lại bất kỳ dấu vết nào trên da.

Đến lúc cánh tay lại trở thành một cánh tay bình thường, hắn mới khẽ gọi:

— Lão Chỉ?

Không có trả lời.

— Lão Chỉ?

*"…Ngươi vừa thấy gì?"* Giọng nói của mảnh giấy rất khác. Không phải khoác lác, cũng không phải nhát gan. Nó dè dặt, nghiêm chỉnh, như người đang cố nén một nỗi sợ.

— Chữ. Chữ vàng trên tay ta. Rồi nó biến mất.

*"Chữ gì?"*

— Ta không đọc được. Nhưng ở cuối, có ba chữ nằm riêng, lớn hơn các chữ khác. — Hắn nhắm mắt, nhớ lại. — Là cổ triện. Ta chưa từng học, nhưng không hiểu sao lại biết nghĩa. Ba chữ ấy là: *Vị chung quyển.*

*Chưa hết quyển.*

Trong động rất yên tĩnh. Mãi sau mới có hàng chữ vàng hiện lên chậm rãi trên mặt giấy, nét bút run run:

*"Bản tọa chỉ dạy ngươi viết một trăm lẻ tám nét. Chưa từng nói ngươi viết thành chữ. Ba chữ đó… không phải thứ bản tọa dạy."*

— Vậy là ai?

*"…Không biết."* Lão Chỉ đáp rất nhanh, quá nhanh, như người vội đóng một cánh cửa. *"Có lẽ là hiện tượng thường gặp lần đầu. Ngươi đừng nghĩ nhiều. Hôm nay đã đủ rồi, ngủ đi."*

Lục Trầm không hỏi thêm. Hắn đã học được từ lão Hoàng một điều: khi một người trả lời quá nhanh, tức là người ấy đang giấu một điều quan trọng.

Hắn nằm xuống, gối đầu lên cánh tay phải, nơi những nét chữ vừa tắt. Trong bóng tối, hắn nghe thấy mảnh giấy ấm áp áp sát bên ngực, khẽ rung lên một nhịp, rồi lại một nhịp, như tim của một người đang bất an.

*"Giấy trắng… có người viết trước."* Lão Chỉ thì thầm, tưởng hắn đã ngủ, nhưng hắn nghe thấy tất cả.

*"Vậy thì tờ giấy trắng này, rốt cuộc là của ai?"*
