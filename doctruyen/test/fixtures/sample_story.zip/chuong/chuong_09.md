# Chương 9: Dòng Chữ Bị Nhòe

Gã chủ quán trọ không dám giữ họ qua đêm.

Y nói rất khéo, khéo đến mức Đa Đa phải khâm phục: bảo rằng phòng đã đầy, mà cả tầng hai trống không. Ba người đành rời Thập Lý Đình lúc canh hai, đi dọc quan đạo chừng nửa dặm rồi rẽ xuống một bờ suối nhỏ. Dưới bóng mấy cây liễu, nước chảy róc rách, trăng treo lưng chừng trời, ánh trăng rải một lớp bạc mỏng lên mặt đá cuội.

Thanh Dao đi phía trước, lưng thẳng như cây kiếm của nàng. Lục Trầm đi giữa. Đa Đa vác hai bọc hành lý đi cuối cùng, vừa đi vừa than vãn rằng gã chưa từng ngủ ngoài trời.

— Ngươi sống ở đâu từ nhỏ? — Thanh Dao hỏi, không quay đầu.

— Tại hạ sống ở Lâm Giang, trong một tòa nhà có tám mươi mốt gian phòng.

— Tám mươi mốt? Vì sao phải nhiều như thế?

— Vì… vì có tiền.

— À. — Nàng gật đầu. — Phòng của ta chỉ có một. Có một giường, một bàn, một giá kiếm.

— Ăn thế nào?

— Có người đem tới.

— Cô nương tự nấu bao giờ chưa?

— Chưa. — Nàng đáp tỉnh bơ. — Nhưng chắc không khó. Chỉ là nước, lửa, và đồ ăn. Ba thứ, cộng lại.

Lục Trầm nghe vậy bèn khẽ nhướng mày. Hắn có linh cảm chẳng lành về số phận bữa tối.

---

Nửa nén hương sau, bên bờ suối bốc lên một mùi khét lạ lùng.

Thanh Dao ngồi xổm trước đống lửa, hai tay giữ một chiếc nồi nhỏ mà Đa Đa mua ở quán. Trong nồi đựng một thứ có dáng vẻ của cháo, có màu của than, và có mùi của một vụ hỏa hoạn nhỏ. Mặt nàng nghiêm trọng như đang đối diện một tử địch.

— Nước cháy được sao? — Nàng hỏi, giọng đầy hoài nghi.

— Cô nương, nước không cháy. — Đa Đa cố nén bi thương. — Là gạo cháy.

— Ta cho nước vào rồi.

— Cô nương cho nước rồi… đun cạn.

— Ta nghĩ nước cạn thì cơm chín.

— Đúng, nhưng nếu cô nương đun thêm một nén hương, cơm sẽ thành than.

— Một nén hương là bao lâu?

Đa Đa bật khóc.

Lục Trầm nhận lấy chiếc nồi từ tay nàng với vẻ mặt của một vị lang trung trước một bệnh nhân vô phương cứu chữa. Hắn đổ thứ ấy xuống suối, rửa nồi, nhóm lại lửa. Trong lúc đó, thiếu nữ ngồi lặng thinh, không hề xấu hổ, chỉ lẳng lặng nhìn từng động tác của hắn, như đang học bí kíp thượng thừa.

— Ngươi làm thế nào? — Nàng hỏi.

— Nước trước, gạo sau. Lửa nhỏ. Chờ.

— Chờ bao lâu?

— Đến khi nào nghe tiếng sôi nhỏ lại.

Nàng chăm chú nghe, gật đầu, rồi nghiêm túc nói:

— Ta nhớ rồi. Lần sau ta sẽ chờ.

— Không có lần sau. — Lục Trầm và Đa Đa đồng thanh.

Nàng nhìn hai người, rồi lần đầu tiên, khóe môi nàng hơi động, cực kỳ nhẹ, như một vệt gợn trên mặt hồ đóng băng, rồi lại phẳng. Lục Trầm chắc chắn mình không nhìn nhầm, nhưng hắn là kẻ biết điều, và hắn không nhắc đến chuyện ấy.

---

Họ ăn cháo giữa tiếng nước chảy. Hắn kể.

Hắn kể về Thanh Thạch, về Mệnh Giám trắng trơn, về Ngô chấp sự vả vào gương ba cái, về nửa ngày dân trấn đổi sắc mặt. Hắn kể về vị Chấp Bút Sứ lịch thiệp nói giết người là từ bi, và về lão chủ quán rượu say đã đứng chắn trước mặt hắn rồi không trở ra nữa. Hắn không nhắc đến mảnh giấy, cũng không nhắc đến Bạch Chỉ Quyết. Có những thứ nếu nói ra, hắn không lấy lại được.

Thanh Dao không ngắt lời. Nàng nghe, tay cầm bát cháo nguội dần, đôi mắt không rời mặt hắn. Chỉ khi hắn kể đến đoạn lão Hoàng đẩy hắn chạy, nàng khẽ hỏi:

— Người ấy là gì của ngươi?

— Không là gì cả. — Lục Trầm đáp. — Một lão chủ quán nhặt về nuôi, vẫn còn nợ ta ba tháng tiền công quét sân.

Nàng nhìn hắn rất lâu. Rồi nàng nói điều gì đó mà hắn không ngờ:

— Ngươi nói như vậy khi người ấy chết rồi?

— Lão chưa chết.

— Làm sao ngươi biết?

— Không biết. — Hắn đáp. — Nhưng ta nghĩ nếu ta tin lão chết, lão sẽ càng chết hơn.

Nàng không nói thêm gì. Một lúc sau, nàng lấy trong ngực áo chiếc Mệnh Giám cầm tay, đặt lên mặt đá giữa hai người.

— Đặt tay lên. Ta muốn tự xem.

---

Hắn đặt tay lên.

Mặt gương lạnh buốt, rồi trắng xóa. Một mảng trắng đục, đều đặn, không chút gợn, giống hệt cái buổi sáng trên bục gỗ trước miếu Thổ Địa. Thanh Dao nhìn nó chăm chú, rồi rút chiếc gương về.

— Gương này không hỏng. — Nàng thì thầm, như tự nói với mình. — Vừa rồi gương đọc được mệnh trang của tên mập. Vậy là đúng.

Nàng nâng gương lên, rồi thay vì đặt xuống, nàng lật nó lại, nhìn mặt gương hướng về phía mình.

— Cô nương làm gì vậy? — Lục Trầm hỏi.

— Ta muốn… — Nàng ngập ngừng, lần đầu tiên không tìm ra từ. — Ta muốn kiểm tra xem gương có chạy đúng không. Nên ta đọc mệnh trang của chính mình.

Nàng đặt lòng bàn tay xuống mặt gương.

Chữ vàng hiện lên.

Từ góc nhìn của Lục Trầm, hắn không đọc được, vì gương hướng về phía nàng. Hắn chỉ thấy ánh vàng nhàn nhạt phản chiếu lên mặt nàng, lên đôi mắt phượng, lên cặp lông mi dài. Hắn thấy nàng đọc, đọc rất chậm, như đã thuộc từng chữ, nhưng vẫn muốn đọc lại.

Rồi mặt nàng đổi.

Không đổi nhiều. Chỉ là đôi mắt đang lướt qua dòng cuối cùng bỗng dừng lại. Ngón tay đặt trên mặt gương khẽ co lại. Nàng chớp mắt một lần, hai lần, ghé sát gương hơn.

— Cô nương? — Hắn gọi.

— Đừng nói. — Nàng khẽ đáp.

Hắn im. Đa Đa cũng im, tay cầm thìa lơ lửng giữa không trung. Lão Chỉ trong tay áo hắn rón rén lên tiếng, rất nhỏ: *"Ngươi nhìn mặt nàng kìa."*

— Ta thấy.

*"Mặt nàng như vừa thấy ma."*

— Ta thấy.

Nàng đứng lên, quay lưng, bước đi vài trượng, đến sát bờ suối. Ánh trăng chiếu xuống tấm lưng thẳng tắp, và cũng chiếu xuống mặt gương nàng đang nâng ngang tầm mắt. Nàng đứng đó chừng mấy nhịp thở. Rồi nàng bước lùi lại, rất chậm, từng bước, từng bước, cho đến khi dừng lại cách hắn chừng ba thước.

Nàng nhìn xuống gương.

— …Lục Trầm. — Nàng nói, giọng khô khốc.

— Cô nương.

— Ngươi đứng lên, lùi ra xa, đến chỗ cây liễu kia.

— Làm gì?

— Cứ làm.

Hắn thở dài, đứng dậy, bước ra xa mười trượng, đến dưới gốc liễu. Thiếu nữ nhìn xuống gương. Ba nhịp thở. Năm nhịp thở. Nàng gật đầu, rồi vẫy tay:

— Lại gần. Chậm thôi. Dừng khi ta bảo.

Hắn bước. Mỗi bước chân đi qua đá cuội, nghe tiếng sỏi lạo xạo. Cách ba trượng, nàng im lặng. Cách hai trượng, nàng im lặng. Cách một trượng…

— Dừng.

Hắn dừng.

Nàng không nói gì rất lâu. Rồi nàng ngẩng đầu, ánh mắt xuyên qua khoảng cách ngắn ngủi giữa hai người, và Lục Trầm lần đầu tiên thấy trong đôi mắt ấy một thứ khác ngoài băng tuyết.

— Mệnh trang của ta, — nàng nói. — Dòng cuối cùng ghi: *Tuổi hai mươi, chết dưới kiếm.*

Lục Trầm im lặng. Đa Đa suýt nuốt cả cái thìa.

— Ta biết nó từ năm tám tuổi. Ba năm nữa ta hai mươi. Chữ ấy luôn rõ ràng, đen đậm như vừa khắc. — Giọng nàng đều đều, như đọc một bản báo cáo. — Khi ta đứng xa ngươi, nó rõ. Khi ngươi đến gần một trượng, nó… — Nàng dừng, như khó khăn mới tìm được từ. — …nó nhòe.

— Nhòe thế nào?

— Như mực bị nước thấm. Ranh giới các chữ lan ra, không còn đọc được rõ ràng. Hai chữ "chết dưới" gần như tan mất. — Nàng nhìn hắn. — Khi ngươi lùi lại, nó trở về như cũ.

*"…"* Lão Chỉ trong tay áo hắn không nói gì. Hắn cũng không dám nói.

— Cô nương, — hắn nói rất chậm. — Tại hạ không làm gì cả.

— Ta biết. — Nàng hơi cười, rất khẽ, một nụ cười không có chút vui vẻ nào. — Ta cũng không biết là gì. Chỉ là… từ năm tám tuổi, ta chưa từng thấy chữ trên mệnh trang mình biến đổi. Một nét cũng không.

---

Hắn không biết phải nói gì.

Hắn từng nghe người ta an ủi nhau bằng muôn kiểu lời hoa mỹ, và hắn thấy chẳng cái nào có ích. Hắn là kẻ biết chọn đúng lúc để im, thế nên lúc này hắn ngồi xuống một tảng đá cạnh suối, thong thả nhìn nàng, rồi nói một câu mà trong cuộc đời hắn hiếm khi nói ra:

— Còn ba năm, cô nương có thể lạc đường thêm khoảng hai trăm lần nữa. Quá đủ để chết vì già.

Nàng quay lại nhìn hắn, mặt vô cảm.

— Ta không lạc.

— Vâng. Ta quên.

— Ngươi đang chế nhạo ta, hay đang an ủi ta?

— Là an ủi bằng cách chế nhạo. — Hắn đáp. — Cách này tại hạ dùng cho cả bản thân.

Nàng im lặng nhìn hắn một lúc. Rồi nàng ngồi xuống, cách hắn đúng ba bước chân, gương đặt trên đầu gối, mắt vẫn nhìn mặt nước đen.

— Ta không sợ chết. — Nàng nói. — Ta đã nghĩ ngàn lần. Chỉ là ta ghét… phải biết trước. Mọi người đều sống với "không biết". Nhưng ta bị buộc phải mang theo một con số. Ta muốn biết con số ấy có đúng không, có thể xóa không, hay ít nhất, có thể… nhòe thêm một chút.

Nàng nói câu cuối, lần đầu tiên, rất nhỏ.

Lục Trầm nhìn bờ suối. Hắn không thương cảm. Hắn nghĩ đến lão Hoàng, đến mệnh số, đến Mệnh Giám trắng của chính hắn. Trên đời có kẻ bị ghi quá nhiều, có kẻ không được ghi gì. Hóa ra hai kẻ ấy ngồi cạnh nhau, giữa đêm, bên một bờ suối vô danh.

*"Tiểu tử."* Lão Chỉ nói khẽ, và lần này không hề châm chọc. *"Ngươi cần nàng. Còn nàng… cần ngươi hơn mức nàng biết."*

— Ngài thì biết đủ thứ. — Hắn đáp thầm.

*"Bản tọa không biết. Chỉ là… một mảnh giấy cũng có thể nhận ra khi một dòng chữ sắp bị xóa."*

---

— Ta đề nghị một thỏa thuận. — Thanh Dao nói, sau khi mặt trăng nghiêng thêm một chút.

— Xin nghe.

— Ta sẽ không giết ngươi. Ta cũng không trói ngươi. Ta đi cùng ngươi đến Lạc Phong, và theo dõi. — Nàng nói từng chữ như soạn công văn. — Trong thời gian ấy, ngươi đáp mọi câu ta hỏi, không được che giấu. Còn nếu ta kết luận ngươi là mối họa, ta sẽ ra tay.

— Tại hạ không phải mối họa. — Lục Trầm đáp. — Tại hạ chỉ là một kẻ muốn sống thêm vài năm.

— Vậy thì chứng minh. — Nàng nói. — Ta cần biết vì sao chữ trên mệnh trang ta lại nhòe khi ngươi đến gần.

— Cô nương không báo về Thiên Thư Các sao?

— Sẽ báo. Khi nào đến thành. — Nàng hơi dừng, không nhìn hắn. — Ta không nói dối. Nhưng ta cũng không có gì để báo. Chưa có kết luận.

Lục Trầm gật đầu chậm rãi. Hắn hiểu rõ nàng vừa làm một chuyện lớn: nàng vừa đặt giữa nhiệm vụ và sự thật một khoảng đệm nhỏ. Với một người chưa từng nói dối, đó là bước đi nguy hiểm.

— Còn điều kiện của tại hạ. — Hắn nói.

— Ngươi có điều kiện?

— Một. Khi đi đường, để tại hạ chỉ hướng.

Đa Đa phì cười thành tiếng, rồi vội che miệng.

Thanh Dao nhìn hắn thật lâu.

— Hai. — Hắn tiếp. — Cô nương không nấu ăn.

— …Chấp nhận.

— Ba. Khi tại hạ nói "dừng", cô nương dừng.

— Ta không nhận mệnh lệnh từ ngươi.

— Vậy là "nhờ". Cô nương làm ơn dừng.

— …Chấp nhận. — Nàng nói, giọng rất không tình nguyện. — Nhưng chỉ khi hợp lý.

— Tuyệt. — Lục Trầm khẽ cười. — Giao kèo thành.

Hắn giơ tay ra giữa không trung, ý tứ một cái bắt tay. Nàng nhìn bàn tay hắn như nhìn một món đồ lạ, rồi chầm chậm vươn bàn tay mình, chạm vào đầu ngón tay hắn, chỉ đúng một nhịp, rồi rụt về.

Đa Đa nhìn cảnh ấy, khóe miệng cong lên một độ cong rất đáng ngờ, và rất giống nụ cười của một thương nhân vừa tính ra một khoản lời không ai thấy.

Ánh lửa nhỏ dần. Dòng suối vẫn róc rách. Lục Trầm nằm xuống lớp cỏ khô, mắt nhìn trời.

Hắn không hay biết, ở phía đối diện, thiếu nữ vẫn ngồi thẳng, chiếc Mệnh Giám úp trên đầu gối. Nàng lén lật nó lên, nhìn dòng cuối cùng một lần nữa. Khoảng cách giữa hai người: hai trượng. Dòng chữ vẫn nhòe, rất nhẹ, nhưng vẫn nhòe.

Nàng nhìn rất lâu, rồi úp gương xuống, ngả đầu, nhắm mắt.

Cách đó vài dặm, trên mái nhà một quán trọ vừa tắt đèn, một con hạc giấy trắng lặng lẽ đáp xuống, đầu hạc xoay về hướng bờ suối.
