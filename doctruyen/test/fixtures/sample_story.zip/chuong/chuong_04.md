# Chương 4: Mảnh Giấy Biết Nói

Trời tối hẳn thì Lục Trầm tìm được một sơn động.

Cửa động nằm khuất sau một mảng dây leo, cao chưa đến một trượng, bên trong ẩm lạnh, nền đá phủ đầy lá thông mục. Hắn chui vào, dựa lưng vào vách đá, ngồi xuống. Đến lúc ấy hắn mới phát hiện hai bàn tay mình vẫn đang run, run không ngừng, như thể chúng không còn thuộc về hắn.

Mưa rả rích ngoài cửa động. Trong bóng tối, mảnh giấy trong lòng bàn tay vẫn ấm đều như hơi thở.

Hắn nhìn nó rất lâu.

Nửa ngày đường, hắn không dám nghĩ đến chuyện gì khác ngoài việc đặt chân xuống đất. Giờ thì mọi thứ ùa về: tiếng đao, vệt sáng rạch ngang trời, cái xoa đầu thô bạo, và câu *"rượu chua trẻ con uống hại bao tử"*. Lão già say ấy cả đời chưa từng nói một câu tử tế, vậy mà lần cuối cùng lại dặn dò chuyện bao tử.

— Lão đầu thối. — Lục Trầm khẽ nói với bóng tối. — Còn nợ ta ba tháng tiền công quét sân.

Không ai đáp lại. Hắn nhắm mắt, ép cổ họng nuốt xuống thứ gì đó cay xè, rồi mở mắt ra.

Và nhìn thấy chữ.

Trên mặt giấy vàng ố vốn trống trơn, một nét mảnh như sợi tóc đang chậm rãi vạch xuống. Nét ngang. Nét sổ. Nét phẩy. Từng nét hiện ra tựa hồ có bàn tay vô hình đang cầm bút, thong thả như một lão tú tài đang viết câu đối đầu năm. Mực không đen, mà là màu vàng nhạt, ánh lên một chút ánh sáng yếu ớt.

Hắn không động đậy. Hắn thậm chí không thở.

Cuối cùng nét bút dừng lại. Trên giấy là sáu chữ:

*Tiểu tử, ngươi ồn quá đấy.*

Lục Trầm nhìn sáu chữ ấy rất lâu.

— Ta chưa nói gì. — Hắn đáp.

Chữ trên giấy khẽ lay động, như người ta nhíu mày. Một hàng chữ mới hiện ra, lần này nhanh hơn, nét bút cũng phóng khoáng hơn nhiều:

*Ngươi đang gào trong lòng. Ồn đến mức bản tọa không ngủ nổi.*

— Bản tọa? — Lục Trầm nhướng mày.

*Chính là bản tọa. Nghe cho kỹ.*

Mặt giấy bắt đầu phát sáng. Ánh sáng vàng nhạt tụ lại ở chính giữa, rồi một luồng âm thanh khàn khàn, cũ kỹ như tiếng giấy cọ vào giấy, vang thẳng vào trong đầu hắn, không qua tai:

*"Nghe cho kỹ, tiểu tử! Bản tọa chính là đệ nhất cao nhân vạn cổ, Chí Tôn Chỉ Linh, người từng một nét bút định càn khôn, một cái búng tay phá cửu thiên! Hôm nay ngươi có phúc ba đời, mới gặp được bản tọa tỉnh giấc!"*

Lục Trầm im lặng một lúc.

— Ngài tên gì? — Hắn hỏi.

*"Tên của bản tọa…"* Giọng nói khựng lại. *"Tên của bản tọa vang dội cửu châu, khiến quỷ thần khiếp sợ, nói ra e rằng ngươi chịu không nổi."*

— Ta chịu được.

*"…"*

— Thật đấy. Ta chịu được.

*"Bản tọa… tạm thời… đang suy nghĩ."*

— Ngài không nhớ. — Lục Trầm nói.

*"Làm gì có chuyện đó!"* Giọng nói cao vút lên, giấy run lên bần bật. *"Chỉ là chuyện đã quá lâu. Vạn năm là một quãng thời gian dài, ngươi hiểu không? Ngươi, một phàm nhân mười lăm tuổi, có từng sống vạn năm chưa?"*

— Chưa. Nhưng ta nhớ tên mình.

Mảnh giấy im bặt. Một lúc sau, hai chữ nhỏ xíu hiện lên ở góc giấy, nét bút ỉu xìu:

*Lão Chỉ.*

— Lão Chỉ?

*"Tạm thời gọi như vậy. Là bản tọa tự nghĩ vừa rồi. Rất có khí phách, đúng không?"*

— Rất có khí phách. — Lục Trầm gật đầu, mặt không đổi sắc. — Gọi là "Lão Chỉ", vì ngài là một mảnh giấy.

*"Đó là chữ 'chỉ' trong 'chỉ điểm giang sơn'!"*

— Vâng.

---

Gió lùa qua cửa động, mang theo hơi lạnh của rừng đêm. Lục Trầm xoa hai tay vào nhau rồi bọc mảnh giấy lại, ủ trước ngực. Từ lúc nãy, hắn đã nhận ra một điều: dù nói năng ngông cuồng, mảnh giấy này chẳng có chút uy áp nào. Nó chỉ nói rất to, như một đứa trẻ trốn dưới gầm giường mà gào lên rằng nó là đại hiệp.

Lão Chỉ lại hắng giọng trong đầu hắn.

*"Được rồi. Nhìn dáng vẻ ngươi, hẳn là người có duyên, linh khí chưa có, căn cốt chưa có, thiên mệnh… cũng chưa có. Nhưng bản tọa độ lượng, không chấp nhặt. Còn chần chừ gì nữa? Quỳ xuống, dập đầu ba cái, bái bản tọa làm sư phụ!"*

— Không.

*"…Cái gì?"*

— Không. — Lục Trầm thản nhiên. — Ngài còn không nhớ nổi mình là ai, ta bái làm gì? Lỡ ngài là một mảnh giấy gói bánh thì sao?

*"Ngươi dám!"*

Mặt giấy bốc lên một luồng nhiệt, nóng đến mức hắn suýt buông tay. Hắn vẫn giữ chặt.

*"Bản tọa là… là…"* Giọng Lão Chỉ lạc đi, *"Bản tọa còn nhớ rõ ràng, từng có cả vạn người quỳ trước mặt bản tọa, lạy xin bản tọa nhận làm đồ đệ! Chỉ là bây giờ… khụ… ký ức bị bụi phủ mất một chút. Nhưng ngươi tin ta, tuyệt đối, nhất định…"*

— Ngài vừa tự gọi mình là gì? Chí Tôn Chỉ Linh?

*"Đúng vậy."*

— Vậy là ngài có tên đấy chứ.

*"…Đó là cách nói văn vẻ."*

Lục Trầm không nhịn được nữa, khóe miệng khẽ giật. Hắn vội cúi đầu, giả vờ ho khan một tiếng. Từ sau buổi sáng kinh hoàng ấy, đây là lần đầu tiên hắn suýt bật cười, và sự thật ấy khiến lồng ngực hắn vừa nhẹ đi, vừa nhói lên một cái. Lão Hoàng mà còn ở đây, hẳn sẽ vỗ đùi cười đến sặc rượu.

Hắn lập tức bóp chặt cái ý nghĩ ấy lại.

*"Ngươi cười gì thế?"*

— Ta không cười.

*"Ngươi cười! Bản tọa cảm nhận được!"*

— Ngài cảm nhận sai rồi. — Hắn nói. — Ta chỉ đang nghĩ xem một đệ nhất cao nhân vạn cổ, sao lại bị người ta nhét vào ngực áo của một lão chủ quán rượu chua.

Mặt giấy bỗng tối đi.

Không phải tối đi vì giận. Mà như bị ai đó đột ngột bóp nghẹt. Mấy dòng chữ hiện lên rồi tan đi, ánh vàng chớp tắt hai lần, và giọng Lão Chỉ trong đầu hắn chậm lại, thấp xuống, hoàn toàn mất vẻ ba hoa:

*"…Chủ quán rượu chua?"*

— Lão Hoàng. Người ném ngài cho ta.

*"Hoàng… Hoàng…"* Chữ run rẩy. *"Không nhớ. Bản tọa không nhớ tên ấy."*

— Ông ấy đã nhét ngài trong người rất nhiều năm.

*"Có thể. Cái mùi rượu chua này… bản tọa đúng là ngửi thấy. Nhưng không nhớ. Tiểu tử, đừng ép."*

Lục Trầm nhìn mảnh giấy. Lần đầu tiên trong đêm nay, mảnh giấy này trông giống một thứ cần được cẩn thận.

— Lúc đi, ông ấy bị một kẻ áo trắng gọi là "Đao Quỷ".

Hai chữ vừa dứt, mảnh giấy rung lên như bị ai kéo mạnh. Không phải rung vì giận, mà rung như lá khô trước gió thu. Ánh sáng vàng nhạt co rút lại thành một điểm, rồi một dòng chữ nguệch ngoạc, nét bút xiêu vẹo, chạy loạn trên mặt giấy:

*Đừng nhắc.*

— Ngài biết cái tên ấy?

*Không biết. Không nhớ. Nhưng… đừng nhắc.* Rồi thêm một dòng: *Bản tọa không hiểu vì sao bản tọa… sợ.*

Hang động chìm vào im lặng. Chỉ có tiếng mưa nhỏ giọt xuống đá.

Lục Trầm im hồi lâu, rồi nói, giọng bình thản như đang bàn chuyện thời tiết:

— Vậy ta không nhắc nữa.

*"…Ừ."*

— Nhưng lão ấy nhất định chưa chết. — Hắn nói tiếp, không rõ để thuyết phục ai. — Lão sống dai lắm. Lão tự nói thế.

Một lúc sau, những nét chữ rất nhẹ hiện lên:

*Ừ. Kẻ nào đã dặn dò như vậy thì sẽ không dễ chết.*

Hắn chớp mắt. Câu ấy không giống giọng một mảnh giấy khoác lác chút nào. Hắn nhìn chằm chằm vào hàng chữ, nhưng nó đã mờ dần.

---

Vừa lúc ấy, ngoài cửa động bỗng sáng lên.

Không phải ánh trăng. Đó là thứ ánh sáng lạnh lẽo màu trắng bạc, lướt qua mảng dây leo, in lên vách đá một vệt sáng dài rồi lại biến mất. Lục Trầm lập tức dập tắt hơi thở, tay còn lại ấn xuống nền đất ẩm.

Chỉ thấy bên ngoài, giữa màn mưa phùn, vài con hạc giấy trắng đang bay lượn trên các ngọn thông.

Mỗi con chỉ to bằng bàn tay, thân giấy mỏng như cánh ve, đầu hạc ngậm một hạt sáng nhỏ như đốm lửa ma trơi. Chúng bay không nhanh, nhưng rất đều, mũi chúc xuống như một con chó săn đang ngửi dấu vết. Cánh giấy không bị nước mưa làm ướt, chỉ khẽ rung theo từng nhịp.

*Chỉ Hạc Truy Tung.* Giọng Lão Chỉ khẽ vang lên, nhỏ như tiếng muỗi. *Vật của Thiên Thư Các. Nó đọc mệnh số của người mà tìm đường.*

— Ngài nhớ ra cái này?

*Nhớ ra đúng một cái này thôi. Đừng hỏi.*

— Nó đọc mệnh số… — Lục Trầm khẽ nói. — Ta không có mệnh số.

*Cho nên nó không tìm ngươi được. Nhưng nó có thể tìm* ***dấu*** *của ngươi: bùn dính giày, cành bị bẻ, mùi người. Lũ hạc kia chỉ là con mắt. Người sau lưng chúng mới là mũi dao.*

Qua khe dây leo, Lục Trầm thấy một con hạc dừng lại, lơ lửng ngay trước cửa động, đầu hạc xoay qua xoay lại. Hạt sáng trong mỏ nó chiếu lên đám lá thông, rồi lên mảng dây leo.

Tim hắn đập từng nhịp nặng nề.

Hắn nhìn xuống chân. Bùn trên giày vẫn còn tươi, một vệt dài in lên nền động ngay sát cửa. Nếu hạc giấy kia chui vào một tấc nữa…

*Dấu giày!* Lão Chỉ nói gấp gáp. *Mau lên!*

— Ngài bảo sao?

*Bản tọa có thể thu hết khí tức, nhưng bùn trên giày ngươi thì không! Nhanh! Lau đi!*

Lục Trầm không do dự nữa. Hắn lột phăng áo ngoài, quệt thật mạnh vào vệt bùn, rồi vo viên áo lại ném sang góc động tối. Con hạc giấy ngoài cửa động ngừng một khắc, đầu mỏ chĩa xuống mặt đất.

Hắn nhắm mắt lại.

Một nhịp thở. Hai nhịp thở. Mười nhịp thở.

Con hạc xoay mình, bay vút lên, hòa vào đàn hạc, rồi cả bầy lướt về phía đỉnh núi, ánh bạc lấp lánh xa dần.

Lục Trầm thở ra một hơi dài, lưng áo đã ướt đẫm mồ hôi lạnh.

*Đáng tiếc.* Giọng Lão Chỉ lại nổi lên, lần này đã lấy lại một chút ngạo khí. *Nếu bản tọa còn ở thời cực thịnh, đừng nói là mấy con hạc giấy, cả Thiên Thư Các cũng phải…*

— Ngài vừa sợ đến mức không dám thở.

*Đó là… chiến thuật.*

— Ngài vừa rồi gọi ta "mau lên" tới ba lần.

*Đó là… để chỉ huy.*

— Vâng. Đệ nhất cao nhân vạn cổ chỉ huy rất tốt. — Lục Trầm đáp.

Lão Chỉ nghẹn lời. Cuối cùng giấy phát ra một tiếng "hừ" rất khẽ trong đầu hắn, vừa dỗi vừa nhụt chí.

Lục Trầm tựa lưng vào vách đá, ngước nhìn trần động tối đen. Hắn mười lăm tuổi, là phàm nhân, bị cả Thiên Thư Các đuổi giết, trong tay chỉ có một mảnh giấy nhát gan không nhớ nổi tên mình. Nghĩ đến đó, khóe môi hắn lại khẽ cong lên một chút, nửa là cười khổ, nửa là chân tâm.

— Lão Chỉ. — Hắn nói.

*Hả?*

— Ngài thật sự có thể dạy ta một thứ gì đó không?

Mảnh giấy im lặng một lát.

*Bản tọa không nhớ mình là ai.* Lão Chỉ đáp, giọng chậm rãi, lần này không có một chút ngông cuồng. *Nhưng có một chuyện, bản tọa nhớ rất rõ.*

— Chuyện gì?

*Cơ thể ngươi. Khi ngươi cầm bản tọa lên, bản tọa liền biết: ngươi là một trang trắng. Không có một chữ nào trên người. Chính vì thế bản tọa mới tỉnh được.* Từng nét chữ hiện lên trên mặt giấy, vàng nhạt, nhẹ như hơi thở. *Cho nên, tiểu tử, nghe cho kỹ. Thứ mà người đời cho là lời nguyền, có lẽ chính là thứ duy nhất có thể cứu ngươi.*

Hắn nhìn những dòng chữ ấy. Ngoài cửa động, mưa đã ngừng, chỉ còn tiếng nước nhỏ giọt từ mái dây leo xuống nền đá.

— Vậy… — Lục Trầm nói. — Bắt đầu từ đâu?

*Bắt đầu từ chỗ ngươi chịu nhận bản tọa làm sư phụ.*

— Ngủ trước đi. Ngày mai nói tiếp.

*Này! Tiểu tử! Ngươi đừng giả vờ ngủ!*

Lục Trầm nhắm mắt, mặc kệ giọng nói oang oang trong đầu. Nhưng trước khi chìm vào giấc ngủ, hắn nghe tiếng Lão Chỉ lẩm bẩm rất nhỏ, như nói với chính mình:

*…Hoàng. Hoàng…*

*Sao nghe cái tên ấy, lòng bản tọa lại thấy chua như vậy?*
