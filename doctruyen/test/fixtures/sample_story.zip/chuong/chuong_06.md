# Chương 6: Tên Mập Không Sợ Chết

Ngày thứ năm, trái dại trong rừng đã bị hắn hái sạch.

Lục Trầm đứng trên sườn núi, nhìn xuống con đường đất uốn lượn nơi chân dốc, trong bụng réo lên một tiếng dài. Luyện Khí tầng một có thể giúp hắn nhìn rõ hơn, nghe xa hơn, nhưng không giúp hắn no bụng. Đan điền ấm áp, tay chân nhẹ nhõm, còn dạ dày thì trống rỗng như một cái giếng cạn.

*"Tu sĩ đến Trúc Cơ là có thể tịch cốc."* Lão Chỉ nằm trong tay áo hắn, lên tiếng. *"Ngươi đừng tầm thường như thế, đã bước chân vào tiên đồ thì phải…"*

— Một bát cháo nóng. Thêm hai cái bánh bao.

Lão Chỉ nghẹn lời, một lúc sau mới lầm bầm:

*"Bản tọa cũng… hơi muốn ăn bánh bao. Dù không có miệng."*

Hắn xuống núi. Dọc theo con đường đất có dấu bánh xe, dấu ngựa, và cả một xác xe hàng bị lật nghiêng bên bờ mương. Hòm gỗ vỡ tan, vải vóc xé nát, gạo rải ra khắp mặt đường, còn có những vệt máu đã khô. Lục Trầm dừng lại, quan sát một lúc.

— Cướp. — Hắn nói.

*"Sơn tặc."*

Hắn men theo dấu giày. Đi chưa đến nửa dặm, tiếng người từ phía rừng bên đường vọng ra, rất lớn, rất ồn, mà đặc biệt là có một giọng nói sang sảng, đầy tự tin, ngang nhiên cãi nhau với cả đám người:

— Các ngươi có biết ta là ai không? Ta là thiếu chủ Tiền gia ở Lâm Giang! Cha ta là Tiền Vạn Quán, thương hội Tiền gia trải khắp ba châu! Mệnh trang của ta ghi rõ ràng: *đại phú đại quý, thọ tám mươi*! Ta còn sống lâu hơn tất cả các ngươi cộng lại, các ngươi giết ta thử xem!

Lục Trầm trèo lên một gốc cổ thụ, rẽ cành ra nhìn.

---

Dưới gốc cây là một bãi đất trống, dựng chừng mười cái lều vải rách, giữa bãi đốt một đống lửa lớn. Khoảng hai mươi tên sơn tặc, kẻ cầm đao, kẻ cầm gậy, đang quây quanh một cột gỗ.

Trên cột gỗ trói một thiếu niên.

Thiếu niên chừng mười sáu tuổi, người tròn như quả bí, bộ cẩm bào thêu chỉ vàng dính đầy bùn nhưng vẫn không giấu được vẻ sang trọng. Mặt tròn, mắt nhỏ lanh lợi, và cái miệng thì không biết sợ là gì.

— Còn ngươi, tên lùn sẹo mặt kia! — Gã quay sang một tên đứng gần, khinh khỉnh. — Ngươi tướng mạo này, chắc chắn không sống quá bốn mươi! Ta khuyên ngươi nên đổi nghề đi!

— Ngươi còn dám mở mồm? — Tên sẹo mặt giận đến tím tái, vung đao. — Ta chém ngươi!

— Chém đi! — Thiếu niên mập vểnh cằm. — Ta không chết được! Ta thọ tám mươi! Nếu ta chết hôm nay, Thiên Thư sẽ sai! Thiên Thư sai, Thiên Thư Các sẽ đến tìm các ngươi!

Tên sẹo mặt khựng lại, quay sang nhìn một người đàn ông cao to, ngồi trên một khúc gỗ ở giữa, mặt đầy râu, một mắt bị mù.

Đó hẳn là thủ lĩnh.

— Đại ca. — Tên sẹo mặt khổ sở. — Cái thằng này nó… nó có lý. Mệnh trang của nó thật sự ghi như vậy. Tiểu đệ soi bằng mảnh Mệnh Giám vỡ rồi.

Thủ lĩnh một mắt gõ nhẹ ngón tay lên đầu gối, nhìn thiếu niên mập, chậm rãi nói:

— Ta không giết. Ta chỉ bắt nó viết thư cho cha nó, đòi ba nghìn linh thạch. Khi nào có tiền thì thả. Không có thì… chặt một ngón tay gửi về. Thọ tám mươi, thiếu một ngón tay vẫn là tám mươi.

— Ngươi!

Thiếu niên mập cuối cùng cũng biến sắc. Nhưng chỉ một cái chớp mắt, gã ưỡn ngực lên, giọng còn cao hơn nữa:

— Ba nghìn? Nực cười! Cha ta nuôi một con ngựa cũng tốn nhiều hơn thế! Ít nhất cũng phải là năm nghìn! Các ngươi định xúc phạm gia thế Tiền gia sao?

Cả đám sơn tặc sững sờ nhìn nhau.

Trên cây, Lục Trầm cúi đầu, nghiêm túc hỏi mảnh giấy trong tay áo:

— Lão Chỉ. Người này có phải bị điên không?

*"Không phải điên. Là loại có tiền. Hai thứ này thường giống nhau."*

— Hắn vừa tự nâng giá tiền chuộc mình lên.

*"Ừ. Một nhân tài."*

---

Lục Trầm không nhúc nhích. Hắn quan sát như đã quan sát suốt bao năm ở quầy rượu của lão Hoàng. Mười chín tên sơn tặc, phần lớn là phàm nhân; tên sẹo mặt và hai kẻ bên cạnh thủ lĩnh cỡ Luyện Khí tầng hai, tầng ba; thủ lĩnh một mắt chừng tầng bốn. Hắn mới tầng một, động thủ thì chẳng khác nào lấy trứng chọi đá.

Nhưng hắn không định động thủ.

Ánh mắt hắn lướt qua bãi đất, dừng lại ở một thứ treo trên cọc gỗ ngay lối vào trại.

Một chiếc chuông đồng nhỏ, to chừng nắm tay, khắc đầy ký tự li ti. Mỗi lần có kẻ qua lại gần lối vào, chuông lại ngân khẽ một tiếng, và tên canh gác bên cạnh gật đầu rồi làm ngơ. Lục Trầm đếm: trong một nén hương, chuông kêu bảy lần, đúng với bảy tên sơn tặc đi tuần ra vào.

*"Báo Mệnh Linh."* Lão Chỉ khẽ nói. *"Pháp khí rẻ tiền. Hễ có người sống mang tên trong Thiên Thư đến gần trong ba mươi trượng, chuông tự reo. Dùng để canh nhà, canh trại, tiện nhất."*

— Còn người không có tên?

*"Nó không biết."*

Lục Trầm nhìn chiếc chuông thêm một lúc. Khóe miệng hắn khẽ nhếch lên.

— Ngài có thể viết chữ lên giấy, cho người ta đọc được không?

*"Đương nhiên! Bản tọa là…"*

— Viết to. Loại ai cũng đọc được.

*"Ngươi định làm gì?"*

— Một vở kịch. — Lục Trầm nói. — Ta cần ngài đóng vai chính.

Mảnh giấy im lặng một nhịp, rồi rung bần bật vì phấn khích.

*"Vai chính! Bản tọa đảm nhận!"*

---

Hoàng hôn buông xuống, bãi đất bắt đầu tối. Những tên sơn tặc ăn xong bữa tối, ngồi quây quần bên đống lửa. Tên sẹo mặt đang lục lọi hành lý của thiếu niên mập, và nhặt lên một cuốn sổ nhỏ có bìa da.

— Này, có cả sổ sách ghi chép rõ ràng, tên này chắc giàu thật.

— Trả lại ta! — Thiếu niên mập vùng vẫy, mặt đỏ gay. — Đó là bàn tính của ta! Cuốn sổ ấy một chữ đáng giá một lạng bạc! Ngươi dám cầm…

Chuông ở lối vào không hề kêu. Tên canh gác nhìn bóng tối bên ngoài, gãi đầu.

— Không có ai mà. Chắc gió.

Thế nhưng khi y quay lại, một thiếu niên áo xám đã đứng sẵn bên đống lửa.

Thiếu niên ấy dáng gầy, mặt dính bùn, tay áo rách, nhưng thần sắc bình tĩnh. Trong lòng bàn tay trái hắn giữ một mảnh giấy vàng, mặt giấy phát sáng, những chữ vàng bay lơ lửng như đom đóm.

Đám sơn tặc ngẩn người một khắc. Rồi thủ lĩnh một mắt quát:

— Ai! Từ đâu ra!

Báo Mệnh Linh không kêu.

Cả đám người ngẩng đầu nhìn cái chuông. Chuông im lìm, một cái lưỡi đồng đứng bất động. Có tên đã bắt đầu lùi lại.

— Chuông không kêu… — Tên sẹo mặt run giọng. — Đại ca! Thứ này không có tên trong Thiên Thư! Nó… nó không phải người!

Lục Trầm khẽ giơ mảnh giấy lên, bình thản, mặt không đổi sắc. Những chữ vàng trên giấy tụ lại, hiện ra từng hàng rõ mồn một:

**VÔ THƯỜNG SỨ GIẢ ĐẾN THU MỆNH.**

**KẺ NÀO KHÔNG THẢ TÙ NHÂN, ĐÊM NAY TÊN BIẾN KHỎI SỔ SỐNG.**

Tiếng hít khí lạnh vang lên khắp bãi đất.

Trên cột gỗ, thiếu niên mập trợn tròn đôi mắt, nhìn chằm chằm vào chữ vàng, rồi nhìn Lục Trầm, rồi lại nhìn chữ.

— Này. — Gã nói rất to, hoàn toàn không kiêng nể. — Chữ "thu" trong "thu mệnh" ngươi viết sai rồi. Nhìn nét phẩy kia kìa. Nếu là quỷ, ít ra cũng phải biết chữ chứ.

Mảnh giấy khựng lại giữa không trung, các nét vàng run lên.

*"…Hắn nói bản tọa viết sai chữ."* Giọng Lão Chỉ vang trong đầu Lục Trầm, tức tối vô cùng.

— Đừng để ý. — Lục Trầm đáp thầm.

*"Bản tọa là đệ nhất cao nhân vạn cổ, sao có thể viết sai chữ!"*

— Ngài vừa không nhớ nổi tên mình.

*"…Chữ ấy chỉ là nhất thời lệch nét!"*

— Thủ lĩnh. — Lục Trầm nhìn thẳng vào tên một mắt, giọng nói cố tình hạ thấp, đều đều, lạnh lẽo. — Bổn sứ chỉ lấy một người. Người này thọ tám mươi, ghi trong sổ chưa đến lúc chết, không đến lượt các ngươi đụng vào. Thả ra, mọi chuyện coi như chưa có. Nếu không…

Hắn dừng. Chỉ dừng.

Sự im lặng đáng sợ hơn bất kỳ lời đe dọa nào.

Tên sẹo mặt đã quỳ xuống ôm đầu. Hai tên khác vứt cả đao, tháo chạy vào rừng. Thủ lĩnh một mắt cắn răng, tay vẫn siết chặt chuôi đao, gân xanh nổi lên bên thái dương. Cuối cùng y phẩy tay:

— Thả… thả thằng béo ra! Mau!

Dây thừng rơi xuống.

Thiếu niên mập vừa được thả thì đã không buồn chạy. Gã xoa cổ tay, khệnh khạng bước qua bên cạnh tên sẹo mặt, giật lại cuốn sổ, sau đó tiện tay cầm luôn túi tiền bên hông thủ lĩnh một mắt, lắc lắc thử, nghe tiếng leng keng rồi vui vẻ giắt lại vào người mình.

— Cái này là lãi. — Gã tuyên bố. — Phí tinh thần.

Cả đám sơn tặc, kể cả thủ lĩnh, không một ai dám phản đối.

Lục Trầm quay lưng bước đi. Hắn giữ vẻ bình thản từng bước cho đến khi bóng cây rừng nuốt chửng ánh lửa, rồi mới dựa vào một gốc cây, thở ra một hơi dài, hai chân hơi run.

Thiếu niên mập lẽo đẽo theo sát phía sau, miệng cười không khép lại được.

---

— Hoàn hảo! — Thiếu niên mập cười toe, chạy lên cạnh hắn. — Thật hoàn hảo! Ta chưa từng thấy ai lừa sơn tặc đẹp như thế! Huynh đài xưng hô thế nào? Tại hạ Tiền Đa Đa, con trai độc nhất của Tiền Vạn Quán Lâm Giang!

— Lục Trầm.

— Lục huynh! — Đa Đa chắp tay, cúi người thật sâu. — Ơn cứu mạng, tại hạ không biết lấy gì báo đáp. Không bằng… huynh cho ta đi theo!

— Không cần.

— Sao lại không cần? Tại hạ có tiền! Mỗi ngày bao ăn ở, bao cả quần áo mới!

Lục Trầm đang bước đi bỗng khựng một nhịp.

— Ngươi vừa nói gì?

— Ta có tiền! — Đa Đa vỗ vào túi, tiếng leng keng vang lên, gồm cả phần của thủ lĩnh. — Ta tin mệnh mình tốt, nhưng mệnh tốt mà không biết lừa người thì cũng phí.

— Ngươi tin mệnh ngươi tốt, nhưng suýt bị chặt ngón tay.

— Đó là tình huống bất ngờ. — Đa Đa chột dạ, nhưng lập tức cười tươi. — Hơn nữa, huynh vừa nói "người này thọ tám mươi, chưa đến lúc chết". Ngay cả quỷ cũng công nhận mệnh trang của ta!

— Ta chỉ nói cho đủ vở kịch.

Lục Trầm im lặng một lát, liếc túi tiền căng phồng bên hông Đa Đa, rồi liếc cái bụng đang réo của mình.

— Có bánh bao không?

— Có! — Mắt Đa Đa sáng rỡ. — Ta biết chỗ bán bánh bao! Trong thôn cách đây nửa dặm, hàng của lão Từ, làm nhân thịt nhiều nhất vùng! Ta bao!

— Thành giao.

*"…Ngươi bán mình chỉ vì bánh bao?"* Lão Chỉ thở dài trong đầu.

— Là vì bánh bao và tiền. — Lục Trầm đáp thầm. — Ngài biết một mảnh giấy thì không ăn được, đúng không?

---

Họ vào thôn lúc canh một.

Cái thôn nhỏ chỉ có hơn mười nóc nhà, nằm cạnh con đường lớn dẫn ra quan đạo. Lão Từ bán bánh bao đã đóng cửa, nhưng Đa Đa chỉ gõ cửa ba cái, nhét một viên bạc vụn vào tay chủ tiệm, thế là hai khay bánh bao nóng hổi được bưng ra, hơi nước nghi ngút.

Lục Trầm ăn bánh thứ ba thì chợt nhìn thấy một tờ giấy dán trên cột đá bên đường.

Giấy mới, mực chưa khô, ngay dưới ánh đèn lồng đỏ treo trước cửa tiệm. Hắn đặt bánh xuống, bước lại gần.

Trên giấy là hàng chữ lớn viết bằng mực đen:

**TRUY NÃ DỊ SỐ**
**LỤC TRẦM, MƯỜI LĂM TUỔI. TRẤN THANH THẠCH.**
**PHỤNG LỆNH THIÊN THƯ CÁC: AI BẮT SỐNG, THƯỞNG NĂM TRĂM LINH THẠCH.**

Dưới dòng chữ là một bức chân dung.

Lục Trầm nhìn chằm chằm vào bức vẽ.

Người trong tranh có gương mặt tròn như cái bánh, hai má phính, đôi mắt tí hon cười tít, cằm hai ngấn.

— …Trông còn giống ngươi hơn giống ta. — Hắn nói.

— Cái gì? — Đa Đa chạy lại, nhìn lên giấy, rồi mặt gã từ từ đỏ lên. — Ai dám vẽ như vậy! Mắt ta to hơn nhiều!

— Quan trọng không phải mắt. — Lục Trầm trầm giọng. — Quan trọng là nơi này chỉ cách trấn Thanh Thạch hai ngày đường, mà giấy truy nã đã dán tới. Lão trượng, giấy này dán từ khi nào?

— Mới sáng nay, tiểu huynh đệ. — Lão Từ gãi đầu. — Người của Thiên Thư Các dán. À, còn một chuyện lạ.

— Chuyện gì?

— Chiều nay có một cô nương áo trắng, đeo kiếm, đứng trước tiệm của lão hỏi đường tới Thanh Thạch. — Lão Từ nhớ lại. — Dáng người thanh tú, mặt lạnh như sương, nhìn là biết người trong đại tông môn. Lão chỉ tay về hướng bắc, bảo nàng cứ đi dọc quan đạo là tới. Nàng gật đầu, nói *"đa tạ, ta biết"*, rồi quay lưng đi thẳng về phía nam.

Lục Trầm im lặng.

— Lão bảo nàng hướng ấy không phải. Nàng nói *"không sao, ta nhớ rõ đường"*, rồi cứ thế đi mất. Nhưng trước khi đi, nàng còn hỏi thêm một chuyện.

— Chuyện gì?

— Nàng hỏi, gần đây quanh vùng này, có kẻ nào… *"không có tên"* đi qua không.

Hơi nóng của bánh bao trong tay Lục Trầm đột ngột nguội đi. Trên cột đá, bức chân dung béo tròn của Tiền Đa Đa mỉm cười vô tội, dưới ánh đèn lồng đỏ.

*"Thiên Thư Các."* Lão Chỉ khẽ nói, trong giọng không còn chút đùa cợt. *"Tiểu tử, người đuổi theo ngươi, không còn chỉ là hạc giấy nữa."*
