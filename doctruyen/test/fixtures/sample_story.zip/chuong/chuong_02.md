# Chương 2: Tiếng Chuông Trong Đêm

Tin dữ chạy nhanh hơn ngựa. Chưa tới giờ Ngọ, cả trấn Thanh Thạch đã biết đứa nhỏ nhà quán rượu cuối phố là dị số.

Không ai giải thích được dị số là gì, nhưng ai cũng biết nó chẳng phải điều lành. Người ta kể rằng dị số là kẻ trời không thèm ghi tên, nên trời cũng không che chở, và những gì ở gần hắn đều sẽ xui xẻo theo. Đến buổi chiều, lời đồn đã tiến hóa thêm vài bậc: có kẻ thề rằng đã thấy cái bóng của Lục Trầm không nằm đúng hướng mặt trời. Lục Trầm nghe được chuyện này lúc đi mua đậu phụ, trong lòng thành thật khâm phục trí tưởng tượng của dân trấn.

Hắn xách cái giỏ trúc đi dọc con phố đá xanh, tiếng giày vải gõ nhịp khô khốc. Các cửa tiệm hai bên đều mở, nhưng chủ tiệm đứng cả ở ngưỡng cửa, mắt dán vào hắn như dán vào một nồi canh sắp trào.

Đến sạp đậu phụ của Vương đại nương, hắn dừng lại.

Vương đại nương là một phụ nhân tròn trịa, tay lúc nào cũng ướt nước đậu, giọng vang như kèn đồng. Mười lăm năm qua, sáng nào bà cũng cắt cho hắn hai miếng đậu to nhất, rồi mắng hắn gầy như que củi, ăn nhiều vào. Hôm nay, bà đứng sau cái thớt, tay cầm dao, không nhúc nhích.

— Hai miếng, như mọi khi. — Lục Trầm nói.

Vương đại nương nhìn hắn. Mắt bà đỏ, nhưng cái đỏ ấy không phải của người sắp khóc. Đó là ánh mắt của người đang giằng co với chính mình.

— Hôm nay hết rồi. — Bà nói, giọng gượng gạo.

Lục Trầm liếc mâm gỗ đầy ắp đậu phụ trắng tinh sau lưng bà, không nói gì. Hắn chỉ gật đầu, xoay người.

— Tiểu… tiểu tử thối. — Vương đại nương gọi với theo.

Hắn quay đầu lại. Bà đang xúc bốn miếng đậu bỏ vào lá sen, gói vội, ném cái gói qua mặt thớt như ném củ khoai nóng. Gói đậu rơi gọn vào giỏ hắn.

— Lão nương không bán. Lão nương cho. — Bà nói thật to, như để cả phố nghe thấy mình không phạm điều cấm nào. — Cầm lấy rồi đi đi. Đừng đến đây nữa.

— Vâng. — Lục Trầm nói. — Bốn miếng. Đại nương cho nhiều hơn mọi khi, chắc là sợ vãn bối chết đói trước ngày bị xử.

— Đồ tiểu quỷ! — Vương đại nương quát, rồi quay đi, lấy vạt áo lau mắt.

Hắn mỉm cười, nụ cười rất nhạt, rồi bước tiếp. Hắn hiểu bà. Người ta có thể sợ một thứ mà vẫn thương nó, hai chuyện ấy không mâu thuẫn. Chỉ là những người sống ở nơi này không có nhiều thứ để lựa chọn, cho nên nỗi sợ luôn thắng.

Phía sau vang lên tiếng bước chân nhỏ chạy theo. Tiểu Đậu thò đầu ra từ sau thùng nước, hai tay giấu sau lưng.

— Trầm ca. — Nó thì thào. — Nương đệ bảo không được nói chuyện với huynh.

— Thế ngươi đang làm gì?

— Đệ không nói. Đệ đang… đứng thở. — Nó nhìn trước ngó sau, rồi chìa ra một cái bánh bao nhỏ. — Của đệ. Huynh cầm đi. Nương đệ bảo dị số là thứ xấu, nhưng đệ thấy huynh không xấu. Huynh còn chưa lừa đệ quả táo nào.

Lục Trầm nhìn cái bánh bao, nhìn đứa nhỏ, rồi nhận lấy.

— Ngươi nên lừa người khác trước khi người ta lừa ngươi. — Hắn nói. — Nhưng đa tạ.

Tiểu Đậu cười toe, rồi chạy biến.

---

Quán rượu của lão Hoàng nằm ở cuối phố, sát chân núi, là một ngôi nhà gỗ hai tầng xiêu vẹo, tấm biển hiệu đã bạc màu chỉ còn đọc được hai chữ "Hoàng Tửu" cùng một vết gì đó rất giống phân chim. Mái ngói rêu phủ xanh, cửa ra vào xệ một bên, trong sân có một cái giếng cổ và một cây hồng già sai quả mà chẳng ai buồn hái.

Khách quen của quán đếm trên đầu ngón tay: một lão thợ mộc, một vị lang trung già, và vài kẻ nhàn rỗi cần chỗ ngồi uống. Hôm nay quán trống không. Mấy vị khách quen cũng đã nghe tin, và tối nay chẳng ai muốn ngồi trong quán của kẻ nuôi dị số.

Lão Hoàng nằm dài trên sập trúc ở sân sau, cái bầu rượu gác lên bụng, miệng há ra ngáy, râu ria lòa xòa còn dính cả hạt cơm từ bữa trưa. Lục Trầm đặt giỏ đậu phụ xuống bếp, nhóm lửa, nấu một nồi canh đậu phụ đơn giản, rồi bưng ra sân.

— Dậy ăn.

— Ừm. — Lão Hoàng mở một mắt. — Giờ nào rồi?

— Giờ Dậu.

— Còn sớm. — Lão nhắm mắt lại.

— Giờ Dậu là chiều tối, không phải sớm.

— Với kẻ say thì lúc nào cũng sớm. — Lão ngáp dài. — Đậu phụ à? Bà Vương bán cho ngươi à? Thế nghĩa là bà ta vẫn chịu bán.

— Bà ấy cho. Bà ấy bảo ta đừng đến nữa.

Lão Hoàng khựng lại một chút, cái bầu rượu trên bụng khẽ nhúc nhích. Rồi lão ngồi dậy, tu một ngụm, nhăn mặt, nhổ toẹt ra.

— Rượu này hỏng rồi. Chua.

— Hôm qua lão khen nó ngon.

— Hôm qua nó chưa chua. — Lão đáp bằng giọng của kẻ cả đời chưa từng sai. — Này, tiểu tử. Hôm nay… ngoài kia có ai làm gì ngươi không?

— Không. Chỉ có người ta nhìn ta như nhìn xác chết biết đi. — Lục Trầm ngồi xuống bậc thềm, múc canh. — Lão nên biết, hôm nay ta đã thành trò cười số một của cả trấn. Ta chưa từng nổi danh đến thế. Mai chắc ta sẽ thành giai thoại thiên cổ, sau này có người viết sách kể chuyện một thiếu niên làm gương đồng sợ đến mức không dám sáng.

— Ngươi bị gương đập hay ngươi đập gương?

— Vị chấp sự kia đập gương. Ba lần. Ta chỉ đứng nhìn.

— Hà. — Lão Hoàng cười khùng khục, nhưng tiếng cười chợt tắt. — Ba lần. Kẻ đó phải ngu đến mức nào mới nghĩ là đập được.

— Y là kẻ sợ. Người đã sợ thì làm gì cũng ngu.

Lão Hoàng nhìn thiếu niên trước mặt hồi lâu. Trong ánh hoàng hôn đỏ như rượu, khuôn mặt nhăn nheo của lão dường như già hơn thường lệ.

— Ngươi không sợ à?

— Sợ. — Lục Trầm thành thật đáp. — Nhưng ta đang đói, mà đã đói thì nỗi sợ chẳng còn chỗ mà ngồi.

— Ăn đi. — Lão Hoàng nói, giọng thô lỗ. — Bớt nói nhảm. Ăn hết nồi canh, rồi đi ngủ. Ngươi là tiểu tử của lão tử, thì trời có sập cũng phải ăn no rồi hẵng chết.

— Lão đang an ủi ta hay đang rủa ta?

— Cả hai. Đỡ tốn công.

Lục Trầm bật cười, lần đầu tiên trong cả ngày. Hắn ăn. Lão Hoàng ngồi cạnh, vừa bóp trán vừa gắp trộm miếng đậu phụ Vương đại nương cho. Hai người im lặng ăn, tiếng đũa chạm bát lách cách, tiếng dế kêu rả rích trong luống rau.

— Lão Hoàng. — Một lúc sau hắn cất tiếng. — Mười lăm năm trước lão nhặt ta ở đâu?

— Bên bờ suối. Trong một cái giỏ trúc.

— Lão kể mười lần rồi, mỗi lần một khác. Lần trước là trong cái nồi, lần trước nữa là dưới gốc cây hồng.

— Thì lần này lão tử nhớ đúng. — Lão nói trơn tru. — Đi rửa bát.

Lục Trầm biết lão sẽ không nói. Hắn không hỏi thêm. Hắn có một thói quen đặc biệt: biết khi nào nên hỏi, và khi nào chỉ cần ghi nhớ.

---

Đêm xuống. Trấn Thanh Thạch tắt đèn sớm hơn mọi khi, từng nhà một cài chặt then cửa, như thể bóng tối cũng là thứ lây được. Mưa trở lại vào khoảng canh một, ban đầu chỉ lác đác vài hạt trên mái ngói, rồi thành màn nước đều đặn, gõ lên đá xanh nghe như hàng trăm ngón tay kiên nhẫn.

Lục Trầm nằm trên gác xép, mở mắt nhìn xà nhà. Hắn không ngủ được. Trong đầu, mặt gương trắng cứ lơ lửng mãi không chịu tan.

*Không có tên.*

Hắn thử bình tĩnh suy xét. Không có tên nghĩa là gì? Là không có linh căn, không có thọ nguyên, không có kiếp nạn? Hay là không có cả quyền được tồn tại trong sổ sách của trời? Hắn nhớ câu Ngô chấp sự lẩm bẩm: "Chó, mèo, gà, vịt cũng có." Một thiếu niên mười lăm tuổi mà đến gà vịt cũng hơn mình, hẳn là hắn cần một cuộc đàm đạo nghiêm túc với số mệnh, nếu số mệnh chịu tiếp.

Đúng lúc ấy, tiếng chuông vang lên.

*Boong.*

Lục Trầm bật dậy. Đó là tiếng chuông đồng ở miếu Thổ Địa, thứ chuông chỉ rung khi có thiên tai hoặc có người chết. Hai mươi năm nay chưa ai đánh nó.

*Boong. Boong.*

Tiếng chuông ngân dài trong mưa, loang ra khắp trấn. Rồi từ xa vọng lại tiếng chân người chạy, tiếng cổng trấn đóng sầm, tiếng xích sắt kéo lê trên đá. Cổng trấn đã khóa. Giữa đêm mưa, Ngô chấp sự hạ lệnh phong tỏa mọi lối ra vào.

Lục Trầm xuống thang gác, bước thật nhẹ. Nhà dưới tối om, sập trúc trong gian chính trống không, cái bầu rượu lăn lóc trên nền. Từ sân sau vọng lại tiếng nước chảy, cùng một thứ âm thanh khác, đều đặn, ken két.

Hắn ghé mắt qua khe cửa.

Dưới mái hiên sân sau, bên cạnh cái giếng cổ, lão Hoàng ngồi trên một chiếc ghế đẩu thấp. Lão không say. Điều đó thể hiện ngay ở tấm lưng lão, tấm lưng thẳng tắp mà suốt mười lăm năm hắn chưa từng thấy. Trước mặt lão đặt một chậu đá đựng nước, trong tay lão là một thanh đao.

Một thanh đao cũ, lưỡi dài, hơi cong, vỏ đã mục. Chẳng có gì đặc biệt, thoạt nhìn chỉ như một món sắt vụn người ta vứt xó trong kho. Nhưng khi lão kéo lưỡi đao trên đá mài, mỗi lần chạm, nước mưa rơi xuống lưỡi đao đều tách làm đôi gọn ghẽ, rơi sang hai bên, không một giọt nào bám lại.

*Ken két. Ken két.*

Lão Hoàng cúi đầu nhìn lưỡi đao, môi mấp máy một câu mà Lục Trầm nghe không rõ. Chỉ nghe được mấy chữ cuối: "…ba mươi năm rồi. Ngươi vẫn còn sắc."

Một cơn gió thổi qua, mang theo mùi mưa, mùi đất, và thoang thoảng trong đó còn có một mùi khác, mùi sắt cũ và máu khô, thứ mùi chưa bao giờ có trong quán rượu này.

Lục Trầm đứng yên sau cánh cửa. Hắn có thể đẩy cửa bước ra mà hỏi. Nhưng hắn không làm. Một phần vì hắn hiểu, nếu lão Hoàng muốn cho hắn thấy cảnh này, lão đã ngồi mài đao giữa sân trước. Phần khác, hắn sợ nếu mình hỏi, lão sẽ phải trả lời thật.

Hắn lùi lại một bước, ván sàn khẽ kêu.

Tiếng mài đao dừng lại.

— Đi ngủ. — Lão Hoàng nói, không quay đầu, giọng khàn khàn nhưng tỉnh táo hoàn toàn. — Lão tử đang mài dao thái thịt. Mai có khách.

— Thịt gì mà phải dùng đao dài một thước tám?

— Thịt kẻ say. — Lão đáp. — Đi ngủ.

Lục Trầm đứng thêm một nhịp, rồi quay lên gác. Nằm xuống, hắn nghe tiếng mài đao lại vang lên, ken két, ken két, hòa cùng tiếng mưa và tiếng chuông xa xa còn vọng lại.

Hắn nhắm mắt, nhưng sau mi mắt không phải bóng tối, mà là một vệt sáng lạnh, mảnh như sợi chỉ, vạch ngang qua màn đêm đen kịt.

Chuông đã ngừng. Trấn Thanh Thạch nằm im dưới mưa như một con thú đang nín thở.

Và ở cuối con phố đá xanh, bên ngoài cổng trấn đã khóa, một chiếc ô giấy trắng đang chậm rãi đi tới.
