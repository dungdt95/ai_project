# Chương 11: Bí Cảnh Tàng Vân

Đêm ấy, trong gian phòng nhỏ của khách điếm gần chợ Tây, bốn "người" ngồi quanh một ngọn đèn dầu, và không ai có vẻ dễ chịu.

— Ta tổng kết lại. — Lục Trầm nói. — Cổng Tàng Vân có Mệnh Giám. Mệnh Giám của ta trắng. Trắng nghĩa là dị số. Dị số thì bị bắt, hoặc ít nhất bị ngó chằm chằm. Ngoài ra, ta còn có một tấm chân dung mới, đẹp trai hơn bản cũ.

— Đẹp trai là do họa sư nịnh. — Đa Đa nói.

— Đa tạ.

*"Đơn giản thôi."* Lão Chỉ lên tiếng, giọng đầy tự tin của kẻ chưa từng phải chịu trách nhiệm cho ý kiến của mình. *"Bản tọa xuất thủ, đập nát toàn bộ gương, Mệnh Giám nào cũng thành bột. Không gương thì không soi, không soi thì không có dị số."*

— Rồi mười vạn người ở đó tìm ta tính sổ.

*"…Phương án hai. Ngươi dập đầu ba cái, bản tọa niệm chú, ngươi bay vào."*

— Ngài có chú ấy không?

*"Bản tọa đang nhớ."*

Lục Trầm quay sang Thanh Dao, người ngồi thẳng bên góc bàn, ánh đèn rọi lên hàng mi dài. Nàng đã nghe hết mà không chen ngang. Với nàng, đó là kiên nhẫn bậc nhất.

— Cô nương, tại hạ muốn nhờ cô nương làm một việc. Rất nhỏ.

— Nếu là nói dối thì không.

— Không phải nói dối. — Hắn nói. — Ngày mai, ở cổng, mệnh trang của tại hạ sẽ hiện chữ vàng. Cô nương chỉ cần nhìn, rồi nói đúng những gì mình thấy.

Nàng nhìn hắn rất lâu.

— Mệnh trang của ngươi trắng.

— Hôm nay thì trắng.

— …Đó là gian lận.

— Là vận may. — Đa Đa chen vào, mắt sáng rực. — Thẩm cô nương, người buôn bán gọi đó là "gặp thời".

Thanh Dao nghĩ rất lâu, và hắn thấy tai nàng hơi hồng.

— Ta không hỏi. — Nàng nói, từng chữ rất chậm. — Ta không hỏi nên ngươi không phải đáp. Nhưng ta sẽ không bảo là ta chưa thấy gì.

— Thế là đủ.

Đa Đa lúc này mới lôi từ trong ngực ra cuốn sổ bìa da, mở đến một trang gấp góc.

— Phần của tại hạ. Tiền gia thuê người đều ghi lại mệnh trang phó bản, phòng khi hộ viện chết thì còn biết đường đền. — Gã đọc: — "Tiền Phúc, hai mươi lăm tuổi. Mộc linh căn hạ phẩm. Thọ năm mươi hai. Hộ viện." Người này hiện đang canh kho ở Lâm Giang, cách đây ba ngàn dặm, chẳng bao giờ đặt chân tới Lạc Phong.

*"Hừ."* Lão Chỉ ngẫm nghĩ. *"Một người thật, có tên thật trong Thiên Thư. Nếu bản tọa viết đúng từng chữ…"*

— Ngài viết đúng được không?

*"Bản tọa là đệ nhất…"*

— Ngài từng viết sai chữ "thu".

*"…Lần này bản tọa viết đúng."*

---

Bảy ngày trôi qua trong tiếng người ngựa.

Đa Đa bán sạch mấy trăm tờ bản đồ, bán thêm một nghìn chiếc đấu lạp cho những kẻ lo trời mưa, rồi bán luôn tin tức về việc đấu lạp sắp lên giá. Gã còn dạy Lục Trầm cách làm mặt tròn, bằng hai cục bông nhét vào má, kèm một nét mày dày và một bộ áo vải thô.

— Ngươi nhìn ta như nhìn một cái bánh bao. — Lục Trầm nói.

— Tại hạ không dám. — Đa Đa lau mắt. — Chỉ là… trông rất có phúc.

Rạng sáng ngày thứ tám, họ đi ra thành.

Mười dặm đường sơn đạo đã kín người. Tu sĩ áo bào đủ màu, cưỡi hạc, cưỡi ngựa, có kẻ cưỡi cả một con nhện ngà to bằng cái bàn. Đám tán tu chen vai thích cánh, những môn phái nhỏ đứng thành từng nhóm, tay đặt sẵn lên chuôi kiếm, mắt liếc nhau như chó săn gặp mùi thịt. Đâu đó có kẻ đang cãi nhau vì một chỗ đứng; đâu đó có kẻ đã rút đao.

Dãy núi Tàng Vân hiện ra giữa màn sương trắng, đỉnh nhọn cắm vào mây. Dưới chân núi là một cổng đá cổ, cao chừng bảy trượng, phủ rêu xanh. Hai trụ khắc những ký tự mà mắt thường chỉ thấy là vết nứt. Phía trước, Thiên Thư Các đã dựng một dãy đài đá thấp, mười hai chiếc Mệnh Giám đồng xếp thẳng hàng, mỗi chiếc có một chấp sự áo xám đứng canh.

*"Cái cổng đá kia."* Lão Chỉ nói, giọng bỗng thấp xuống. *"Không phải của họ."*

— Sao ngài biết?

*"Rêu mọc trên đó già hơn cả Thiên Thư Các."*

Thanh Dao đã tách khỏi họ từ ven đường. Đội Thiên Thư Các đi lối riêng ở phía bên phải, bảy người áo trắng viền xám, dẫn đầu là một chấp sự trung niên mặt gầy như dao. Nàng quay đầu nhìn hắn đúng một lần. Hắn khẽ gật. Nàng quay đi.

---

Hàng người bò chậm hơn sên.

Giữa trưa, trời bắt đầu mưa lất phất, và đấu lạp của Đa Đa bán không kịp thở. Chính trong lúc gã đếm tiền, ba người lạ ngồi chung một tảng đá với họ.

— Huynh đệ, cho chúng ta tránh mưa chút, lão sẽ mua một cái nón. — Người nói là một lão già lưng còng, râu thưa, nụ cười dễ mến như ông chủ quán nước. — Lão họ Cổ, các vị cứ gọi là Cổ lão Thất. Đây là lần thứ ba lão chen vào bí cảnh.

— Lần thứ ba, vậy lão vẫn chưa chết?

— Hà hà, nhờ chuyên tránh người ta chết. — Lão Thất cười. — Luyện Khí tầng tám, nhưng nhớ cho kỹ: bí cảnh là sống nhờ chân chạy, không phải nhờ tu vi.

Bên cạnh lão là một thiếu nữ độ hai mươi, áo xanh nhạt thêu lá thuốc, tay ôm một chiếc hòm gỗ nhỏ, cứ thấy ai nhìn là cúi đầu.

— Liễu Tri Vi. — Nàng nói khẽ. — Hồi Xuân Cốc. Luyện Khí tầng bảy. Tiểu nữ… biết chút y thuật.

— Là đan sư. — Lão Thất nói. — Có nàng, gãy tay cũng đỡ gãy.

Người thứ ba là một thanh niên chừng hai mươi tám, bạch bào phai màu, mặt mũi nho nhã, cử chỉ như kẻ sinh ra để ngồi bàn trà.

— Phương Ngọc Thành, ngoại môn Bạch Vân Phái. — Y chắp tay, nụ cười vừa vặn từng tấc. — Luyện Khí tầng chín. Tiểu môn phái, không dám sánh với các vị. Lần này vào bí cảnh, chỉ mong có nhóm đồng hành tử tế.

Lục Trầm nghe tên, mặt không đổi. Hắn để ý ba điều, hoàn toàn vô tình. Một: ống tay áo bạch bào của y có mùi tro lạnh, thứ mùi người ta thường thấy ở nơi vừa thiêu giấy. Hai: lúc y cúi chào, mắt không nhìn mặt hắn mà nhìn thẳng vào đôi má phồng bông. Ba: khi y nói "đồng hành tử tế", y liếc sang tờ cáo thị dán trên cột đá đối diện, lâu hơn mức một người nên liếc.

Lục Trầm chỉ cười, một nụ cười của kẻ có phúc.

— Tại hạ Tiền Phúc. — Hắn nói. — Hộ viện. Vị này là thiếu gia nhà ta.

— Tiền Đa Đa. — Gã vươn tay, đồng thời đặt vào tay Phương Ngọc Thành một chiếc đấu lạp. — Tám văn. Quen biết thì bảy văn.

— Ngươi bán cả cho đồng đội? — Lão Thất cười lăn.

— Đồng đội cũng cần che mưa. — Đa Đa nghiêm túc.

Phương Ngọc Thành trả tiền không chút do dự, còn lấy ra một cuốn sổ nhỏ, chép từng cái tên vào trang đầu.

— Nếu vào trong gặp nhau, ta cần nhớ tên. — Y giải thích, cười hiền. — Bí cảnh không tránh được lúc ly tán.

*"Tên tuổi người ta ghi sổ,"* Lão Chỉ lẩm bẩm, *"người này khiến bản tọa nhớ đến một thứ gì đó rất khó ưa."*

*Thứ gì?* Lục Trầm nghĩ.

*"…Bản tọa đang nhớ."*

---

Đến chiều, họ tới đài đá.

Phía trước là một thanh niên có vẻ sắp ngất vì đang phải ấn tay lên gương cho cả trăm người. Lục Trầm đứng thứ tám trong hàng của chiếc gương số chín. Hắn nghe từng tiếng "tên?" "linh căn?" "qua" lặp lại như tiếng mõ, và tính toán rất nhanh từng nhịp thở.

— Này. — Tên chấp sự cạnh gương số chín quay đầu nói với đồng sự. — Nghe nói ở Thanh Thạch có một vụ, Ngô chấp sự đập gương ba lần.

— Ôi trời, đừng nhắc. Cả Các cười suốt ba tháng.

— Từ đó có lệnh mới: gương lạ thì *đổi gương*, cấm đập.

— Cấm đập.

Lục Trầm khẽ mím môi để nụ cười không lộ.

Đến lượt Đa Đa, mệnh trang hiện lên chữ vàng, chấp sự gật đầu qua. Rồi Lục Trầm bước tới, giữa tiếng rì rầm của đám đông phía sau, đặt bàn tay phải lên mặt gương lạnh buốt.

Gương trắng.

Một nhịp thở. Hai nhịp thở. Trong tay áo, mảnh giấy rung lên.

Rồi từ đầu ngón tay hắn, dòng chữ vàng bắt đầu rỉ ra như mực loang trên nước. Từng chữ hiện ra, ngay ngắn, đúng nét: *Tiền Phúc. Hai mươi lăm tuổi. Mộc linh căn hạ phẩm.* Đến chữ "thọ", mặt gương bỗng chớp lên một cái.

Tên chấp sự nhíu mày, tay đã nhấc lên.

— Đại nhân. — Lục Trầm nói, giọng hết sức ngây thơ. — Gương này hình như…

— Hỏng. — Y chép miệng, hạ tay xuống, mắt liếc sang đồng sự. — Đổi gương số mười.

Lục Trầm đổi sang chiếc gương bên cạnh. Trong tay áo, Lão Chỉ thì thào, rất nhanh, rất khẽ: *"Đã nói là bản tọa viết đúng! Là cái gương nó xoay bút!"*

Lần này, mệnh trang hiện đầy đủ. *Thọ năm mươi hai. Hộ viện.* Chấp sự cúi nhìn, ngón tay gõ gõ trên mặt bàn, rồi ngẩng đầu, nhìn thẳng vào đôi má bông phồng.

— Mặt ngươi trông… hơi lạ so với cáo thị.

— Cáo thị nào, đại nhân? — Lục Trầm hỏi.

Chấp sự quay ra nhìn tờ cáo thị, rồi nhìn hắn. Một người gầy, cằm nhọn, mắt dài; một người mặt tròn, mày dày, bộ dạng lấm lét của hộ viện chuyên canh cổng nhà giàu. Hai gương mặt chẳng có gì giống nhau, trừ… đôi mắt. Y nheo mắt.

— Khoan.

Hắn nghe sau lưng tiếng bước chân nhẹ. Một mùi hương lạnh như sương, mùi của lưỡi kiếm vừa lau sạch.

— Đại nhân.

Thanh Dao đã đứng đó, từ lúc nào hắn cũng không biết. Cả hàng tu sĩ phía sau im lặng. Chấp sự vội cúi người.

— Thẩm sư tỷ. Người này…

— Ta vừa đứng đây. — Nàng nói, nhìn thẳng vào mặt tên chấp sự, không chớp mắt. — Ta đã thấy chữ vàng hiện lên trên gương. Ta thấy rõ ràng.

Câu nói không thừa một chữ nào, không sai một chữ nào. Lục Trầm đứng yên. Hắn chợt nhận ra, nàng chưa nói chữ vàng ấy từ đâu mà ra.

— À… vâng. — Chấp sự cười gượng, vội đưa một mảnh thẻ ngọc. — Danh bài của các hạ. Cầm lấy, qua cổng.

Lục Trầm nhận thẻ. Trên mặt ngọc lạnh, ba chữ *Tiền Phúc* vừa khắc xong, còn nóng. Hắn cúi người cảm tạ, và lúc ngẩng lên, gặp ánh mắt nàng. Nàng không cười. Nhưng đôi mắt phượng ấy nhìn hắn một nhịp rất lâu, như muốn nói: *ta đã nói thật đấy.*

— Cô nương, — hắn nói rất khẽ, — thật phiền cô nương.

— Đừng lạc. — Nàng đáp.

— Câu này nên để tại hạ nói.

Nàng quay đi. Vành tai hơi đỏ.

---

Khi mặt trời đỏ au ngả xuống sau đỉnh núi, tiếng chuông cổ ngân lên. Không phải chuông của Thiên Thư Các, mà là từ chính cổng đá, từ sâu trong khối rêu xanh, một tiếng ngân trầm như tiếng thở của một con thú đã ngủ vạn năm.

Cổng đá bắt đầu sáng.

Những ký tự trên hai trụ tỏa ra thứ ánh sáng trắng sữa, không phải vàng của Thiên Thư. Đám đông nín bặt. Màn sương từ chân núi cuộn lên, uốn thành những sợi dài, chui vào khe cổng.

Rồi, giữa hàng ngàn người cùng nhích bước, Lục Trầm cảm thấy mảnh giấy trong tay áo mình nóng bừng lên. Ánh sáng trên cổng chợt tập trung. Một sợi sương mảnh, tách khỏi muôn vàn sợi khác, uốn cong qua đầu mấy trăm tu sĩ, rồi dừng lại trước mặt hắn, nhẹ nhàng như một bàn tay mời khách.

— Lục huynh. — Đa Đa thì thào, mặt tái. — Nó… chỉ vào huynh.

*"Tiểu tử."* Giọng Lão Chỉ khô khốc. *"Bản tọa nhớ ra rồi. Không phải nhớ cái cổng này. Nhớ cảm giác bước qua nó."*

Hắn bước tới. Lão Thất, Tri Vi, Phương Ngọc Thành, cũng bị cuốn đi cùng, như chiếc lá trôi theo dòng. Phía sau, giữa đám đông, hắn thoáng thấy tấm lưng trắng thẳng tắp, bị đoàn Thiên Thư Các kéo sang một cánh cổng phụ.

Nàng quay đầu lại.

Sương dâng lên, nuốt chửng mọi thứ. Trước khi bóng tối khép lại, Lão Chỉ nói thêm một câu, nhỏ như tiếng nước nhỏ vào đáy giếng.

*"Cái cổng này không phải của Thiên Thư Các. Và nó vừa nhận ra ngươi."*
