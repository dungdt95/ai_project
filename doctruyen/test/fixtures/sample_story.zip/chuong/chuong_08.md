# Chương 8: Kiếm Chỉ Yết Hầu

Lục Trầm không thấy nàng rút kiếm.

Hắn chỉ thấy bạch y thoáng qua như một vệt tuyết, và khi tầm mắt kịp bắt lại, đầu mũi kiếm đã tựa vào yết hầu hắn, lạnh buốt. Quãng cách từ bàn ăn đến quầy thu ngân dài chừng năm trượng, chen giữa là mấy chục thực khách, vậy mà không một chiếc đũa nào bị chạm đổ, không một vạt áo nào bị gió kiếm sượt qua.

Cả quán trọ im phăng phắc.

— Thiên Thư Các làm việc. — Giọng thiếu nữ không lớn, nhưng rơi vào gian sảnh như một viên đá ném xuống giếng sâu. — Người không liên quan, ra ngoài.

Mấy chục tu sĩ vừa rồi còn ồn ào, thoáng chốc đã tản đi gần hết, người nhảy cửa sổ, kẻ chui qua cửa sau, để lại một đống ghế đổ và vài chén rượu còn dở. Danh hiệu "Thiên Thư Các" trên đại lục này có sức nặng hơn bất kỳ lời đe dọa nào. Gã chủ quán gầy gò cũng đã chui tọt xuống gầm quầy, chỉ để lộ một đôi mắt kinh hoàng.

Chiếc chuông đồng trên đầu quầy rung lên *đinh* một tiếng, vì y ngồi dưới đó mà run.

Còn lại trong sảnh chỉ có ba người, và một thanh kiếm.

Lục Trầm nhìn xuống đầu mũi kiếm. Thân kiếm mỏng như băng, ánh lên sắc trắng mờ, khắc những hoa văn li ti chạy dọc từ gần chuôi đến mũi. Hắn nhận ra loại hoa văn ấy: giống hệt viền của Mệnh Giám. Hắn nuốt khan, yết hầu khẽ động, mũi kiếm theo đó rung nhẹ.

— Đừng cử động. — Nàng nói.

— Cô nương, tại hạ chỉ là người hầu…

— Ngươi không phải. — Nàng ngắt lời, thẳng thừng như một nhát chém. — Ta có thể không giỏi nhận ra đường đi. Nhưng ta nhận ra được chuyện này.

— Chuyện gì?

— Chiếc chuông vừa kêu cho mười bảy người, không kêu cho ngươi. Ta đếm rồi.

Lục Trầm không đáp. Sau lưng nàng, Tiền Đa Đa từ bàn ăn lao tới, nửa bước chân vấp phải ghế, nhưng vẫn gào lên bằng giọng mà cả đời gã chưa từng cao đến thế:

— Dừng tay! Cô nương! Buông Lục huynh ra!

Thanh Dao không quay đầu.

— Lục huynh? — Nàng lặp lại. — Vậy là ngươi không tên A Ngưu. Ngươi là Lục Trầm.

— A… không. — Đa Đa nghẹn họng. — Ý ta là… Lục… Lục lạc! Tại hạ đang gọi chuông!

— Đừng nói nữa. — Lục Trầm khẽ thở dài. — Ngươi đang hại ta.

*"Lúc nào cũng vậy."* Lão Chỉ thì thào, giọng đã run đến mức chữ nào cũng rụng nét. *"Bản tọa bảo ngươi đừng ngu xuẩn, ngươi nghe lời quá tốt, thành ra đến phiên tên mập kia ngu xuẩn thay. Tiểu tử, kiếm này… kiếm này… đây là Trúc Cơ hậu kỳ! Bản tọa cảm nhận được! Khí tức nàng như thanh kiếm đã rút ra nửa tấc, chỉ cần sơ sẩy là máu chảy ba trượng! Chạy! Mau chạy!"*

— Ngài thấy ta chạy được không?

*"Vậy… nằm xuống giả chết?"*

— Ngài định bảo ta giả chết trước mũi kiếm?

*"Đó là một chiến lược cổ xưa!"*

Hắn quyết định không tranh luận nữa.

---

Thanh Dao nhìn hắn bằng ánh mắt khó đoán.

— Lục Trầm. — Nàng nói chậm, từng chữ một. — Mười lăm tuổi. Dị số. Không có tên trong Thiên Thư. Phụng lệnh Chấp Bút Sứ, bắt sống, thưởng năm trăm linh thạch.

— Năm trăm? — Đa Đa chợt thốt lên, giọng đầy phẫn nộ. — Rẻ như vậy sao? Cô nương, Lục huynh nhà ta đáng giá ít nhất năm ngàn!

— Ngươi đang bán hắn hay đang bảo vệ hắn?

— Tại hạ… đang định giá!

Nàng không để ý. Nàng đang nhìn mũi kiếm của mình với vẻ nhíu mày, thứ vẻ nhíu mày rất nhỏ, như một vị tiên sinh chợt thấy hàng chữ viết sai trong sách thuộc lòng.

— Kỳ lạ.

— Có gì kỳ lạ? — Lục Trầm hỏi, rất khẽ.

— Kiếm ta tu là *Chiếu Mệnh Kiếm Quyết*. — Nàng nói, không chút giấu giếm, như nói chuyện với một đồng môn. — Nhìn người, đọc mệnh số, rồi kiếm đi theo sợi chỉ mệnh ấy. Trong mắt ta, mỗi người đều có một đường sáng bao quanh như dây tơ. Kiếm ta không cần ngắm. Chỉ cần theo sợi chỉ, trúng. Ta chưa từng chệch một kiếm. — Nàng nhìn thẳng vào mắt hắn. — Nhưng ở ngươi, không có sợi chỉ nào cả. Chỉ có một khoảng trống, như đứng trước một cái giếng không đáy.

Giọng nàng không có chút sợ hãi, chỉ có sự tò mò thành thật, đến nỗi Lục Trầm nhất thời không biết nên cảm thấy bị xúc phạm hay vinh dự.

— Vậy cô nương định làm gì? — Hắn hỏi.

— Ta thử xem kiếm ta có chém được ngươi không.

— Cô nương, tại hạ nghĩ…

— Không cần nghĩ. Thử.

Mũi kiếm ấn xuống, chỉ một phân.

Lục Trầm nín thở. Hắn cảm thấy lưỡi thép lạnh buốt miết trên da cổ, không đau, nhưng từng sợi lông tơ đều dựng đứng. Rồi hắn nghe tiếng thiếu nữ khẽ "ồ" một tiếng, rất nhỏ.

Không có máu.

Lưỡi kiếm đã đè lên da hắn, nhưng nó không cắt. Nó trượt, như đặt lưỡi dao lên mặt nước. Lớp da cổ hơi lõm xuống rồi lại nhô lên, nguyên vẹn, không trầy.

— Thanh kiếm này, — nàng chậm rãi nói, — rèn từ thiết Thiên Thư. Nó chỉ chém được thứ nào có ghi trong sổ. Ta chưa bao giờ nghĩ tới chuyện ngược lại.

Nàng rụt kiếm lại nửa tấc, nghiêng đầu, ngón tay trái đặt lên thân kiếm, như vị lang trung xem mạch.

— Thú vị. — Nàng thì thầm.

*"Đừng mừng!"* Lão Chỉ rít lên trong đầu hắn, giọng đã lấy lại phần nào sự sắc bén hiếm thấy. *"Kiếm không chém được ngươi, nhưng ngươi cũng chỉ là một thân thịt bằng xương. Nàng ta chỉ cần giơ một ngón tay, một cú đấm, một cái búng… Thân xác ngươi không thuộc về Thiên Thư, nhưng cũng không cứng hơn thân xác của người khác."*

— Ta biết. — Hắn đáp thầm.

*"Nàng ta thật sự rất mạnh."*

— Ta biết.

Cho nên, Lục Trầm làm điều duy nhất một kẻ yếu có thể làm trước một cường giả: nói chuyện.

---

— Cô nương. — Hắn mở lời, giọng bình thản, thậm chí hơi lười biếng, như người đang bàn chuyện thời tiết. — Tại hạ có ba câu muốn nói. Xin cô nương nghe xong rồi hẵng quyết định bẻ cổ tại hạ.

Thanh Dao nhíu mày.

— Ngươi biết ta có thể bẻ cổ ngươi?

— Cô nương đã nói thế qua ánh mắt từ nãy. Thiết Thiên Thư không cắt được tại hạ, nhưng tay cô nương thì được. — Hắn dừng một chút. — Câu thứ nhất. Cô nương đã đi lạc ba ngày.

— Ta không…

— Thôn của lão Từ cách quán này ba ngày đường. Thanh Thạch nằm phía bắc thôn, còn cô nương đi về phía nam. Nếu cô nương vẫn tin rằng "mình đang đi đúng", thì tại hạ xin mạn phép nói, cô nương hiện cách Thanh Thạch năm ngày đường, theo đúng hướng ngược lại.

Thiếu nữ im lặng.

Đa Đa há hốc mồm. Lão Chỉ thì thầm đầy bội phục: *"Hắn dám nói thẳng như thế."*

— Làm sao ngươi biết ta đi từ thôn lão Từ? — Nàng hỏi, giọng không hề tức giận.

— Lão Từ kể. Cô nương hỏi đường, lão chỉ hướng bắc, cô nương nói "đa tạ" rồi đi nam.

— Ta nhớ rõ đường mà.

— Vâng. Có lẽ cô nương nhớ rất rõ. Chỉ là thế gian có chút khác với trí nhớ của cô nương.

Gương mặt nàng không biến sắc, nhưng vành tai bên trái chậm rãi ửng hồng.

— Câu thứ hai. — Lục Trầm nói tiếp. — Giấy truy nã ghi "bắt sống". Thiên Thư Các cần tại hạ còn sống. Mà họ cần một kẻ không tên còn sống, tất nhiên không phải vì lòng từ bi.

Nàng im lặng lâu hơn.

— Ta không biết lý do. — Nàng thành thật nói. — Ta chỉ nhận lệnh.

— Cô nương thật thà quá.

— Ta không thích nói dối.

Lục Trầm gật đầu, trong lòng thầm ghi nhớ điều ấy. Một người không biết nói dối là một kẻ đối thoại nguy hiểm, nhưng cũng là kẻ dễ nói chuyện nhất.

— Câu thứ ba. — Hắn cất giọng, bỗng thấp xuống một chút, lần đầu tiên không mang ý đùa cợt. — Cô nương có muốn biết, vì sao kiếm của cô nương không giết được ta không?

---

Trong sảnh trọ, tiếng nến cháy bật tách rất khẽ.

Đa Đa quên cả thở. Từ gầm quầy, gã chủ quán thò đầu lên nhìn, rồi bị chuông đồng reo lên *đinh*, y giật mình lại chui xuống.

Thanh Dao hạ mũi kiếm xuống nửa thước, nhưng tay vẫn không rời chuôi.

— Ngươi biết?

— Tại hạ biết một phần. — Lục Trầm đáp. — Không phải toàn bộ.

Hắn đang đánh cược. Hắn không biết vì sao kiếm nàng không cắt được hắn, chỉ biết đại khái điều Lão Chỉ vừa nói. Nhưng hắn biết một điều khác: người ta có thể quên một lời đe dọa, rất khó quên thứ mình không giải thích nổi.

— Cô nương nói kiếm của cô nương đi theo sợi chỉ mệnh. — Hắn nói. — Sợi chỉ ấy do Thiên Thư dệt nên. Còn nơi tại hạ đứng thì không có dây. Cho nên chuyện này không phải do tại hạ mạnh, mà là do cô nương chọn nhầm cách để giết.

— Vậy ta chọn cách khác. — Thanh Dao nói.

— Vâng. Nhưng cô nương sẽ mãi mãi không biết lý do. Nếu cô nương bẻ cổ tại hạ rồi mang về Thiên Thư Các, ai sẽ giải thích cho cô nương?

— Hàn đại nhân.

— Người nói giết người là "từ bi", liệu có nói thật cho cô nương chuyện mà chính ngài ấy muốn giấu?

Nàng ngẩng lên.

— Ngươi gặp Hàn đại nhân?

— Gặp một lần. — Hắn mỉm cười nhạt. — Ngài ấy rất lịch sự. Lịch sự đến mức quán rượu của người nuôi tại hạ không còn nữa.

Nàng nhìn hắn, và trong đôi mắt phượng lạnh ấy, một thứ gì đó chuyển động rất chậm. Không phải thương cảm, mà là *nghi hoặc*, loại nghi hoặc của người lần đầu tiên nghe thấy một kẽ hở trong bức tường mà mình tin là kín.

— Ta chưa nói ta tin ngươi. — Nàng nói.

— Tại hạ cũng chưa dám xin cô nương tin.

— Ta sẽ không bẻ cổ ngươi ngay bây giờ.

— Tại hạ vô cùng biết ơn.

— Đừng biết ơn. Ta chỉ… — Nàng ngập ngừng, lần đầu tiên tìm không ra từ thích hợp, sau cùng nói thật lòng: — Ta muốn biết.

---

Đúng lúc ấy, Tiền Đa Đa không chịu nổi nữa.

Gã nuốt khan, nhón từng bước nhích lại, rồi bất thình lình chen mình đứng chắn trước mặt Lục Trầm, hai tay dang rộng, bụng ưỡn tròn như một cánh cửa thịt.

— Cô nương! Muốn giết Lục huynh, trước hết hãy giết ta! Ta thọ tám mươi, mệnh trang ghi rõ ràng! Kiếm của cô nương chém ta thì chắc chắn trượt, vì Thiên Thư không thể sai!

Thanh Dao nhìn bụng gã, rồi nhìn mặt gã.

— Ta không định giết ngươi.

— Hả?

— Ngươi che đèn. — Nàng nói. — Tránh ra.

— …Tại hạ không tránh! Tại hạ… tại hạ có tiền! Tám ngàn linh thạch! Chín ngàn! Cô nương cứ nói giá!

— Ta không thiếu linh thạch.

— Vậy cô nương thiếu gì?

Thiếu nữ im lặng một thoáng.

— Bản đồ. — Nàng đáp.

Đa Đa đứng hình. Phía sau gã, Lục Trầm vội đưa tay che miệng, vai khẽ run, rồi ho thật lớn để giấu tiếng cười. Từ gầm quầy, gã chủ quán dù đang run lẩy bẩy cũng không nhịn nổi mà phát ra một tiếng "phụt" nhỏ xíu.

*Đinh.* Chuông đồng reo.

Thanh Dao nhìn về phía quầy, mặt không đổi sắc, nhưng vành tai lại hồng thêm một chút.

— Ta chỉ nói thật. — Nàng cứng nhắc nói.

— Vâng, vâng, rất thật! — Đa Đa vội gật đầu như giã gạo. — Tại hạ sẽ vẽ cho cô nương bản đồ! Loại có mũi tên! Còn thêm chữ lớn!

— Câm miệng. — Lục Trầm khẽ nói, nhưng khóe môi vẫn còn nhếch.

Thanh Dao thu kiếm vào vỏ, tiếng thép rít nhẹ rất êm.

Lục Trầm không dám thở phào. Hắn biết thiếu nữ trước mặt không hề tha cho hắn, nàng chỉ đang đặt một món đồ khó hiểu lên giá, để xem xét sau.

— Ngươi có một nén hương. — Nàng nói. — Kể cho ta nghe, mọi thứ về việc ngươi không có tên. Nếu ta thấy hợp lý, ngươi sống thêm một ngày. Nếu không…

— Nếu không, cô nương bẻ cổ tại hạ.

— Không. — Nàng nhìn hắn, gương mặt thanh lãnh không có chút biểu cảm. — Ta sẽ trói ngươi lại, và bắt ngươi đi cùng ta đến khi ta tìm ra đường đến Lạc Phong.

Lục Trầm nhìn nàng một lúc. Hắn thật sự không biết nên vui hay nên khóc.

*"Tiểu tử."* Lão Chỉ thở dài thườn thượt. *"Ta e rằng bản đồ không phải thứ duy nhất nàng ta thiếu."*
