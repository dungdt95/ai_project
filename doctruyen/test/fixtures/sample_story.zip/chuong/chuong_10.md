# Chương 10: Thành Lạc Phong

Sáng hôm sau, con hạc giấy trắng đáp xuống vai Thanh Dao đúng lúc nàng đang nhìn chằm chằm vào nồi nước sôi mà không dám động tay.

Lục Trầm đã lăn mình ngồi dậy, tay theo phản xạ chạm vào ống tay áo nơi Lão Chỉ nằm. Nhưng thiếu nữ chỉ thản nhiên đưa ngón tay chạm vào đầu hạc. Con hạc mở mỏ nhả ra một cuộn giấy nhỏ, rồi hóa thành một nắm tro trắng bay đi theo gió.

— Truyền thư hạc của Thiên Thư Các. — Nàng nói, giọng không giấu giếm. — Không phải Chỉ Hạc Truy Tung. Nó chỉ tìm ta, không tìm ngươi.

*"Ra là hạc truyền tin."* Lão Chỉ thở phào, cứ như chính nó đã nín thở suốt đêm. *"Đêm qua bản tọa cứ tưởng…"*

— Ngài đã ngáy suốt đêm.

*"Là nhập định!"*

Nàng đọc thư, nét mặt không đổi, nhưng ngón tay giữ cuộn giấy hơi siết lại.

— Chi các Lạc Phong triệu ta về báo cáo. Đúng ba ngày nữa phải có mặt. — Nàng nhìn hắn, thẳng thắn như thường lệ. — Còn có một điều khác. Hàn đại nhân đã mười ngày không gửi tin về. Chi các nói, sau khi đến Thanh Thạch, ngài ấy… *mất liên lạc*.

Đa Đa đang gặm dở chiếc bánh bao khô, nghe vậy bỗng ngừng nhai. Lục Trầm không nói gì. Hắn nhớ tiếng nổ trầm đục ở chân núi, và vết nứt dài hàng chục trượng rạch qua đất.

— Ngài ấy là Kim Đan. — Thanh Dao nói thêm, như tự nhủ. — Mất liên lạc không có nghĩa là chết.

— Cũng không có nghĩa là sống. — Lục Trầm đáp.

— Ta biết.

Hai người nhìn nhau trong một nhịp thở. Đó là lần đầu tiên hắn thấy nàng không đáp lại bằng một câu thẳng như kiếm.

---

Hai ngày sau, Lục Trầm phát hiện mình có thêm một công việc mới: làm la bàn.

Thanh Dao đi rất nhanh, rất thẳng, và hoàn toàn mù tịt về mọi ngã rẽ. Sáng ngày đầu, nàng suýt dẫn cả nhóm đi thẳng xuống một vực sâu, vì nàng khăng khăng rằng "đường nào cũng đến được". Chiều ngày đầu, nàng bước vào một bãi lầy, bảo rằng "đây là đường tắt". Tối ngày đầu, Lục Trầm dùng một sợi dây buộc cổ tay nàng vào cổ tay mình, để tiện kéo lại. Nàng nhìn sợi dây hồi lâu, rồi hỏi:

— Đây là hình phạt?

— Đây là lòng từ bi. — Hắn đáp.

Nàng im lặng một chốc.

— Nghe giống lời Hàn đại nhân.

— …Tại hạ thu hồi.

Sợi dây ấy được tháo ra sau nửa canh giờ, vì Đa Đa chê nhìn "như hai kẻ tù nhân dẫn nhau đi thi". Nhưng từ đó, thiếu nữ có một thói quen mới: mỗi lần đến ngã rẽ, nàng liếc nhìn hắn, chờ hắn gật hoặc lắc, rồi mới đi.

Ngày thứ hai, họ đến Lạc Phong.

---

Lạc Phong là một tòa thành lớn nằm giữa thung lũng, ba mặt tựa núi, một mặt hướng ra con sông Bạch Lộ. Tường thành xám cao ba trượng, cổng thành dựng ngay trên quan đạo, chen chúc hàng trăm kẻ chờ vào. Nghe nói năm ngày nay, người đổ về nơi này nhiều gấp ba lần thường lệ.

Lục Trầm đứng ở cuối hàng, nhìn lính gác đang kiểm tra từng người. Cổng thành treo hai chiếc Báo Mệnh Linh to bằng cái chậu, mỗi người đi qua lại có tiếng chuông kêu "boong".

*"Chuông to như thế."* Lão Chỉ nói. *"Ngươi định làm gì? Chui qua?"*

— Ta chưa nghĩ ra.

Hàng người nhích dần. Thanh Dao đột nhiên bước lên một bước, đứng cạnh hắn.

— Ngươi lo lắng.

— Tại hạ chỉ đang nhìn cái chuông.

— Nó kêu, rồi ngươi bị bắt. Không kêu, thì ngươi bị nghi.

— Cô nương hiểu rõ tình cảnh của tại hạ lắm.

— Ta không ngốc. — Nàng nói. — Đi theo ta.

Nàng nắm lấy cổ tay áo hắn, kéo lên đầu hàng. Lính gác nhìn thấy tấm lệnh bài bằng bạch ngọc nàng giơ ra, mặt biến sắc, vội vàng cúi người:

— Thì ra là Thẩm đại nhân của Thiên Thư Các…

— Hai người này là tùy tùng của ta. — Thanh Dao nói, giọng lạnh như tuyết đóng. — Không cần kiểm.

Hai tên lính nhìn nhau. Một người liếc về phía chuông, người kia kéo vạt áo y, rồi cả hai cùng cúi đầu nói:

— Mời đại nhân vào thành.

Chuông "boong" hai tiếng cho Thanh Dao và Đa Đa. Đối với Lục Trầm, nó im lặng như thể ai đó đã nhét một nắm bông vào lưỡi chuông. Tên lính trẻ nhìn chiếc chuông, mặt cau lại, nhưng không dám hé môi.

Qua cổng, Lục Trầm khẽ nói:

— Cô nương vừa làm một việc rất nguy hiểm.

— Ta nói thật: các ngươi là tùy tùng của ta. — Nàng nghĩ một chút. — Chỉ là *chưa nói hết*.

*"Cái đầu óc ngay thẳng này,"* Lão Chỉ cảm thán, *"hễ rẽ một chút là cong thành đường mới."*

---

Lạc Phong rộn rịp hơn hắn tưởng.

Trên phố, tu sĩ đủ kiểu, áo xanh áo bạc chen vai thích cánh. Hai bên đường đều là tiệm đan dược, phù lục, pháp khí rẻ tiền, sạp nào cũng đua nhau rao to: "Phù bảo mệnh đây! Vào Tàng Vân phải có!", "Đan hồi khí giá hời!", "Bản đồ bí cảnh, hàng thật giá thật!"

Tiền Đa Đa dừng lại giữa đường, bất động.

— Lục huynh. — Gã nói bằng giọng của người đã được hiển linh. — Tại hạ… ngửi thấy mùi tiền.

— Đó là mùi mồ hôi.

— Mồ hôi cũng là mùi tiền. Tại hạ đi một lát.

— Ngươi đi đâu?

— Mua.

Một canh giờ sau, gã quay về với bộ mặt hớn hở của kẻ vừa thắng một canh bạc lớn.

— Tại hạ vừa mua. — Gã tuyên bố. — Trọn gói. Cả kho hàng của một lão thương nhân vải bố đang phá sản. Nón lá, áo tơi, lều vải. Tất cả giá đáy.

— Ngươi mua đấu lạp làm gì?

— Tàng Vân nằm trong núi, mưa gió thất thường. — Đa Đa nháy mắt. — Tu sĩ dẫu có linh lực hộ thể, ai chẳng muốn khô ráo? Ngày mai giá đấu lạp sẽ gấp ba.

Lục Trầm nhìn gã hồi lâu.

— Ngươi có thật chỉ mười sáu tuổi không?

— Phụ thân dạy từ ba tuổi.

— Còn gì nữa?

— Còn bản đồ. — Gã rút từ trong ngực ra một xấp giấy, mỗi tờ vẽ nguệch ngoạc những đường cong, ký hiệu, mũi tên, và cả những dòng chữ rất to như "ĐI THẲNG", "RẼ TRÁI", "ĐỪNG CHẾT". — Tại hạ nghĩ đến yêu cầu của Thẩm cô nương. Bản đồ có mũi tên. Mười linh thạch một tờ.

— Ngươi đến Lạc Phong bao giờ chưa?

— Chưa. Nhưng tại hạ đoán mò rất có căn cứ.

Họ đi ngang một sạp đồ cổ ven đường, bày hỗn độn đồ sứ, ngọc khí và một tấm bia con khắc cổ ngữ, bảng hiệu viết to: *"Thượng cổ di vật, từ Tàng Vân bí cảnh!"* Lão Chỉ lập tức hừ lạnh:

*"Giả. Cái bình này, nét men thế kia, bản tọa năm xưa tiện tay viết một chữ lên cũng đẹp hơn!"*

— Ngài nhớ ra rồi?

*"…Bản tọa chỉ nói thế thôi."*

Hắn bước qua. Nhưng khi đi ngang tấm bia con, mảnh giấy trong tay áo hắn bất chợt nóng lên, rất nhẹ, như tiếng gọi từ một chốn xa xôi. Lão Chỉ im bặt. Hắn cũng không hỏi.

---

Lục Trầm phát hiện nàng biến mất vào lúc hoàng hôn.

Họ vừa tìm xong một khách điếm nhỏ gần chợ Tây, thuê hai gian phòng. Thanh Dao nói muốn ra mua một thỏi mực, vì nghiên mực mang theo đã khô. Tiệm mực nằm ngay đầu phố, cách khách điếm ba mươi bước chân. Đa Đa đã giảng giải ba lần.

— Ta nhớ rồi. — Nàng nói. — Ta đi thẳng.

Nửa nén hương sau, nàng chưa về.

Một nén hương sau, Lục Trầm đã đứng ngoài cửa tiệm mực, trong khi chủ tiệm khẳng định chưa từng có nữ tử nào áo trắng đeo kiếm bước vào.

Đa Đa vò đầu:

— Chợ rộng thế này, biết đi đâu mà tìm?

— Dễ thôi. — Lục Trầm nói. — Nàng làm ngược lại mọi lời chỉ đường. Ngươi bảo thẳng, nàng sẽ rẽ.

Hắn hỏi thăm hết dãy sạp này đến dãy sạp khác. Một lão thợ rèn bán đồ sắt cười nói:

— Cô nương áo trắng đeo kiếm? Có, vừa đi qua. Bảo muốn tìm "thứ gì đó thơm thơm". Lão chỉ nàng hướng chợ ăn, nàng đi hướng ngược lại. Giờ chắc là chợ ăn đấy.

*"Ngược của ngược."* Lão Chỉ thán phục. *"Cô nương này là một kỳ nhân."*

Hắn tìm thấy nàng ở cuối một con hẻm nhỏ bên chợ ăn, đứng bất động trước một sạp bán mứt quả.

Chủ sạp là một lão nhân tóc bạc, đang khổ sở cố giải thích điều gì đó. Thiếu nữ áo trắng đứng trước mặt lão, tay cầm một chiếc lá vàng mỏng, đưa ra nghiêm trang như đưa công văn. Trước sạp, trẻ con xúm lại xem vị cô nương lạ lùng này.

— Ta muốn thứ này. — Nàng nói, chỉ vào một xâu quả đỏ bọc đường, ánh lên trong nắng chiều. — Đây có đủ không?

— Cô nương, một lá vàng có thể mua cả sạp này!

— Vậy lấy cả sạp.

— Không cần cả sạp, cô nương! Chỉ một xâu thôi, mười văn tiền!

— Ta không có văn tiền.

Lục Trầm bước tới, đặt mười văn tiền lên sạp, nhận lấy một xâu mứt, đưa tận tay thiếu nữ. Nàng quay lại, thấy hắn, mắt hơi mở to.

— Ngươi tìm được ta.

— Cô nương đi hướng ngược. Dễ thôi.

— Ta không lạc. — Nàng nói, giọng không chút chắc chắn. — Ta chỉ… theo mùi.

— Vâng. Mùi mứt quả.

Nàng im lặng nhìn xâu quả đỏ trong tay mình, rồi cắn thử một miếng, rất nhỏ, như thử độc.

Lớp đường vỡ giòn tan dưới răng. Trong khoảnh khắc ấy, gương mặt lạnh như băng của nàng đổi sắc, rất nhẹ, đôi mắt mở to, rồi dịu đi, như một người vừa nhìn thấy một thứ chưa từng tồn tại trong thế giới của mình.

— Ngọt. — Nàng nói.

— Mứt thường thế.

— Ta chưa từng ăn.

Hắn nhìn nàng. Một đứa trẻ lớn lên trong Thiên Thư Các, chưa từng nếm vị ngọt của đường, chưa từng mang tiền, chưa từng nấu một chén cháo.

— Vậy cô nương cứ ăn. — Hắn nói. — Chỗ này còn nhiều xâu.

Nàng gật đầu, ăn thêm một miếng, rồi lặng lẽ bước theo hắn, không nói gì, chỉ chầm chậm đi cạnh. Rất gần. Gần đủ để nếu hắn đưa tay, hắn sẽ chạm vào tay áo nàng. Ở khoảng cách ấy, nàng không rút gương ra. Nhưng cặp mắt nàng, trong khoảnh khắc nào đó, liếc xuống thật nhanh về phía ống tay áo, như đang muốn kiểm tra một điều, rồi lại thôi.

---

Sáng hôm sau, Thanh Dao đến chi các. Thiên Thư Các tại Lạc Phong là một tòa bạch tháp bảy tầng, cổng đóng kín, bốn tên chấp sự áo xám đứng gác. Nàng một mình đi vào, Lục Trầm và Đa Đa đợi trong quán trà đối diện, chọn chỗ góc khuất cạnh một cây hòe.

Nàng ra sau chừng nửa canh giờ, mặt không biểu cảm.

— Ta đã báo. — Nàng nói, ngồi xuống. — Ta nói đang truy theo manh mối ở phía nam, chưa xác nhận mục tiêu.

— Đó là nói dối. — Đa Đa thì thầm.

— Không. — Nàng đáp. — Ta chưa xác nhận. Ta chỉ… đang xác nhận.

— Nửa thật nửa giả. — Lục Trầm nhận xét. — Cô nương tiến bộ nhanh.

— Câm miệng.

— Vâng.

Nàng uống cạn chén trà, đặt xuống, giọng hạ thấp:

— Chi các đã nhận tin. Bí cảnh Tàng Vân sẽ mở sau bảy ngày nữa, ở dãy núi ngoài thành mười dặm. Thiên Thư Các sẽ cử người vào. Ta nằm trong danh sách. — Nàng dừng một nhịp. — Hàn đại nhân vẫn chưa có tin tức.

Lục Trầm gật đầu chậm rãi, không nói gì. Hắn đang nhìn qua cửa sổ quán trà, ra phía bức tường đối diện chi các, nơi một tờ cáo thị mới tinh vừa được dán lên, giấy trắng, mực đen, hai tên lính đang vuốt cho phẳng.

Hắn đứng dậy bước ra, Thanh Dao bước theo.

Tờ giấy ghi hai điều. Điều thứ nhất, trong bức chân dung mới tinh, đã không còn là khuôn mặt tròn của Đa Đa. Người trong tranh gầy, cằm nhọn, đôi mắt dài, và đang nhìn thẳng ra phía hắn, giống đến lạnh người. Phía dưới, một dòng chữ nhỏ: *"Phụng lệnh Thiên Thư Các. Thưởng gấp mười."*

Điều thứ hai nằm ở một tờ giấy khác ngay bên cạnh, mép giấy còn ướt keo:

**QUY ĐỊNH VÀO TÀNG VÂN BÍ CẢNH.**
**MỌI NGƯỜI TRƯỚC KHI VÀO PHẢI SOI MỆNH GIÁM TẠI CỔNG, XÁC MINH TÊN TRONG THIÊN THƯ.**
**KẺ KHÔNG CÓ TÊN, KHÔNG ĐƯỢC VÀO.**

Lục Trầm nhìn dòng chữ ấy rất lâu. Trong tay áo hắn, mảnh giấy nóng lên, nóng rực, như tiếng gọi không thể làm ngơ.

— Lục huynh… — Đa Đa nuốt khan.

— Ta biết.

Thanh Dao đứng sau lưng hắn, khoảng cách chưa đầy một trượng. Nàng không rút gương ra, nàng cũng không cần.

— Ngươi không có tên. — Nàng nói khẽ.

— Ta biết. — Lục Trầm đáp, mắt không rời tờ giấy. — Nhưng còn có một chuyện tệ hơn nữa, cô nương ạ. Ta có cảm giác, ta *phải* vào đó.

Nàng nhíu mày, nhưng hắn không giải thích thêm. Hắn chỉ lặng lẽ siết chặt ống tay áo, nơi mảnh giấy vẫn nóng ran như một trái tim đang gõ nhịp vào cửa, và tự hỏi một mảnh giấy không nhớ nổi tên mình, vì sao lại nhớ đường về một bí cảnh vạn năm.
