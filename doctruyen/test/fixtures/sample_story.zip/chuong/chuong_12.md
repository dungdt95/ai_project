# Chương 12: Bia Đá Không Chữ

Sương tan, và họ đứng giữa một khu rừng đá.

Hàng trăm cột đá xám dựng thẳng lên trời, cao thấp không đều, thân phủ rêu và dây leo trắng. Trời bên trên không có mặt trời, chỉ một dải mây sáng đục như sữa. Dưới chân, mặt đất lát những phiến đá vỡ, ngàn năm không ai dọn.

— Ly tán rồi. — Lão Thất lẩm bẩm, đếm đầu người. — Năm. May mà chỉ lạc mất những kẻ không quen biết.

— Thẩm cô nương… — Đa Đa khẽ nói.

— Nàng sẽ không sao. — Lục Trầm đáp. — Người đáng lo là kẻ phải đi tìm nàng.

Lão Thất chép miệng, vẻ như đã từng thấy nhiều cảnh tương tự, rồi chống gậy dạy dỗ ba điều quy củ của kẻ sống sót: đừng đi nhanh, đừng nhặt thứ gì rơi trên đường, và tuyệt đối đừng đáp lại tiếng ai gọi mình trong sương.

Phương Ngọc Thành mỉm cười tán thưởng, rồi lấy cuốn sổ nhỏ ra.

— Chư vị. Bí cảnh này, ta nghe sư môn kể lại, có nhiều chỗ chỉ đi được bốn năm người. Để phòng ngộ nhỡ, chúng ta lập một cái khế đồng hành: ai bỏ rơi bạn, người ấy chịu phạt.

— Khế gì? — Đa Đa cảnh giác, giọng của kẻ vừa nghe chữ "khế" đã sờ vào túi tiền.

— Không tốn một đồng. Chỉ điểm chỉ, mỗi người đặt dấu máu cạnh tên mình. — Y nói, giọng ôn hòa. — Tâm giao với nhau, tâm phục với nhau.

Lão Thất gãi cằm. Tri Vi nhìn sang Lục Trầm, vẻ chờ đợi. Lục Trầm không nói gì. Hắn thấy trang giấy trong sổ ghi đủ năm cái tên, và cạnh mỗi tên là một ô trống nhỏ.

*"Tiểu tử."* Lão Chỉ thì thầm. *"Chữ viết rất đẹp. Quá đẹp. Bản tọa không thích người nào viết chữ ngay ngắn đến thế."*

*Ngài ghét ai viết đẹp hơn ngài.*

*"Chính xác."*

Phương Ngọc Thành điểm chỉ trước, nhanh đến mức Lục Trầm chỉ kịp thấy đầu ngón tay y chạm giấy mà không dính chút đỏ nào. Hắn bước lên sau, nặn một giọt máu từ đầu ngón tay, chấm xuống cạnh hai chữ *Tiền Phúc*. Giọt máu nằm trên giấy một chốc, không thấm, không loang, như thể trang giấy không muốn chạm vào nó. Phương Ngọc Thành chớp mắt.

— Huyết khí hơi yếu. — Y cười, đóng sổ. — Thiếu niên còn nhỏ, không sao.

---

Họ đi suốt buổi sáng.

Đi cùng bí cảnh là đi cùng sự im lặng. Gió luồn qua rừng đá rít lên những tiếng khẽ như người thở dài. Đôi khi, dưới chân có xương trắng, và cả một đoạn kiếm gãy cắm giữa kẽ đá. Tri Vi dừng lại bên một bụi cỏ xanh mướt, hái hai lá nhỏ, lẩm bẩm gì đó với chúng, rồi mới cất vào hòm. Lão Thất kể chuyện lần trước vào Hàn Vân Động, y mất ba ngón chân vì chui qua hang chật; Đa Đa kể chuyện bán nón; Phương Ngọc Thành ít nói, đi cuối cùng, bước nhẹ như mèo.

Đến trưa, Lục Trầm nhận ra mình đang dẫn đường.

Không phải hắn chọn lối. Mảnh giấy trong tay áo hắn cứ nóng bên này, mát bên kia, chỉ dẫn hắn bước về phía mát hơn. Hắn viện cớ "ta ngửi thấy mùi nước", lão Thất tin ngay, vì dưới rừng đá quả thật có suối, nhưng lão không biết Lục Trầm chẳng bao giờ có cái mũi tốt đến thế.

Đúng lúc ấy, từ sau một cột đá, có tiếng gọi.

— Lục Trầm.

Giọng trong, lạnh, quen thuộc. Cả nhóm khựng lại. Đa Đa quay đầu, mắt sáng lên.

— Thẩm cô…

— Đừng đáp! — Lão Thất giữ chặt vai gã. — Là vân hồ. Nó bắt chước giọng nói. Ai đáp thì bị dẫn đi mất.

Giọng nói lại vang lên, lần này gần hơn.

— Lục Trầm. Ta không lạc.

Lục Trầm nhắm mắt thở ra một hơi. Hắn đã nghe một vạn lần câu này.

— Đó không phải nàng. — Hắn nói.

— Sao huynh chắc? — Tri Vi thì thầm.

— Nàng thật sẽ nói câu ấy, rồi hướng về phía ngược lại.

Tiếng gọi tắt phụt. Từ sau cột đá, một bóng trắng như sương lao ra, bốn năm cái nữa theo sau, mõm dài, đuôi xòe như đám khói cuộn, đôi mắt vàng như hai hạt đèn. Lão Thất vung gậy. Tri Vi ném ra một nắm bột xanh, tuôn khói ngọt. Đa Đa nhảy lên lưng Lục Trầm.

Phương Ngọc Thành chỉ giơ tay.

Y không rút kiếm. Thanh kiếm tự bật khỏi vỏ như một tia chớp lạnh, chém ngang một đường. Ba con vân hồ rơi xuống thành ba làn khói tan, tiếng kêu im bặt. Con còn lại quay đầu, chạy mất vào sương.

— Nhanh quá. — Lão Thất trầm trồ. — Phương huynh, ngươi chắc chỉ ngoại môn thôi sao?

— Ngoại môn cũng phải ăn cơm. — Phương Ngọc Thành thu kiếm, cười khiêm tốn. — May là kiếm của ta nhanh hơn miệng ta.

Lục Trầm nhìn lưỡi kiếm đang lặng lẽ trở về vỏ. Thanh kiếm quá sạch. Trong một đoàn người vừa chặt mấy con yêu thú, y không dính một giọt bụi. Hắn không nói gì, chỉ ghi nhớ.

---

Họ tìm thấy tấm bia lúc chiều.

Nó nằm giữa một khoảng trống tròn của rừng đá, mọc lên như một ngón tay chỉ trời. Cao ba trượng, rộng hơn một sải tay, mặt đá xám nhẵn bóng, không có một nét chạm khắc. Dưới chân bia là một nền đá tròn phủ rêu, và quanh nền trống trải, không một xương cốt.

— Bia vô tự. — Lão Thất liếc qua, xua tay. — Có đầy trong các bí cảnh cổ. Đá chết, không thờ ai, không canh ai. Đi tiếp thôi.

— Chúng ta nghỉ một chốc. — Phương Ngọc Thành nói, nhanh hơn nhịp nói thường của y. — Phía trước còn khá xa. Ta thấy… nơi này yên ổn.

Y nói vậy, mắt lại chẳng nhìn tấm bia mà nhìn về hướng ngược lại, về phía một cái khe giữa hai cột đá, nơi sương dày đặc nhất.

Lục Trầm không nói gì. Hắn chỉ bước tới.

Mảnh giấy trong tay áo hắn đã nóng đến mức gần như bỏng da. Đa Đa chạy theo, chợt thấy sắc mặt hắn khác thường.

— Lục huynh?

— Ngươi cùng lão Thất đi tìm nước. — Hắn nói, mắt không rời tấm bia. — Cho ta một nén hương.

Gã định cãi, nhưng nhìn thần sắc hắn, gã im, kéo lão Thất đi. Tri Vi ngồi xuống nền đá nghỉ, mở hòm thuốc. Phương Ngọc Thành cũng ngồi, nhưng đúng chỗ có thể nhìn thấy tấm lưng của Lục Trầm.

Hắn đặt lòng bàn tay phải lên mặt bia.

Đá lạnh buốt. Lạnh hơn cả lòng giếng chưa ai chạm tới.

Một nhịp thở. Hai nhịp thở.

Rồi từ chỗ bàn tay hắn đặt, một vệt nhạt hiện ra, không phải vàng, cũng không đen, mà là *trắng*, thứ trắng nhạt của vết nước đọng trên giấy cũ. Từng nét chữ nổi lên, chậm chạp, lan ra khắp mặt bia theo từng hàng thẳng. Chữ cổ triện, rất lớn, nét thanh mà sắc như đao khắc.

*"Cái này…"* Giọng Lão Chỉ run. *"Tiểu tử, đừng buông tay. Đọc từ trên xuống."*

Tên đầu tiên khắc rất sâu: **Tư Đồ Hoài Chỉ**. Bên cạnh một dòng nhỏ: *Kẻ mở trang.*

Tên thứ hai: **Ôn Cửu Nương**. *Viết bằng máu.*

Tên thứ ba: **Thạch Bất Ngôn**. *Viết không lời.*

Tên thứ tư, thứ năm, thứ sáu: **Lăng Hư Tử**, **Diệp Trường Ca**, **Ninh Vô Hối**.

Đến tên thứ bảy, hắn dừng.

Chỗ đó không còn chữ. Ai đó đã cạo sạch mặt đá, chỉ để lại một vệt dài rạch chéo từ trên xuống, sắc, thẳng, sâu đến thấu xương bia, như một nhát chém. Lục Trầm nhìn nó khá lâu. Hắn không biết vì sao tim mình lại đập mạnh như vậy.

Tên thứ tám: **Quan Nguyệt Nhi**. Tên thứ chín: **Mặc Trì**.

Rồi, ở dưới cùng, một khoảng trống rộng bằng đúng một hàng chữ. Cạnh khoảng trống, một dòng chú nhỏ, mờ như sắp tan:

*Chín người vào trang. Một người ra, mang theo bút.*

Và dưới nữa, sát chân bia, ba chữ cổ triện lớn đến mức hắn nhận ra ngay, vì chúng đã từng hiện trên cánh tay hắn vào đêm thứ ba trong sơn động:

**VỊ CHUNG QUYỂN.**

Lục Trầm đứng sững, và cảm thấy máu mình chảy chậm lại.

Dưới chữ ấy còn một dòng:

*Hậu lai giả, tục thư.*

Kẻ đến sau, viết tiếp.

---

— Vạn năm. — Lão Chỉ nói. Giọng nó không còn kiêu ngạo, không còn khoác lác. — Những cái tên này, vạn năm trước. Bản tọa… bản tọa biết cách bia này khắc. Là triện thể của người xưa ở "Trang Thứ Nhất", chữ chỉ hiện với người…

*Với người không có tên.* Hắn tiếp.

*"Phải."*

*Những người này đều như ta?*

*"Họ đều là dị số. Họ không tên trong Thiên Thư. Họ…"* Lão Chỉ nghẹn lại. *"Tư Đồ… Hoài… Chỉ."*

Hắn nghe Lão Chỉ đọc ba chữ ấy, và cảm thấy mảnh giấy trong tay áo bỗng *run lên* như một chiếc lá giữa bão.

*Ngài sao vậy?*

*"…Bản tọa thấy…"* Giọng nói bị bóp méo, đứt đoạn. *"…một cái bàn dài. Mực. Rất nhiều mực. Mười người ngồi quanh. Người ngồi đầu bàn quay lại, gọi bản tọa là… là…"*

Hắn đợi. Mảnh giấy nóng rực, rồi nguội ngắt, như một ngọn đèn bị ai thổi tắt.

*"…Bản tọa vừa nói gì?"*

*Ngài vừa nói có một cái bàn dài.*

*"Cái bàn nào? Bản tọa chưa từng nói."* Giọng nó nhỏ và lạc, như đứa trẻ vừa tỉnh dậy sau cơn ác mộng. *"…Sao bản tọa lại thấy lạnh?"*

Hắn không đáp. Hắn chỉ khẽ vuốt ống tay áo, như vuốt một con thú nhỏ đang hoảng.

Ở bên cạnh bia, hắn nhận ra một chi tiết nữa. Ở sườn đá, có một vết lõm hình chữ nhật, mép lởm chởm như bị xé. Hắn khẽ che mảnh giấy trong lòng bàn tay, áp lại gần. Mép rách của mảnh giấy và mép vết lõm *giống nhau đến từng chiếc răng cưa*, nhưng cái lõm lớn hơn gấp ba, như một trang sách thật vừa bị ai đó xé đi khỏi cuốn, và mảnh giấy trong tay hắn chỉ là một góc.

Hắn chợt hiểu vì sao lão Hoàng nhét thứ này vào ngực hắn.

— Lục Trầm.

Giọng nàng vang lên sau lưng, và lần này hắn không nghi ngờ gì.

Thanh Dao đang đứng giữa những cột đá, áo trắng lấm bụi, tóc dính hai nhánh cỏ khô, thanh kiếm đã rút ra nửa vỏ. Phía sau, ba con vân hồ nằm tan thành khói.

— Cô nương làm sao tìm được? — Hắn hỏi.

— Ta đi theo Tiền Đa Đa. — Nàng đáp, rất nghiêm túc. — Sợi chỉ mệnh của gã vàng rực, dày bằng ngón tay, thấy từ ba dặm. Đại phú đại quý, thọ tám mươi. Dễ tìm hơn cả cây đèn.

Đa Đa vừa hớt hải trở về, nghe vậy, ngập ngừng giữa tự hào và bị xúc phạm.

— Đội của cô nương đâu?

— Ta thấy họ chậm. — Nàng nói. — Ta báo là đi dò đường.

— Ngược hướng?

— …Không. — Nàng đáp, sau một nhịp thở, hơi ngập ngừng. — Chỉ là… *rẽ một chút.*

Nàng bước tới gần bia, nhìn lên tấm đá xám phẳng lì, rồi nhìn hắn, rồi nhìn bàn tay hắn đang đặt trên đá.

— Ta không thấy gì. — Nàng nói.

— Ta biết.

— Ngươi thấy gì?

Hắn nghĩ một chốc. Phương Ngọc Thành đã đứng dậy, cách đó mười trượng, và nghiêng đầu như đang nghe một tiếng ru. Nhưng hắn đã hứa, *đáp mọi câu hỏi, không che giấu*. Hắn hạ giọng, đọc tên từng người. Không bỏ tên nào, không sót nét nào. Chỉ giấu mảnh giấy.

Khi hắn đọc xong, Thanh Dao im lặng thật lâu.

— Dị số vạn năm trước. — Nàng nói chậm rãi. — Chín người.

— Và một chỗ trống.

— Sách của Các chép: dị số là lỗi của Thiên Thư. Một sai sót hiếm có trong vạn năm. — Nàng nắm chặt chuôi kiếm. — Ta được dạy như thế từ lúc năm tuổi.

— Cô nương còn được dạy gì nữa?

— Rằng… Thiên Thư không bao giờ sai.

Hai câu ấy đặt cạnh nhau, tự mâu thuẫn. Nàng cũng nghe thấy. Gương mặt lạnh như băng của nàng thoáng một nét hoang mang rất khẽ, như người đang đứng giữa phố quen mà bỗng không nhận ra đường.

— Nếu có chín người, — nàng nói, — thì không còn là lỗi.

— Phải.

— Vậy thì là gì?

Hắn không trả lời. Hắn nhìn khoảng trống ở dưới cùng tấm bia, rộng đúng một hàng chữ, và cảm thấy từ đá lạnh toát ra một sự chờ đợi mà hắn không thích.

*Đừng chạm vào đó.* Hắn nghĩ. Nhưng bàn tay phải của hắn đã nóng lên, và trên mu bàn tay, ba chữ *Vị chung quyển* chợt lóe vàng, rồi tắt.

Phía sau, tiếng bước chân của Phương Ngọc Thành vang lên, rất nhẹ, rất chậm.

— Các vị. — Y nói, nụ cười vẫn nguyên vẹn. — Ta nghĩ… ta tìm được đường rồi.
