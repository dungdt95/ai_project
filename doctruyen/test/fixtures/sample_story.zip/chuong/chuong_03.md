# Chương 3: Chấp Bút Sứ

Cổng trấn khóa bằng xích sắt to bằng cổ tay. Sáng hôm sau người ta mở cổng, thấy xích vẫn nguyên, chốt vẫn nguyên, vậy mà vị khách kia đã ngồi sẵn trong quán trà đầu phố, chẳng ai hay hắn vào từ lúc nào.

Đó là một nam nhân chừng ba mươi, dáng vẻ thanh nhã, bạch y thắng tuyết, không dính một vết bùn dù bên ngoài mưa suốt cả đêm. Tóc hắn búi gọn bằng một cây trâm hình ngọn bút bằng ngọc, chiếc ô giấy trắng đã gấp lại đặt ngay ngắn bên chén trà. Gương mặt hắn hiền hòa, nụ cười hiền hòa, hiền đến mức người bán trà run tay rót đầy chén thứ ba mà chẳng dám lấy tiền.

— Đa tạ. — Hắn mỉm cười. — Trà ngon. Chủ quán, xin hỏi quán rượu họ Hoàng ở cuối phố đi lối nào?

Ngô chấp sự đứng sau lưng hắn, người cúi gần như gập đôi, mồ hôi chảy ròng từ thái dương xuống cổ áo.

— Bẩm Hàn đại nhân, thuộc hạ… thuộc hạ đã cho người canh giữ…

— Ta biết. Ngươi làm tốt lắm. — Hàn Mặc nói, giọng ôn hòa như vỗ về trẻ nhỏ. — Gương hỏng thì đập, đập nhiều lần mà không hỏng thì chứng tỏ gương không hỏng. Ngươi nghĩ đúng, chỉ chậm một chút. Lui về nghỉ đi.

Ngô chấp sự lùi ra, hai chân nhũn ra như không còn xương.

Hàn Mặc cầm ô đứng dậy, bước ra đường. Mưa đã nhỏ hạt, bầu trời xám chì, mặt đá xanh loáng nước. Hắn đi rất chậm, mỗi bước đặt xuống đều khẽ như lướt, không một giọt nước nào bắn lên vạt áo.

---

Lục Trầm bị đánh thức bởi một mùi hương.

Không phải mùi rượu, mà là mùi mực. Mùi mực thượng hạng, phảng phất trầm hương, lan khắp quán như thể có ai đang mài nghiên ngay giữa gian chính.

Hắn bước xuống thang. Quán không có khách, cửa lớn mở toang, nơi bậc thềm có một bóng áo trắng đứng đó, ô giấy khép trong tay.

Lão Hoàng ngồi trên sập trúc giữa sân trước, bầu rượu kẹp giữa hai đầu gối, đầu gục xuống như đang ngủ gật. Thanh đao cũ vẫn nằm trong vỏ mục, gác ngang trên đùi.

— Quán chưa mở. — Lão Hoàng không ngẩng đầu. — Muốn uống thì quay lại vào giờ Ngọ.

— Tại hạ không đến để uống. — Người áo trắng nói, giọng nhẹ như gió. — Tại hạ Hàn Mặc, Chấp Bút Sứ của Thiên Thư Các. Nghe nói nơi này có một đứa trẻ cần được… giúp đỡ.

Lục Trầm đứng khựng ở chân thang.

Hàn Mặc quay đầu nhìn thấy hắn, ánh mắt dịu dàng như phụ thân nhìn con. Thiếu niên bỗng thấy toàn thân lạnh lẽo hơn cả lúc chạm vào Mệnh Giám.

— Là tiểu hữu đây sao? — Hắn khẽ cúi đầu chào, vô cùng lễ độ. — Lục Trầm, mười lăm tuổi. Xin đừng sợ. Tại hạ không phải kẻ ác. Tại hạ đến để giúp ngươi.

— Giúp thế nào? — Lục Trầm hỏi, giọng đều đều.

— Ngươi thử nghĩ xem. — Hàn Mặc bước vào sân, giọng ấm áp như đang kể chuyện cho trẻ nhỏ nghe. — Thiên Thư ghi tên mọi sinh linh. Nhờ có nó, kẻ yếu biết mình yếu mà sống yên phận, kẻ mạnh biết mình mạnh mà gánh vác. Một người không có tên thì không có chỗ đứng trong thế gian. Không tông môn nào nhận, không ai tin, đi đến đâu cũng bị xua đuổi, bị săn lùng, cả đời không có lấy một ngày yên ổn. Như thế chẳng phải khổ lắm sao?

Hắn ngừng lại, ánh mắt càng dịu đi.

— Cho nên, thay vì để ngươi chịu khổ, Thiên Thư Các sẽ đưa ngươi trở về nơi hư vô mà ngươi vốn thuộc về. Không đau. Chỉ một nét bút, rất nhanh. Đó là lòng từ bi.

Lục Trầm hiểu hết từng chữ. Hắn chỉ chậm hơn một nhịp trong việc tin rằng trên đời có kẻ bàn chuyện giết người bằng giọng điệu của người mời trà.

— Các hạ nói hay lắm. — Hắn đáp. — Nhưng nếu vãn bối từ chối lòng từ bi ấy thì sao?

— Thì tại hạ rất lấy làm tiếc. — Hàn Mặc mỉm cười buồn bã. — Từ bi vốn không phải thứ để từ chối.

Hắn giơ tay. Cây trâm bút ngọc trên đầu bay ra, lơ lửng giữa không trung, đầu bút đọng một giọt mực đen lóng lánh. Lục Trầm chẳng biết gì về tu sĩ, nhưng bản năng trong hắn gào lên một chữ: chạy.

Nhưng chân hắn không nhúc nhích. Không khí quanh sân đột nhiên đặc quánh lại, nặng nề như nước biển sâu, từng sợi lông tơ trên người hắn dựng đứng. Trong khoảnh khắc ấy hắn hiểu thế nào là cách biệt giữa phàm nhân và tu sĩ. Mãi về sau hắn mới biết, đó là uy áp của một tu sĩ Kim Đan. Hắn chỉ cần đứng đó đã đủ khiến cả trấn không dám thở mạnh.

Cây bút ngọc vạch một nét trong không trung.

Một chữ đen hiện ra, cao bằng người, đè xuống như một ngọn núi.

*Tử.*

*Choang.*

Một tiếng kim loại xé gió.

Chữ đen vỡ nát thành ngàn mảnh mực, bắn tung tóe khắp sân, vẩy đen lên vách gỗ, lên cây hồng, lên chiếc sập trúc. Không một giọt nào chạm được vào Lục Trầm.

Lão Hoàng đã đứng dậy.

Lão vẫn đứng như một lão già say, lưng còng, tóc rối, nhưng thanh đao đã ra khỏi vỏ nửa tấc. Chỉ nửa tấc, ánh thép lạnh lẽo lóe lên dưới bầu trời xám, toàn bộ uy áp đang nghiền xuống sân lập tức vỡ tan như bọt nước.

— Lão tử nói rồi. — Lão Hoàng uể oải nói. — Quán chưa mở.

Hàn Mặc đứng bất động, nụ cười trên mặt cứng lại một chút. Bàn tay cầm ô khẽ siết.

— Tiền bối. — Hắn chậm rãi nói. — Tại hạ có mắt như mù. Xin hỏi tôn tính đại danh?

— Chủ quán. — Lão Hoàng đáp. — Họ Hoàng. Chuyên bán rượu chua.

— Một kẻ bán rượu không thể cản nổi một nét bút của Chấp Bút Sứ. — Hàn Mặc nhìn nửa tấc thép, giọng nhẹ đi nhưng ánh mắt lại sắc lên. — Trong Thiên Thư có tên tiền bối chăng? Tại hạ chưa từng thấy ai chặn được chữ "Tử" của Chấp Bút Sứ bằng một thanh đao… trừ một người, đã chết từ ba mươi năm trước.

Lão Hoàng không đáp. Thay vào đó, lão cười, nụ cười rất nhẹ, rất khó đoán, như người vừa nhớ ra một trò đùa cũ.

— Tiểu tử. — Lão nói mà không quay đầu. — Vào trong lấy cho lão tử cái hũ rượu dưới bếp. Hũ nhỏ nhất, nắp đỏ.

— Hả? — Lục Trầm sững sờ.

— Đi.

Hắn chạy. Hai bàn chân tê dại, nhưng hắn vẫn chạy vào bếp, nhấc cái hũ rượu nhỏ nắp đỏ trong góc, tay run lên như kẻ sốt rét. Khi hắn trở ra, bầu trời đã tối sầm. Mây đen dày đặc cuộn từng tầng trên nóc quán. Hàn Mặc đã rút ra một cây bút thật sự, dài như cây quạt xếp, đầu bút nhỏ từng giọt mực, mực rơi đến đâu, nền đá trong sân mòn lõm đến đó.

Còn lão Hoàng vẫn đứng yên, thanh đao rút ra thêm một tấc.

— Hũ rượu đâu? — Lão hỏi.

Lục Trầm đưa tới. Lão đón lấy, hất nắp, tu một ngụm lớn rồi thở phào.

— Rượu này cũng chua. — Lão chép miệng. — Nhưng chua thế mới hợp với hôm nay.

Rồi lão ném hũ rượu qua vai. Hũ rượu bay lên, xoay tròn giữa không trung, và Lục Trầm thấy lão Hoàng nhìn mình, lần đầu tiên không bằng ánh mắt lười nhác thường ngày. Đó là ánh mắt của một người đã tính toán rất lâu, rất kỹ, mà vẫn thấy chưa đủ.

Bàn tay lão thò vào ngực áo, lôi ra một thứ.

Một mảnh giấy.

Rách nát, vàng ố, nhàu nhĩ, to chừng lòng bàn tay, bốn góc xơ xác như đã bị nhét trong ngực áo không biết bao nhiêu năm. Lão nhét nó vào tay Lục Trầm, dùng bàn tay chai sạn nóng hổi ép chặt các ngón tay hắn lại.

— Cầm lấy. — Giọng lão rất thấp, rất nhanh. — Chạy ra cổng sau, men theo lối mòn lên núi. Đừng quay đầu. Đừng dừng lại. Đừng đưa nó cho bất kỳ ai.

— Lão Hoàng, lão…

— Đi.

— Ta không đi. — Lục Trầm nói. Giọng hắn run, đó là lần đầu tiên trong đời giọng hắn run. — Lão cũng phải đi. Ta… ta không nặng, ta chạy nhanh, ta kéo lão theo được…

— Tiểu tử thối. — Lão Hoàng cười. Lần này là một nụ cười rất thật, những nếp nhăn hằn sâu nơi khóe mắt. — Mười lăm năm nay ngươi cãi lão tử chưa thua lần nào. Lần này nghe lời lão một lần đi.

Lão giơ tay xoa đầu hắn, thô bạo như xoa đầu chó con.

— Rượu của lão tử, ngươi đừng uống trộm nữa. Lão biết hết. Thứ rượu chua đó trẻ con uống vào hại bao tử.

Cổ họng Lục Trầm nghẹn lại. Hắn muốn nói một câu độc địa, loại câu hắn vẫn quen dùng để che giấu những lúc mềm lòng, nhưng ra đến miệng lại thành:

— …Lão đừng chết.

— Lão tử sống dai hơn ngươi nghĩ. — Lão nói. — Chạy!

Lão Hoàng xoay người, bước lên một bước.

Chỉ một bước.

Thanh đao rời khỏi vỏ.

Cả khoảng trời trên quán rượu bị rạch ra một đường sáng. Không phải tia chớp, mà là một vệt trắng lạnh lẽo dài từ đất đến mây, như có ai xé toạc tấm vải đen của trời. Cuồng phong nổi lên, cuốn bay cả mái ngói rêu xanh, cây hồng già rung lên bần bật, hàng trăm quả đỏ rụng rào rào như mưa lửa. Lục Trầm bị sức ép hất ngã ngồi, mảnh giấy trong tay như bị một bàn tay vô hình ghìm chặt.

Trên mặt Hàn Mặc không còn chút vẻ hiền hòa nào. Hắn quát lên một tiếng, cây bút trong tay vạch liền ba nét, ba chữ đen dựng lên thành một bức tường chắn giữa hắn và lưỡi đao.

Ba chữ ấy, chữ nào cũng đủ nghiền nát một ngọn núi nhỏ.

Đao chém qua.

Ba chữ ấy vỡ vụn như giấy.

— Chạy đi! — Lão Hoàng gầm lên, không quay đầu lại. Giọng lão không còn khàn đặc men say, mà trầm vang như sấm lăn trên mây, mang theo thứ uy nghiêm từng khiến cả một thời đại phải cúi đầu. — Lục Trầm!

Lần đầu tiên trong mười lăm năm, lão gọi hắn bằng tên đầy đủ.

Lục Trầm bật dậy. Nước mắt không biết từ đâu chảy xuống mặt, hắn mặc kệ. Hắn quay lưng, chạy qua gian bếp, đạp tung cánh cửa sau, lao ra bãi đất trống đầy cỏ ướt. Sau lưng hắn, tiếng đao và tiếng bút va vào nhau như núi lở, mặt đất rung chuyển. Tiếng Hàn Mặc thét lên, không còn một chút nho nhã nào:

— Ngươi là… *Đao Quỷ*… ngươi… không thể nào!

Lục Trầm không quay đầu.

Hắn chạy, chân giẫm lên bùn, cành cây quất vào mặt, hơi thở nóng rát trong lồng ngực. Con đường mòn lên núi trơn như mỡ, hai bên là rừng thông ướt sũng. Phía sau, một tiếng nổ trầm đục vang lên, chấn động cả bầu trời, rồi mọi thứ im bặt.

Im lặng. Tuyệt đối.

Hắn dừng lại ở lưng chừng núi, thở không ra hơi, quay đầu nhìn xuống.

Nơi quán rượu cuối phố từng đứng chỉ còn một đám khói xám cuồn cuộn bốc lên trời. Mái nhà, cây hồng, cái giếng cổ, tất cả đều đã biến mất, chỉ còn lại một vết nứt thẳng tắp dài hàng chục trượng, rạch qua cả chân núi. Giữa khói bụi không có bóng người, không bóng áo trắng, cũng không có bóng lão già gầy còng với thanh đao cũ.

Lão Hoàng đã biến mất.

— Lão Hoàng… — Hắn gọi, giọng khàn đặc. Gió thổi qua, không ai đáp lời.

Hắn đứng như trời trồng, hai tay buông thõng, mưa nhỏ lại bắt đầu rơi trên vai. Rồi hắn nghiến răng, lấy tay áo lau mặt, xoay người, đi tiếp. Không chạy nữa, mà bước, từng bước vững vàng, như một đứa trẻ vừa bị buộc phải lớn lên.

Đi được một đoạn, hắn cảm thấy lòng bàn tay mình ấm lên.

Hắn mở tay ra. Mảnh giấy rách nằm im đó, vàng ố, không một nét chữ. Nhưng nó đang ấm dần, chậm rãi, đều đặn, như có thứ gì đang hít thở bên trong lớp giấy mỏng. Và ngay khoảnh khắc đầu ngón tay hắn chạm vào, hắn cảm thấy trên mặt giấy trống trơn kia, có thứ gì vừa khẽ nhúc nhích.

Như một nét bút, đang tự mình hiện ra.
