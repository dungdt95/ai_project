# Chương 14: Luyện Khí Tầng Năm

Lão Thất và Tri Vi chỉ dám lấy nước ở mép hồ.

Chỉ một chén nhỏ, mỗi người, nhấp từng ngụm như đang uống thuốc đắng. Lão Thất ngồi xếp bằng nửa nén hương, mặt đỏ bừng, rồi hớn hở reo lên rằng tu vi lão nhúc nhích, ba năm khổ tu đổi lấy một chén nước, đáng giá hơn cả mạng già. Tri Vi chỉ lặng lẽ cúi đầu, rút ra một chiếc bình ngọc nhỏ, chắt vào ba giọt, đậy kín.

— Gần giữa hồ, linh khí hỗn loạn lắm. — Nàng khẽ nói. — Đừng ai xuống sâu hơn.

Đa Đa đã quay lại sau một nén hương, tay ôm chín chiếc bình sứ lấy từ túi hai huynh đệ áo đỏ.

— Gọi là phí tinh thần. — Gã nghiêm trang. — Mang ra ngoài bán gấp mười giá vốn.

Lục Trầm đứng ở bậc thềm cuối cùng, nhìn mặt hồ trắng đục. Hắn không lấy bình, không lấy chén. Trong lồng ngực, thứ ấm áp kia đang gọi hắn như tiếng một người thân từ bờ bên kia.

*"Tiểu tử."* Lão Chỉ nói, giọng chưa hết hoảng sau cơn mất trí lúc nãy. *"Thứ nước này không tên. Linh khí người thường hấp thu đều có tên, từ Thiên Đạo cấp xuống, giống như ngân lượng có triều đình đúc dấu. Còn cái này là đồng nguyên chất, chưa ai đóng ấn."*

— Người khác không dùng được?

*"Dùng được, nhưng như nuốt một con sông vào cái chén. Nhưng ngươi…"* Nó ngập ngừng. *"Ngươi là trang trắng. Không gì cản ngươi."*

Hắn quay lại nhìn Thanh Dao. Nàng đang đứng cách hắn năm trượng, tay đặt hờ lên chuôi kiếm.

— Ta cần một ngày một đêm. — Hắn nói.

— Ta canh. — Nàng đáp. — Ngươi làm gì, ta không hỏi. Ta đã nói với ngươi từ lúc ở cổng.

Hắn khẽ gật, rồi bước xuống hồ.

---

Nước lạnh, rồi ấm, rồi không còn là nước.

Khi hắn chìm đến ngực, hắn nghe tiếng. Không phải tiếng người, mà là tiếng bút cào trên giấy, nghìn nghìn tiếng, từ khắp bốn phía. Linh khí tràn vào kinh mạch hắn qua mỗi lỗ chân lông, thô ráp, mênh mông, không có đường đi. Nếu hắn là một người tu theo Thái Thanh Dẫn Khí Quyết, hắn đã nổ tung.

Nhưng hắn là trang giấy trắng.

*Ngài từng nói nét 37 hỏng vì ta ép.*

*"Ừ."*

*Ta nghĩ ta hiểu vì sao rồi.*

Trên tấm bia vạn năm, hắn đã không sao chép bất cứ nét nào. Hắn chỉ nhìn thấy cách chín cái tên ấy được khắc, và nhìn rất lâu, đến mức khi nhắm mắt, hắn vẫn thấy từng đường dao. Nét đầu của chữ này luôn chừa đường cho nét cuối của chữ trước. Không một nét nào đứng riêng. Mỗi nét là một lời hứa với nét kế tiếp.

Nét 37 của hắn năm xưa hỏng, vì hắn viết nó như một nét riêng, không biết nó phải nối vào đâu. Còn bây giờ, hắn biết.

Hắn bắt đầu viết.

Nét thứ 109 đau như một mũi kim chọc vào tủy. Nét thứ 110, như có ai kéo gân từ cổ xuống gót chân. Hắn cắn chặt răng, nhớ lại nét bút trên bia, nhớ cái khoảng chừa ra giữa các nét, và để cho linh khí trắng tràn vào chỗ chừa đó như nước tràn vào lòng sông mới đào. Nó không kéo hắn đi. Nó chờ hắn dẫn.

Đến canh ba, hắn mở thông tầng hai. Linh khiếu mới trên cổ tay trái mở ra như một cánh cửa nhỏ, nhẹ và ấm. Hắn thở ra một hơi dài, khói trắng bay lên mặt hồ.

Sang tầng ba, đau hơn gấp đôi. Hắn đổ mồ hôi lạnh, môi cắn rách. Hắn không dừng, vì biết nếu dừng giữa một nét, nó sẽ ở lại trên người mãi mãi.

Tầng bốn đến lúc rạng sáng, khi ngoài hố sương đã chuyển màu xám bạc.

Đến nét thứ hai trăm tám mươi, hắn khựng lại.

Nét ấy, hắn *chưa hiểu*. Nó nằm đó, trước mặt, một nét ngang cong, và hắn biết nếu viết đúng, hắn sẽ lên được tầng năm ngay hôm nay. Nhưng hắn không hiểu nó nối vào đâu.

*"Đừng."* Lão Chỉ nói. *"Tiểu tử, đừng. Quy tắc của ngươi, nét chưa hiểu mà ép viết thì thành sẹo."*

*Ta biết.*

*"Vậy ngươi…"*

Nhưng tầng năm gần như nằm trong tay, hắn chỉ cần một nét. Chỉ cần *đánh liều*.

Hắn viết.

Có một tiếng "rắc" khô khốc, rất nhỏ, như một chiếc bát sứ nứt. Đau không như những lần trước, mà lạnh, lạnh buốt từ xương bả vai trái lan ra cả ngực. Hắn gập người, nước trắng sôi sùng sục xung quanh. Khi hắn ngẩng lên, tầng năm đã mở, linh khiếu thứ năm ở đan điền xoay chậm như một cối xay nhỏ, nhưng sau vai trái hắn có một vệt sẹo mảnh dài bằng ngón tay, trắng bạc như vết rạn trên sứ.

*"Ngu."* Lão Chỉ nói, giọng rất nhẹ. *"Ngu lắm. Nhưng nhờ ngu mà ngươi lên được."*

— Ngài có thể nói bớt thế được không.

*"Không."* Giọng nó run run. *"Bản tọa vừa tưởng ngươi chết."*

Hắn đứng trong nước, người nóng ran, hơi thở tỏa ra thứ sương trắng rõ ràng. Hắn không thấy mừng. Hắn chỉ thấy nhẹ, và một chút lạnh ở vai.

---

Khi hắn bước lên bờ, trời đã sáng.

Thanh Dao ngồi trên một tảng đá cách đó mười trượng, kiếm đặt ngang đầu gối, áo trắng đã khô sương. Nàng đã ngồi đó đủ một đêm, và có vẻ chưa hề ngủ. Đa Đa nằm cuộn tròn cạnh đống bình sứ, ngáy khò khò. Lão Thất ngồi thiền ở góc, Tri Vi đang cho Phương Ngọc Thành uống nước, nhẹ nhàng như đút cho một đứa trẻ.

— Ngươi đang tỏa sương. — Thanh Dao nói.

Lục Trầm ngồi xuống cạnh tảng đá, thở ra, và thấy vai mình lạnh. Nàng chìa tay ra, không vì vũ khí, mà đỡ lấy bả vai hắn, nghiêng đầu nhìn vết sẹo trắng.

— Cái gì đây?

— Sẹo.

— Hôm trước ngươi không có.

— Một nét viết chưa hiểu. — Hắn đáp. — Ta ép.

— Đau không?

— Đau.

— Ngươi có biết trước là sẽ đau?

— Biết.

— Vậy vì sao?

— Vì lúc đó ta muốn nhanh.

Nàng im lặng một chốc, rồi rút tay về, nhìn những ngón tay mình như vừa chạm vào thứ gì rất lạ.

— Lần sau, — nàng nói, — đừng muốn nhanh.

---

Ngày thứ ba, đúng giờ Ngọ, tiếng chuông cổ lại ngân lên. Cả khu rừng đá rung nhẹ. Sương cuộn lên, và từng người bị cuốn đi như lá, hồ nước, tế đài, bia đá, tất cả tan vào một màu trắng.

Khi mở mắt, họ đã đứng ngoài cổng đá, giữa tiếng người ồn ào, mặt trời còn chói giữa trời. Có kẻ khóc, có kẻ cười, có kẻ nằm ngửa thở dốc như vừa trở về từ chiến trường. Đội Thiên Thư Các đã đứng thành hàng bên phải, tên chấp sự mặt gầy như dao đang nhìn Thanh Dao từ xa, ánh mắt khó dò.

Lão Thất chắp tay, hơi cúi người.

— Tiền Phúc huynh, lão không biết huynh là ai. — Lão nói nhỏ, mắt cười. — Lão chỉ thấy một tiểu huynh đệ hộ viện tốt bụng. Sống thêm mấy năm cũng đáng.

— Đa tạ lão Thất.

Tri Vi đã dìu Phương Ngọc Thành đến, người thanh niên ấy nhìn quanh như đứa trẻ lạc, tay bám lấy tay áo nàng.

— Y không có tên. — Nàng nói, ngước lên. — Ta thấy trong lòng không yên. Một người không biết mình là ai, cũng cần có người gọi tên hộ. — Nàng thoáng đỏ mặt. — Tiểu nữ gọi y là A Thành. Được không?

Lục Trầm nhìn gã thanh niên đang cúi nhìn đôi bàn tay mình, rất lâu.

— Được. — Hắn nói.

Nàng cúi chào, rồi dắt người ấy đi, bóng hai người khuất vào đám đông.

---

Thanh Dao bước vào bạch tháp của chi các lúc hoàng hôn.

Nàng đứng một lúc lâu ở bậc đá đầu tiên. Bốn tên chấp sự áo xám nhìn nàng lặng lẽ. Nàng đã bước vào nơi này hàng trăm lần, chưa bao giờ thấy bậc thềm dài đến vậy.

Tầng ba, phòng bên phải. Tào Hạc Niên, chấp sự mặt gầy, ngồi sau án thư, tay cầm một quyển sổ.

— Thẩm sư điệt. — Y nói, không ngẩng đầu. — Tàng Vân lần này tổn thất ba người trong đội của ta. Còn ngươi tự ý rời đội ngay giữa chừng. Ta muốn biết lý do.

— Ta dò đường. Ta lạc.

Y ngẩng lên, ánh mắt lạnh như dao.

— Ngươi chưa từng lạc.

— Ta đã lạc. — Nàng đáp, không đổi sắc mặt. — Nhưng ta đã tìm được đường.

Tào Hạc Niên nhìn nàng một lúc rất lâu, rồi đặt sổ xuống.

— Dị số Lục Trầm. Có xuất hiện trong Tàng Vân không?

Trong phòng im lặng đến mức nàng nghe được tiếng giọt nước nhỏ trên mái hiên. Nàng nghĩ đến sợi dây buộc cổ tay, đến xâu mứt quả, đến dòng chữ nhòe trong gương.

Nàng đã đọc dòng chữ ấy từ năm tám tuổi, và từ năm tám tuổi, nàng chưa từng nói điều gì không đúng với những gì mình thấy.

— Ta không thấy.

Giọng nàng rất bình thản. Không run, không ngập ngừng, như đọc một con số. Chỉ có một điều, từ lúc câu nói thoát ra khỏi môi, nàng cảm thấy cổ họng mình như nuốt phải cát.

Tào Hạc Niên nhìn nàng thêm một chốc, rồi cúi xuống sổ, nét mặt không đổi.

— Được. Đi đi.

---

Lục Trầm tìm thấy nàng bên con sông Bạch Lộ, trong ánh chạng vạng, ngồi dưới một gốc liễu già.

Nàng không nói gì. Hắn cũng không hỏi. Hắn ngồi xuống cách nàng đúng ba bước, và đặt xuống giữa hai người một xâu mứt quả.

— Đa Đa mua. — Hắn nói. — Gã bảo là tiền công bồi thường cho việc suýt bị rút mất danh.

Nàng nhìn xâu mứt, không đưa tay.

— Ta nói dối. — Nàng nói.

Hắn không đáp.

— Chưa từng. Ta nghĩ nó sẽ dễ hơn. — Nàng nhìn mặt nước. — Cổ họng ta đau. Tay ta vẫn lạnh. Ta nói "ta không thấy", mà ta thấy ngươi ở khắp nơi. Khi ta nhắm mắt, ta thấy ngươi đứng trong nước mà tỏa sương.

— Lần đầu thì thế.

— Rồi sẽ dễ?

— Rồi sẽ dễ. — Hắn đáp.

— Ta không muốn dễ.

Ngọn gió thổi qua tán liễu, lá rụng xuống mặt nước, xoay tròn.

— Ta nói dối vì ngươi, hay vì ta? — Nàng hỏi.

— Ta không biết.

— Ta cũng không biết. — Nàng nhìn thẳng vào hắn, lần đầu tiên hắn thấy hàng mi nàng ướt, nhưng mặt không có nước mắt. — Chỉ biết nếu ta nói thật, ngươi chết. Còn ta không muốn thế.

Câu nói ấy rơi xuống như một hòn đá nhỏ xuống mặt hồ, không tiếng động, mà gợn sóng tỏa ra rất xa. Hắn không giỏi nói lời đẹp. Hắn chỉ đưa tay cầm xâu mứt, bẻ làm đôi, đưa một nửa sang.

Nàng nhận lấy. Ngón tay họ chạm nhau, chỉ một nhịp, nhưng không ai rút về ngay.

— Ngọt. — Nàng nói.

— Mứt thường thế.

— Ta biết. — Khóe môi nàng khẽ cong, rất nhẹ. — Nhưng lần này hình như ngọt hơn.

Cạnh sông, trong bóng chiều, hai người ngồi ăn mứt. Rất lâu sau, nàng mới nhớ ra một chuyện, rút trong ngực áo ra cuộn giấy nhỏ.

— Chi các giao. Lệnh phái của ta. — Nàng đọc, giọng trở lại bình tĩnh. — Vân Lam Tông tổ chức đại hội tuyển đồ, ba mươi ngày nữa, trên núi Vân Lam. Thiên Thư Các cử giám sát, soi lại mệnh trang của mọi người dự thi. Ta phải đi.

— Soi lại mệnh trang. — Lục Trầm lặp lại.

— Mọi người đều có mệnh trang. Không có mệnh trang thì không có thẻ dự thi. — Nàng hơi nghiêng đầu. — Ngươi muốn vào Vân Lam Tông?

— Ta cần tài nguyên. Ta cần chỗ đứng. — Hắn nói. — Và ta cần một cái tên.

Một tiếng bước chân hớt hải vang trên đê. Đa Đa chạy tới, ngực phập phồng, hai mắt sáng rực.

— Lục huynh! Tại hạ vừa nghe một chuyện! — Gã thở dốc, hạ giọng. — Chợ đen Lạc Phong, phố Nam, có một người… *viết mệnh trang*.

*"Viết?!"* Lão Chỉ gào trong tay áo hắn. *"Chỉ bản tọa mới có tư cách viết! Kẻ nào dám…"*

— Giá bao nhiêu? — Lục Trầm hỏi.

Đa Đa nuốt khan, ngồi xuống bãi cỏ trước, rồi mới nói con số. Nghe xong, Thanh Dao suýt bị mứt quả mắc nghẹn. Lục Trầm nhìn gã rất lâu, rất bình tĩnh.

— Ngươi đoán xem, — hắn nói, — ta có bao nhiêu bạc vụn trong người.

— Nhưng tại hạ có. — Đa Đa lau trán. — Chỉ có điều… hàng thật, hàng đặc biệt, còn đúng một bản. Người bán nói, là hàng… *hơi lỗi*.

Gió đêm thổi qua bờ sông. Ở xa, trên tường đê, những ngọn đèn đầu tiên của Lạc Phong đã thắp lên, từng chấm vàng nhỏ, như hàng ngàn dòng chữ chưa ai đọc.
