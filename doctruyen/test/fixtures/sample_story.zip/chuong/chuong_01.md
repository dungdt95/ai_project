# Chương 1: Mệnh Giám Không Sáng

Trấn Thanh Thạch có ba thứ nổi tiếng: đá xanh, mưa dầm, và rượu của lão Hoàng, thứ rượu nghe nói uống vào thì quên hết sầu, nhưng sáng hôm sau lại nhớ ra thêm một đống sầu mới.

Sáng nay trời không mưa, quả là chuyện hiếm thấy như phượng mao lân giác. Mặt đá xanh trước miếu Thổ Địa còn ướt, phản chiếu ánh nắng nhợt nhạt, mà trên quảng trường nhỏ ấy người đã chen chúc kín mít từ giờ Thìn.

Hôm nay là ngày Thiên Thư Các mở khảo hạch.

Ba năm mới có một lần. Đứa trẻ nào đủ mười lăm tuổi đều phải đến soi Mệnh Giám, xem trang Thiên Thư của mình ghi những gì. Có linh căn thì được đưa lên tông môn, từ phàm nhân hóa thành tiên nhân. Không có linh căn thì về nhà, cầm cuốc, cầm dao, cưới vợ, sinh con, chết già. Một tờ giấy quyết định cả đời, nghe thì bất công, nhưng cả Cửu Châu đã sống như thế mấy vạn năm, chẳng ai thấy lạ.

Lục Trầm đứng thứ mười bảy trong hàng, hai tay thọc vào ống tay áo, mắt nhìn trời như đang tính xem bao giờ mưa sẽ trở lại.

— Này, Trầm ca. — Tiểu Đậu, con trai Vương đại nương bán đậu phụ, luồn qua đám đông chui lên, lanh lẹ như một con chuột nhắt. — Huynh có sợ không?

— Không.

— Tay huynh run kìa.

— Lạnh.

— Trời nóng mà.

— Vậy thì ta run vì nóng. — Lục Trầm đáp, mặt không biến sắc. — Ngươi không có việc gì làm sao? Nương ngươi đang tìm ngươi ở sạp đấy.

Tiểu Đậu le lưỡi chạy mất. Lục Trầm khẽ thở ra một hơi. Hắn vốn không hồi hộp. Hắn chỉ hơi… đói. Sáng nay lão Hoàng còn say chưa tỉnh, bếp lạnh tanh, hắn nhịn bữa sáng đi xếp hàng, bụng cứ kêu theo nhịp trống của đội kèn đón khách Thiên Thư Các.

Trên bục gỗ dựng trước miếu, một người đàn ông trung niên mặc áo xám viền chỉ bạc ngồi sau chiếc bàn dài. Đó là Ngô Văn Bình, chấp sự của Thiên Thư Các, phụ trách vùng tây nam. Mặt y tròn, trắng, bóng, trông như một cái bánh bao hấp quá lửa, còn đôi mắt thì nhỏ và đầy vẻ chán đời của kẻ đã soi hàng ngàn đứa trẻ mà chưa gặp được mấy đứa đáng soi.

Trước mặt y đặt Mệnh Giám: một tấm gương đồng tròn, to bằng cái mâm, viền khắc những hoa văn như chữ mà không phải chữ. Đứa trẻ nào đặt tay lên mặt gương, trong gương sẽ hiện ra mệnh trang, từng dòng chữ vàng nhạt chậm rãi nổi lên.

— Triệu Đại Ngưu! — Ngô chấp sự đọc.

Một thiếu niên béo ú, con trai ông thợ rèn, bước lên bục, sắc mặt tái mét như sắp bị hành hình. Y đặt bàn tay to như cái quạt lên gương.

Mặt gương lóe sáng, sóng ánh sáng gợn lên rồi hiện chữ.

— Hạ phẩm thổ linh căn. Thọ nguyên sáu mươi hai năm. — Ngô chấp sự đọc to bằng giọng không chút cảm xúc. — Tư chất bình thường, có thể thu nhận làm tạp dịch ngoại môn. Kế tiếp.

Đại Ngưu đứng trơ ra một thoáng. Dưới đài, ông thợ rèn vỗ đùi đánh "bốp", hai mắt đỏ hoe, không biết đang khóc hay cười. Tạp dịch cũng là có đường đi, còn hơn ở lại trấn cả đời đập sắt. Cả đám đông cùng ồ lên chúc mừng, Đại Ngưu bị khiêng đi như một chiến lợi phẩm.

Lục Trầm nhìn cảnh đó mà thầm nghĩ: sáu mươi hai năm. Người ta có thể đọc ra ngày mình chết ngay giữa quảng trường, giữa tiếng kèn trống. Hắn không rõ mình có muốn biết hay không.

Hàng người nhích dần. Một tiểu cô nương họ Lý là thủy linh căn trung phẩm, cả trấn reo hò, nương nàng ngất xỉu tại chỗ. Một thiếu niên là kim linh căn hạ phẩm. Mấy đứa khác không có linh căn, sắc mặt trắng bệch không còn giọt máu, lủi thủi đi xuống. Thiên Thư không bao giờ đọc nhầm, nhưng cũng chẳng bao giờ dịu dàng.

— Lục Trầm! — Ngô chấp sự gọi, rồi liếc cuốn danh sách. — Mười lăm tuổi, cô nhi, trấn Thanh Thạch, ở quán rượu cuối phố. Lên đây.

Lục Trầm bước lên bục, đôi giày vải cũ nện lên ván gỗ kêu cọt kẹt. Bên dưới có người xì xào: "Đứa nhỏ nhà lão say đấy", "Ừ, đứa nhặt được ấy", "Nhìn vậy mà thông minh lắm", "Thông minh thì làm được gì, phải có linh căn chứ".

Hắn đặt tay lên Mệnh Giám.

Mặt gương lạnh buốt, lạnh đến mức hắn thấy xương tay tê dại. Hắn chờ ánh sáng.

Không có ánh sáng.

Ngô chấp sự đang cúi đầu ngáp, liếc xuống mặt gương rồi nhíu mày.

Gương vẫn trắng. Một màu trắng đục, đều đặn, không gợn sóng, không một nét chữ, như mặt hồ chết giữa mùa đông.

— Ấn mạnh tay hơn xem. — Y nói.

Lục Trầm ấn mạnh hơn.

Vẫn trắng.

— Nhấc tay ra. Đặt lại.

Hắn nhấc ra, đặt lại. Gương trắng như tờ giấy chưa ai viết.

Dưới đài, tiếng xì xào bắt đầu to lên. Ngô chấp sự thu người lại, ngồi thẳng, rút khăn lau mồ hôi trên trán, dù trời đâu có nóng.

— Chắc là… chắc gương bị ẩm. — Y lẩm bẩm. — Mấy hôm nay mưa nhiều quá, linh văn bên trong bị ẩm. Ngươi đứng yên đó.

Y đứng dậy, xắn tay áo, cầm Mệnh Giám lên ngắm trái ngắm phải, rồi giơ lên soi dưới ánh mặt trời. Cả quảng trường nín thở. Một con chó hoang chạy qua, sủa một tiếng, cũng bị ánh mắt của ba trăm người dọa cho cụp đuôi.

— Hỏng thật rồi. — Ngô chấp sự kết luận.

Y đặt gương xuống bàn, hít sâu một hơi, rồi vung bàn tay mập mạp lên, vả vào cạnh gương một cái.

*Bốp.*

Mặt gương vẫn trắng.

— Ừm, linh văn bị kẹt. — Y nói với cả đám đông bằng giọng của một vị lang trung đang giải thích bệnh tình. — Phải gõ cho nó thông.

*Bốp.*

Vẫn trắng.

Lục Trầm đứng yên, mặt không cảm xúc, nhưng khóe miệng khẽ giật. Hắn đã nhịn cười rất nhiều lần trong đời, nhưng cảnh một vị chấp sự của tổ chức đứng trên mọi tông môn đang vả vào bảo vật quý giá nhất của mình thì thật sự là thử thách tu dưỡng.

*Bốp!*

Lần thứ ba, y dùng hết sức bình sinh. Mặt gương rung lên kêu *oong* một tiếng dài, mấy hoa văn trên viền sáng lòe rồi tắt, chỉ để lại một mặt trắng lì như khiêu khích.

Ngô chấp sự rụt tay lại, thổi phù phù vào lòng bàn tay đỏ ửng. Dưới đài có ai đó phì cười một tiếng, rồi vội vàng ho khan che đi.

— Ngô đại nhân. — Lục Trầm lên tiếng, giọng rất lễ độ. — Cái gương không hỏng. Vừa nãy Đại Ngưu soi, nó vẫn sáng bình thường.

— Ngươi im miệng! — Ngô chấp sự quắc mắt, nhưng trong giọng đã có tiếng run. — Ta soi cho ngươi bằng tấm khác.

Y cúi xuống cái hòm gỗ cạnh bàn, lấy ra một tấm gương nhỏ hơn: Mệnh Giám dự phòng. Lần này y tự đặt lòng bàn tay của mình lên đó trước.

Gương sáng rực, hiện ra từng dòng chữ vàng. Ngô Văn Bình, thủy mộc song linh căn, thọ một trăm hai mươi tám năm. Y thở phào, lau mồ hôi, rồi vẫy tay gọi Lục Trầm:

— Lại đây. Đặt lên.

Lục Trầm đặt tay lên tấm gương nhỏ.

Ánh sáng vàng tan đi như sương gặp nắng. Mặt gương trở về màu trắng đục.

Cả quảng trường vốn ồn ào bỗng im phăng phắc, tới mức nghe được tiếng chim sẻ nhảy trên mái ngói miếu Thổ Địa.

— Không có tên. — Một giọng già nua run run từ hàng đầu vang lên. Đó là lão Mạnh, người giữ miếu, tám mươi tuổi, từng chứng kiến không biết bao nhiêu lần khảo hạch. — Gương không hiện tên. Đứa nhỏ này… không có tên trong Thiên Thư.

— Nói bậy! — Ngô chấp sự quát, nhưng giọng yếu hẳn. — Mọi sinh linh đều có tên trong Thiên Thư! Chó, mèo, gà, vịt cũng có! Bằng không thì…

Y không nói tiếp. Cái "bằng không thì" ấy treo lơ lửng giữa không trung, nặng như một tảng đá.

Lục Trầm rút tay về, nhìn lòng bàn tay mình một lúc. Hắn cảm thấy lạnh, nhưng không phải cái lạnh của mặt gương. Đó là hàn ý chạy dọc sống lưng, từ lúc ánh mắt của cả trấn đồng loạt đổ dồn về phía hắn. Ánh mắt ấy không còn là tò mò hay thương hại. Nó giống cách người ta nhìn một con rắn lạ vừa chui ra từ đống củi.

— Nhưng mà, — hắn thong thả nói, — nếu cả chó mèo gà vịt đều có mà ta không có, thì chắc ta thua cả gà rồi. Cũng đáng buồn thật.

Một đứa nhỏ dưới đài bật cười khúc khích, bị nương nó véo tai.

Không ai khác cười.

Ngô chấp sự lùi một bước, lưng chạm vào chân bàn. Y thò tay vào trong ngực áo, lấy ra một khối ngọc phù màu đen nhỏ như đồng xu, bàn tay mập mạp run lên bần bật. Y lẩm nhẩm điều gì đó, ngọc phù lóe một tia sáng xám, và trên mặt y, vẻ chán đời quen thuộc biến mất hẳn, thay vào đó là thứ gì lạnh hơn và sợ hãi hơn.

— Khảo hạch hôm nay tạm dừng. — Y nói, giọng đột ngột trở nên khô khốc. — Tất cả giải tán về nhà. Lục Trầm, ngươi… ngươi không được rời khỏi trấn. Kẻ nào dám để hắn ra khỏi cổng, coi như cấu kết với dị số, Thiên Thư Các sẽ xử tội đồng phạm.

Hai chữ "dị số" rơi xuống như hòn đá ném vào ao tù. Người ta bắt đầu lùi ra, tạo thành một vòng tròn trống quanh bục gỗ. Có bà lão vội vàng bịt mắt đứa cháu, có người nắm chặt tay áo nhau, thì thầm. Lục Trầm đứng một mình giữa vòng tròn ấy, nắng chiếu xuống, cái bóng của hắn nhỏ xíu trên mặt đá xanh.

Hắn ngẩng đầu, nhìn qua đám đông. Ở rìa quảng trường, dưới gốc cây hòe già, có một lão giả gầy gò mặc áo vải thô bạc phếch, tay xách bầu rượu, lưng hơi còng. Đó là lão Hoàng, người mà sáng nay hắn bỏ lại ngáy như sấm trên sập trúc.

Lão đứng nghiêng ngả, mắt lờ đờ, tóc tai rối bời, cái bầu rượu đung đưa trong tay. Trông lão vẫn y như mọi ngày: say mềm, vô dụng, lôi thôi.

Chỉ có một điều khiến Lục Trầm khựng lại.

Trong khoảnh khắc ánh mắt hai người chạm nhau, ánh mắt lão Hoàng không hề lờ đờ chút nào. Nó tỉnh, tỉnh như thanh đao vừa rút khỏi vỏ.

Rồi lão ngáp một cái, quay lưng, loạng choạng bước đi, bầu rượu lắc lư như chưa từng có chuyện gì xảy ra.
