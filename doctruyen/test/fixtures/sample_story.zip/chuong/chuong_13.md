# Chương 13: Phản Bội Trong Bí Cảnh

Con đường Phương Ngọc Thành tìm được là một khe núi hẹp, hai vách đá dựng đứng, sương trắng chảy dưới chân như một dòng sông nhỏ.

— Tâm cốc. — Y nói, giọng ôn hòa. — Sư môn ta có ghi: giữa bí cảnh có một hồ linh nhũ, ai uống một ngụm, ba năm khổ tu. Chư vị đã cùng ta kết khế, thì lợi lộc chia đều.

Lão Thất sáng mắt. Tri Vi ôm chặt chiếc hòm thuốc, vừa hồi hộp vừa mừng. Đa Đa lẩm nhẩm "chia đều", biểu cảm của kẻ vừa nghe một lời hứa mà vẫn muốn xem hợp đồng.

Lục Trầm chậm lại hai bước, nói rất nhỏ với Thanh Dao:

— Cô nương, người này có điều không ổn. Y lập khế, ai cũng nhỏ máu, riêng ngón tay y khô.

— Ta biết. — Nàng đáp, mắt nhìn thẳng. — Y quá sạch. Kiếm sạch, áo sạch, nụ cười cũng sạch.

— Cô nương nhìn kỹ thật.

— Ta nhìn người, không nhìn đường. — Nàng nói. — Đường thì ta không nhìn thấy.

— Vậy tại hạ có một việc nhờ. Cô nương đi vòng sang bên trái vách, lên cao, canh phía sau. Nếu y có đồng bọn, chúng sẽ ở đó.

— Bên trái?

— Là bên tay không cầm kiếm.

Nàng nhìn tay mình, rồi gật đầu, rất nghiêm túc. Hắn có linh cảm nàng sẽ đi bên phải. Đúng như hắn đoán, nàng quay người, đi thẳng về bên phải.

*"Tiểu tử,"* Lão Chỉ nói, *"ngươi nhờ nàng đi bên trái, mà nàng đi bên phải?"*

*Ta tính cả rồi.*

*"Ngươi tính cả rồi? Vậy bên phải có gì?"*

*Ta không biết.*

*"…"*

---

Cuối khe núi mở ra một cái hố tròn, đường kính chừng mười trượng, thành đá nhẵn, đáy hố là một tế đài thấp bằng đá đen, khắc dày đặc những ký tự mờ nhạt. Chính giữa tế đài là một phiến đá đứng, mặt đá như một trang giấy lớn, đang trống. Lục Trầm nhìn thấy nó, mảnh giấy trong tay áo hắn lập tức lạnh buốt.

*"Cái này là trận cũ."* Giọng Lão Chỉ gấp gáp. *"Cổ trận, không phải của Thiên Thư. Ngươi đừng… "*

Chưa kịp nói hết, Phương Ngọc Thành đã bước vào giữa tế đài.

— Chư vị, — y nói, quay lưng lại với họ, — thật cảm tạ.

Y mở cuốn sổ nhỏ. Năm cái tên đen đậm sáng lên. Ba trong số đó chuyển thành đỏ máu: *Cổ Thất. Liễu Tri Vi. Tiền Đa Đa.* Còn tên thứ tư, *Tiền Phúc*, vẫn đen, như một vết mực không chịu khô.

Một tiếng "keng" vang lên, từ lòng đất trồi lên những sợi xích dài làm bằng ánh sáng trắng, quấn quanh cổ tay, cổ chân, thắt lưng ba người. Lão Thất rống một tiếng. Tri Vi ngã xuống, chiếc hòm lăn đi. Đa Đa chỉ kịp kêu "Lục huynh!" rồi bị kéo ngã bẹp xuống đá.

Sợi xích thứ tư vươn về phía hắn. Nó chạm vào vạt áo hắn, trượt đi như nước trên lá sen, không bám vào đâu. Hắn đứng nguyên, bình tĩnh bước lùi một bước.

Nụ cười của Phương Ngọc Thành tắt dần, thay vào đó là một vẻ khoái trá lạnh lẽo.

— Quả nhiên. — Y nói. — Giọt máu không thấm. Ta nghi từ lúc ngươi bước vào hàng. Tiền Phúc, hộ viện nhà họ Tiền? — Y bật cười khẽ. — Ta đã dò hỏi người Tiền gia ở Lạc Phong, chẳng ai biết hộ viện nào tên Phúc. Ngươi là Lục Trầm, kẻ không tên. Thưởng gấp mười, bắt sống.

— Ngươi đọc cáo thị rất kỹ. — Lục Trầm đáp.

— Ta chờ tin này từ lâu. — Y nói. — Có người đã trả công cho ta trước cả khi Thiên Thư Các dán cáo thị. Người ấy nói, ngươi nhất định sẽ vào Tàng Vân.

Hắn hơi nhíu mày. Không phải vì bị lộ, mà vì câu nói sau.

— Ai nói?

— Điều đó thì ngươi không cần biết.

Hai bóng người từ sau tế đài bước ra, áo đỏ sẫm, mặt trắng như phấn, một cao một thấp. Bước chân họ không phát ra tiếng. Trên cổ mỗi người đeo một chiếc răng nanh dài.

— Huyết Nha song huynh. — Phương Ngọc Thành giới thiệu, như giới thiệu hai vị khách quý. — Trúc Cơ sơ kỳ và trung kỳ. Thù lao nửa linh nhũ, cộng nửa tiền thưởng.

— Còn ngươi được gì? — Lục Trầm hỏi.

— Linh nhũ, đương nhiên. Muốn mở cổng linh nhũ, cần ba danh làm tế. — Y vuốt cuốn sổ. — Ta đã tính kỹ. Ba người tế danh, một người bắt sống đổi tiền. Chẳng ai thiệt.

— Ta thiệt.

— Ngươi sống, còn tính là thiệt?

*"Tiểu tử,"* Lão Chỉ thì thầm, hoảng loạn, *"ba người kia, cả Đa Đa nữa. Xích đó kéo danh người ta ra, ngươi nhìn mặt gã mập kìa!"*

Hắn đã nhìn. Mặt Đa Đa trắng bệch, hai mắt trợn lên, thân thể co giật từng cơn khi sợi xích như hút một thứ gì vô hình khỏi ngực gã.

---

Một luồng sáng bạc xé ngang.

Từ trên cao, nơi không ai dự đoán, nhân ảnh trắng lao xuống như một mảnh tuyết rơi. Thanh Dao hạ thẳng xuống giữa tế đài, kiếm trong tay, mắt phượng lạnh như băng. Tóc nàng dính đầy lá và bụi, và nàng đang nhìn đúng hướng *đối diện* chỗ nàng dự định đứng.

— Ta đến phía sau. — Nàng nói.

— Cô nương đang ở *phía trước*. — Lục Trầm đáp.

— …Ta đến đúng lúc.

Huyết Nha huynh trưởng rống lên, ném ra ba đạo huyết ảnh, ba bóng đỏ, cùng một kiểu mặt, cùng vung đao. Thanh Dao không nhìn bóng. Nàng nhìn những sợi chỉ mờ phát ra từ vai gã, chỉ một sợi trong ba đạo, dày hơn, bóng hơn.

Kiếm xuất.

Một tia bạc, không nhanh hơn bao nhiêu, nhưng khi nó đi, ba huyết ảnh đồng loạt sụp xuống. Mũi kiếm xuyên vào lồng ngực gã áo đỏ, rút ra sạch sẽ. Gã nhìn xuống ngực mình, rồi thân thể từ từ mềm xuống, mắt mở trừng trừng. Không ai thấy được vết thương, chỉ thấy gã đã chết.

— Mệnh tuyến. — Nàng nói, giọng không biểu cảm. — Ngươi chỉ có một sợi.

Huyết Nha đệ đệ gầm lên, xông tới. Ba nhịp thở, kiếm đã chạm cổ họng y. Nàng không giết, chỉ nhíu mày, tay trái bắt kiếm quyết, chém vào sợi xích ánh sáng đang bay tới.

Lưỡi kiếm chém xuống xích.

*Keng.* Lưỡi kiếm bị bật ngược, rung lên bần bật.

Nàng sững lại. Lần đầu tiên Lục Trầm thấy trong mắt nàng một nét bàng hoàng, như một người nhận ra thanh kiếm quen thuộc của mình không còn nghe lời.

— Sợi xích này không có mệnh tuyến. — Nàng thì thầm. — Nó không có tên.

— Cổ trận. — Lục Trầm nói. — Nó có trước Thiên Thư.

Xích trắng quấn quanh chân nàng, kéo mạnh. Thân thể nàng quỵ xuống, kiếm rơi xuống đất, vang lên một tiếng giòn. Phương Ngọc Thành bước nhanh tới, một tay đặt dao găm kề cổ Đa Đa đang thở dốc.

— Dừng tay. — Y nói. — Còn nhúc nhích là gã mập này chết.

Đa Đa nghiêng đầu, mặt xám ngoét, nhìn Lục Trầm. Môi gã mấp máy, không thành tiếng. Hắn đọc được chữ "xin lỗi". Trong tay gã, những ngón tay cuộn lại, cố gắng nhét cái gì đó vào lòng bàn tay.

---

Lục Trầm thở ra một hơi dài.

Hắn đã nhìn hết. Khế đồng hành, năm tên, năm ô máu, ba người bị khóa. Một trận lấy "danh" làm tế. Nó chẳng quan tâm người ta là ai, chỉ quan tâm tên có trong sổ hay không. Hắn nhớ cái giọt máu trong sổ, trượt đi, không thấm; nhớ tên chấp sự nói "gương hỏng thì đổi, cấm đập". Hắn nghĩ đến chiếc gương số chín.

*Tiểu tử, đừng có nảy ra ý định gì điên rồ.*

*Ngài viết chữ vàng được, đúng không?*

*"…Ngươi muốn gì?"*

*Cái trận này đọc chữ.*

Hắn từ từ bước tới tế đài, giơ hai tay lên trời như đầu hàng. Phương Ngọc Thành nheo mắt.

— Thông minh. Quỳ xuống.

— Một câu hỏi thôi. — Lục Trầm nói. — Cuốn sổ trong tay ngươi, trận này đọc từ đó, hay đọc từ đá?

— Đá chép theo sổ. Có gì khác nhau?

— Khác nhau ở chỗ, — Lục Trầm nói, đi đến sát phiến đá đen giữa đài, — đá không phân biệt ai viết.

Hắn đặt lòng bàn tay phải lên mặt đá.

Đá lạnh buốt dưới tay. Mu bàn tay hắn chợt lóe vàng, trong tay áo, mảnh giấy rung lên nóng rực.

*Viết!* Hắn nghĩ.

*"Viết cái gì?!"*

*Tế danh. Thêm một người nữa.*

Chữ vàng chảy ra từ đầu ngón tay, loang trên phiến đá như mực ướt, từng nét sắc nhọn, ngay ngắn, lần này không sai một nét:

**PHƯƠNG NGỌC THÀNH.**

Cả tế đài rung lên.

Phương Ngọc Thành nhìn chằm chằm dòng chữ vàng hiện giữa đá đen, và sắc mặt y đổi hẳn.

— Ngươi… ngươi *viết*?

— Sổ của ngươi thì ngươi giữ. — Lục Trầm nói. — Còn đá thì ta viết.

Y vứt dao găm, lao tới giật sổ, xé toạc từng tờ, bật lửa trong lòng bàn tay mà đốt. Giấy bốc cháy, vụn tro bay lên. Nhưng dòng chữ vàng trên đá không hề lay động.

— Sổ hỏng thì xé. — Lục Trầm nói, giọng đều đều. — Nhưng chữ trên đá, ngươi định đập sao?

Xích trắng từ dưới chân đài vươn lên, quấn lấy Phương Ngọc Thành, từ mắt cá chân lên đến vai. Y gầm lên, vung kiếm chém, kiếm bay ra như một vệt chớp, vạch đúng một tấc cách cổ Lục Trầm, rồi dừng lại. Lưỡi kiếm run, rồi buông xuống. Cánh tay y bị xích quấn chặt như một con rắn nuốt mồi.

— Ngươi không có quyền… — Y nghẹn. — Ta mới là người lập khế!

— Ngươi lập khế. — Lục Trầm đáp. — Nhưng ngươi không đổ máu. Trận cần một cái tên ngươi dám trả bằng da thịt. Ngươi không dám, giờ ta trả giúp.

Y há miệng toan hét, nhưng giọng y nhỏ dần, nhỏ dần như bị rút. Một thứ gì sáng trắng, mờ như khói, bốc ra từ ngực y, trôi qua xích, chảy vào đá đen. Ánh mắt y từ phẫn nộ chuyển sang kinh hãi, rồi từ kinh hãi chuyển sang trống rỗng.

Xích trắng lỏng ra khỏi Đa Đa, lão Thất, Tri Vi, rồi cả Thanh Dao. Tất cả đều ngã xuống, thở dốc. Huyết Nha đệ đệ mặt xám như tro, quay đầu bỏ chạy. Thanh Dao với lấy thanh kiếm, cổ tay còn run, một tia bạc phóng ra, và y ngã xuống giữa chừng, không kịp kêu.

Mọi thứ im lặng.

---

Phương Ngọc Thành ngồi bệt giữa tế đài, tay buông xuống, mắt ngơ ngác nhìn lên bầu trời trắng đục. Không còn xích, không còn dao, không còn nụ cười.

— Ta… là ai? — Y hỏi, giọng nhẹ bẫng.

Không ai đáp.

Tri Vi bò đến, tay run, cầm cổ tay y bắt mạch, mặt tái dần.

— Y còn sống, thân thể không sao. — Nàng thì thầm. — Nhưng tên… y không còn nhớ tên mình. Mà thần hồn như bị lấy mất một mảng.

Lục Trầm nhìn gương mặt trống rỗng ấy. Hắn không thấy hả hê. Hắn thấy lạnh. *Đây là cái giá khi một người mất tên.* Hắn nghĩ. *Còn ta thì sinh ra đã không có.*

*"Tiểu tử."* Lão Chỉ nói khẽ. *"Ngươi vừa làm chuyện mà ngay cả bản tọa cũng… cũng kinh ngạc."*

— Ngài viết đúng cả.

*"Tất nhiên."* Giọng nó run, nhưng vẫn kiêu hãnh. *"…Bản tọa tưởng mình sẽ viết sai."*

Đa Đa lồm cồm bò dậy, vẫn nắm chặt một vật trong tay. Gã mở ra, một chiếc răng nanh đỏ rơi xuống nền đá.

— Tại hạ giật được từ cổ y. — Gã thở hồng hộc. — Cái này bán… bán được giá.

Lục Trầm nhìn gã thật lâu, rồi bật cười, một tiếng cười nhẹ như hơi thở. Thanh Dao cũng nhìn, môi hơi động.

Chính lúc ấy, phía trước tế đài, phiến đá trắng ở giữa bất ngờ nứt ra, từ khe hở trào ra thứ ánh sáng sữa, ấm áp, thơm như mùi mưa đầu mùa. Dưới đáy hố, không biết từ lúc nào, một hồ nước trắng đục đã mở ra, phẳng lặng như một tấm gương. Trên mặt hồ, những sợi hơi sương cuộn thành chữ.

Không phải chữ. Là những nét bút đang chậm chạp tự vẽ, chưa thành hình.

— Nhũ… — Lão Thất lắp bắp.

— Không phải. — Lục Trầm nói, đứng thẳng người, nhìn xuống mặt hồ. — Thứ này không có danh.

Hắn bước xuống một bậc, hai bậc. Càng xuống, hắn càng cảm thấy trong lồng ngực một thứ gì đó từ lâu ngủ yên đang thức dậy. Mu bàn tay phải nóng lên, nóng như sắt nung, ba chữ cổ triện lại hiện ra vàng rực.

Phía sau, giọng Phương Ngọc Thành vọng lại, nhỏ như tiếng thì thầm của kẻ đã mất hồn:

— …Người ấy… cũng có bút… không mực…

Hắn quay đầu. Gã áo trắng không còn nhìn ai, chỉ ngồi đó, nước mắt chảy lặng lẽ xuống má.

Không ai biết người ấy là ai.
