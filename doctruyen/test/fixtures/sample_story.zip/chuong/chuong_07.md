# Chương 7: Thiếu Nữ Lạc Đường

Quán trọ Thập Lý Đình nằm ngay chỗ quan đạo chia ba ngả, hai tầng gỗ sơn đỏ đã bạc, treo mười hai chiếc đèn lồng. Ba ngày nay, bất kể giờ nào, trong quán cũng chật cứng người.

Lục Trầm đội nón tre sụp xuống mày, ngồi ở góc trong cùng, lưng dựa vào cột gỗ. Khách trong quán phần lớn là tán tu và đệ tử tông môn nhỏ, đao kiếm treo đầy vách. Họ nói chuyện rất nhỏ, nhưng thỉnh thoảng hai chữ "Tàng Vân" lại nổi lên như bọt trên mặt nước sôi.

— Lục huynh, huynh nghe thấy chưa? — Tiền Đa Đa ghé sát, miệng nhồi đầy thịt hầm. — Nghe nói phía Lạc Phong có một bí cảnh cổ sắp mở, tên là Tàng Vân. Nơi nào có bí cảnh, nơi đó có tiền.

— Nơi nào có bí cảnh, nơi đó có người chết. — Lục Trầm đáp.

— Cũng là tiền. Người chết cần quan tài.

Lục Trầm quyết định không cãi. Sau cuộc chạm trán ở trại sơn tặc, hai người đã đi liền ba ngày trên quan đạo. Đa Đa muốn đến Lạc Phong, nơi Tiền gia có một chi hiệu buôn, đủ để gã rút tiền và mua một cỗ xe ngựa tử tế. Lục Trầm muốn đến đó vì một lý do khác: ở nơi đông người, một kẻ không tên sẽ ẩn mình như giọt nước giữa sông.

*"Tiểu tử."* Giọng Lão Chỉ khe khẽ vang lên từ trong tay áo. *"Nơi này hơi ồn."*

— Ngài vừa ngủ dậy.

*"Bản tọa không ngủ. Bản tọa nhập định."*

— Vậy ngài nhập định rất ngáy.

Lúc ấy cửa lớn bị đẩy ra.

---

Người bước vào là một thiếu nữ.

Nàng khoác bạch y, dáng người thanh mảnh, thanh trường kiếm vỏ bạc đeo ngang eo. Khuôn mặt nàng đẹp theo cách của băng tuyết, đẹp mà không ai dám nhìn lâu: đôi mày dài, mắt phượng, sống mũi thẳng, cặp môi mím chặt như chưa bao giờ biết cong lên. Trên người nàng không dính một hạt bụi, thế nhưng tóc lại lộ ra mấy cọng cỏ khô, giống như nàng vừa từ ruộng nào đó chui ra.

Cả quán trọ bỗng lặng đi một nhịp.

Lục Trầm không cần Lão Chỉ nhắc cũng đã cúi đầu, kéo vành nón thấp thêm một tấc. Bạch y, kiếm, mặt lạnh như sương. Lão Từ đã tả không sai chữ nào.

*"Chính là nàng."* Lão Chỉ nói nhỏ. *"Đừng nhúc nhích. Đừng thở mạnh. Đừng… làm bất cứ điều gì ngu xuẩn."*

— Ngài đang nhắc ta hay nhắc ngài?

*"Cả hai."*

Thiếu nữ quét mắt một vòng. Gã chủ quán, một người đàn ông trung niên gầy gò, vội vàng chạy ra, nở nụ cười nịnh nọt:

— Cô nương dùng cơm hay ở trọ?

— Một bàn.

— Hết bàn rồi, cô nương. Tàng Vân sắp mở, khách từ khắp nơi kéo đến, quán tiểu nhân…

— Đó. — Thiếu nữ chỉ tay.

Ngón tay nàng chỉ thẳng vào góc trong cùng.

Lục Trầm nghe tiếng thịt hầm rơi xuống đĩa.

— Bàn kia còn một chỗ.

— Cái đó… cô nương, bàn ấy có khách…

— Ta ngồi chung. — Nàng nói, đơn giản như tuyên bố một sự thật hiển nhiên về trời đất. — Ta không làm ồn.

Nói rồi nàng bước thẳng tới, chân đi rất nhanh, rất dứt khoát, đến mức hai gã tu sĩ đang đứng chắn lối phải nghiêng người nhường đường. Nàng dừng lại bên bàn, nhìn xuống Đa Đa, rồi nhìn sang Lục Trầm, nghiêng đầu.

— Hai vị cho phép chứ?

Đa Đa nuốt cục thịt, mắt tròn như hai hạt đậu đen.

— T-tất nhiên! Đương nhiên! Tại hạ là Tiền Đa Đa, vị này là Lục… Lục… Lục là Lục… gia nhân của tại hạ!

Lục Trầm nhắm mắt trong một nhịp thở.

— Ngươi tên Lục? — Thiếu nữ nhìn hắn.

— Tại hạ, Lục… A Ngưu. — Hắn nói, giọng cố tình trầm đục, mắt nhìn xuống mặt bàn. — Người hầu của thiếu gia nhà họ Tiền. Cô nương cứ tự nhiên.

— Ngươi gầy quá. — Nàng nói. — Chủ ngươi không cho ngươi ăn sao?

— Tại hạ… ăn ít để tu luyện.

— Phàm nhân không tu luyện được bằng cách ăn ít.

— …Vâng, cô nương nói rất đúng.

Nàng không nói gì thêm, ngồi xuống đối diện hắn, đặt kiếm lên bàn. Trên người nàng phảng phất mùi hương dịu mát, nửa như mực, nửa như sương lạnh, thứ mùi mà hắn từng ngửi ở quán rượu cuối phố, trên người một kẻ bạch y khác.

Thiên Thư Các. Không sai.

---

Nàng gọi món theo cách khiến cả quán phải im lặng.

— Có món gì chín nhanh nhất?

— Mì nước, cô nương. Một chén trà công phu. — Tên tiểu nhị đáp.

— Cho ta mì. — Nàng rút từ trong ngực ra một nén vàng nhỏ bằng ngón tay cái, đặt lên bàn. — Đủ chưa?

Tiểu nhị nhìn nén vàng, miệng há ra không nói được. Nén ấy mua được ba mươi chén mì.

— Vậy mua ba mươi chén. — Nàng nói. — Ta ăn một, còn lại cho người ngoài cửa.

Đa Đa bên cạnh nhìn nén vàng với ánh mắt của kẻ đang chứng kiến sự lãng phí thần thánh.

— Cô nương. — Gã cố giữ giọng thật nhã. — Phần còn lại sau khi trả gọi là tiền thừa, nó thuộc về cô nương.

— Ta không biết có chuyện đó. — Nàng đáp thẳng thừng. — Từ nhỏ ta chưa từng mang tiền.

Lục Trầm suýt nữa đã ngẩng lên nhìn. Lão Chỉ thì dõng dạc hơn nhiều:

*"Thiên Thư Các nuôi ra thứ gì thế này? Cầm kiếm giỏi hơn trời, mà không biết mua một chén mì."*

— Nhỏ tiếng. — Hắn đáp thầm.

*"Nàng ta không nghe thấy bản tọa."*

— Ngài đang nghĩ tới cảnh nàng ta nghe thấy.

*"…Bản tọa im."*

Tiền Đa Đa thế là tự nguyện làm người hướng dẫn, kiên nhẫn giảng giải cho vị cô nương cầm kiếm về việc trả tiền. Nàng nghe rất chăm chú, rồi hỏi một câu khiến cả bàn lặng đi:

— Ngươi mập như vậy, có phải ăn nhiều lắm không?

— Hả? — Đa Đa chết đứng.

— Ta hỏi thật. Ta chưa gặp người nào có thân hình như ngươi.

— Đó là… phúc tướng! — Đa Đa ưỡn ngực, mặt đỏ bừng. — Người trong thương giới gọi là phúc tướng!

— Phúc tướng là gì?

— Là… là mập! Mập nhưng có phúc!

— À. — Nàng gật đầu nghiêm túc. — Vậy là mập.

Lục Trầm cúi đầu, dùng một miếng thịt hầm che khóe miệng. Hắn tự nhắc mình phải bình tĩnh. Nhưng một thiếu nữ lạnh như băng mà đối đáp bằng giọng của một học trò nghiêm túc ghi chép từ ngữ, quả thực rất khó lòng giữ sắc mặt.

---

Mì được bưng lên. Nàng cầm đũa như cầm kiếm, nhìn chén mì một hồi rồi mới bắt đầu ăn. Ăn được nửa chén, nàng bỗng dừng đũa, nhìn chăm chú vào Đa Đa.

— Ngươi.

— Ta? — Đa Đa giật nảy.

Nàng thò tay vào áo, rút ra một tờ giấy gấp nhỏ, mở ra, đặt lên mặt bàn. Chính là bức chân dung truy nã mà Lục Trầm đã thấy ở thôn lão Từ.

Cái mặt tròn như bánh, hai má phính, mắt tí hon, cằm hai ngấn.

Nàng nhìn bức vẽ, nhìn Đa Đa, rồi lại nhìn bức vẽ.

— Rất giống. — Nàng kết luận.

Đa Đa rụng cả đũa.

— C-cô nương! Cô nương hiểu lầm rồi! Tại hạ là Tiền gia thiếu chủ chính hiệu, không phải dị số! Đây là… đây là họa sư vẽ sai!

— Ta không nói họa sư vẽ sai. Ta nói ngươi giống.

— Giống thì có sao?

— Không có sao. Chỉ cần kiểm tra. — Nàng lại thò tay vào áo.

Lần này là một tấm gương nhỏ, to bằng lòng bàn tay, viền bạc khắc hoa văn quen thuộc. Mệnh Giám cầm tay. Nàng đặt nó lên bàn, đẩy về phía Đa Đa.

— Đặt tay lên.

Đa Đa mặt xám như tro. Trong một thoáng gã quay sang Lục Trầm bằng ánh mắt của con cừu bị đẩy lên thớt. Lục Trầm không nhúc nhích.

— Lục… A Ngưu. Ngươi có cách nào…

— Tại hạ chỉ là người hầu. — Lục Trầm đáp.

*"Cái đồ vô lương tâm."* Lão Chỉ thở dài.

Đa Đa nuốt nước bọt, nghiến răng, đặt cái tay mập mạp lên mặt gương. Gương sáng lên, từng dòng chữ vàng hiện ra.

*Tiền Đa Đa. Kim linh căn hạ phẩm. Đại phú đại quý. Thọ tám mươi.*

Thiếu nữ nhìn những dòng chữ rất lâu, rồi gật đầu, thu gương lại.

— Ngươi có mệnh. — Nàng nói. — Mệnh khá tốt. Tám mươi là nhiều. Ngươi không phải dị số.

— Thấy chưa! Tại hạ đã nói! — Đa Đa hét lên, thở hồng hộc, rồi bỗng như nhận ra điều gì, gương mặt gã vừa nhẹ nhõm vừa tủi thân. — Nhưng mà cô nương nói "tám mươi là nhiều", tại sao nghe như cô nương thất vọng?

— Không. Ta chỉ nghĩ, người giống bức tranh mà không phải bức tranh, thật lãng phí thời gian. — Nàng lắc đầu. — Tranh vẽ sai.

Nàng quay sang Lục Trầm. Hắn cảm thấy tim đập mạnh hơn một nhịp.

— Ngươi cũng thử đi.

— Tại hạ…

— Chỉ là thủ tục.

— Cô nương. — Lục Trầm khàn giọng. — Tại hạ… hôm trước bị thương ở tay, ngón tay rất đau, không tiện đặt lên gương…

Nàng nhìn hắn từ đầu đến chân, ánh mắt không mang chút ác ý, chỉ là cách nhìn thẳng của một người chưa từng học cách che đậy suy nghĩ.

— Ngươi gầy. — Nàng nói. — Dị số trong tranh mập. Không cần.

Rồi nàng cúi xuống, tiếp tục ăn mì.

Lục Trầm ngồi chết lặng, cảm giác như vừa được bỏ qua một lưỡi dao bằng lý do hoang đường nhất thiên hạ. Dưới bàn, Đa Đa dùng đầu gối thúc hắn một cái, ánh mắt đầy ý ai oán: *Huynh gầy là tội gì mà ta mập là bị nghi?*

*"Lần đầu tiên bản tọa thấy gầy là một loại bảo hộ."* Lão Chỉ trầm ngâm.

---

Thẩm Thanh Dao ăn xong chén mì, đặt đũa xuống, nhìn ra cửa sổ.

Nàng đã đi lạc ba ngày. Đúng hơn, nàng không thừa nhận mình lạc, chỉ thừa nhận con đường dài hơn dự tính. Mỗi lần có người bảo rẽ trái, nàng đi thẳng; mỗi lần có người bảo đi thẳng, nàng thấy rẽ phải mới hợp lý. Rốt cuộc nàng gặp một tảng đá khắc chữ "Thập Lý Đình" và quyết định ở lại nghỉ chân, bởi nơi này có đèn, có người.

Nàng mười bảy tuổi, thiên tài kiếm tu của Thiên Thư Các, Trúc Cơ hậu kỳ. Nàng được giao nhiệm vụ này vì mệnh trang của nàng rất đặc biệt, hay nói đúng hơn, vì nàng đã đọc mệnh trang của mình từ năm tám tuổi.

Hôm ấy nàng nhớ rõ. Trong đại điện lạnh lẽo ngập hương trầm, chữ vàng nổi lên chậm rãi trên Mệnh Giám lớn nhất. *Kiếm cốt thiên sinh.* Các trưởng lão đồng loạt gật đầu mãn nguyện. Nhưng một vị trưởng lão chợt im bặt, bàn tay đặt trên mặt gương khẽ run.

Dòng cuối cùng chỉ có sáu chữ.

*Tuổi hai mươi, chết dưới kiếm.*

Nàng đã đọc được nó trước khi vị trưởng lão kịp che đi. Một đứa trẻ tám tuổi không hiểu thế nào là cái chết, nhưng hiểu hai chữ "kiếm" và "hai mươi". Từ hôm đó, nàng cầm kiếm.

Nàng không sợ chết. Nàng chỉ ghét việc *không biết* mình chết thế nào. Kiếm của ai? Của kẻ thù, của đồng môn, hay của chính nàng? Nàng quyết định rằng cách duy nhất để thoát khỏi lời tiên đoán là trở thành người cầm kiếm giỏi đến mức không ai dám rút kiếm trước mặt nàng.

Còn ba năm. Mệnh trang chưa bao giờ ghi sai.

Nàng chớp mắt, kéo ý nghĩ trở về. Đối diện nàng, tên mập đang lẩm bẩm gì đó về nén vàng, người hầu gầy gò vẫn cúi đầu uống trà chậm rãi, như đang đọc một cuốn sách vô hình.

Người hầu ấy… hơi khác.

Nàng không rõ khác ở đâu. Chỉ là từ lúc ngồi xuống, nàng cứ có cảm giác nhìn hắn thì trong đầu có một điều gì đó trống rỗng, như khi bước nhầm một bậc thang không có.

---

— Tại hạ xin phép đi lấy thêm giấm.

Lục Trầm đứng dậy. Bát giấm trên bàn thật sự đã cạn, là một lý do hợp lý để rời bàn mà không gây nghi ngờ. Hắn không nghĩ nhiều hơn.

Đó là sai lầm.

Quầy thu ngân nằm ở phía bên kia sảnh. Trên đầu quầy, treo lủng lẳng một chiếc chuông đồng nhỏ khắc đầy hoa văn li ti. Lục Trầm nhớ ra ngay khi bước chân đã đi được nửa đường.

*Báo Mệnh Linh.*

Hắn muốn quay lại. Nhưng đúng lúc đó, phía sau lưng hắn vang lên tiếng hò hét, một gã tu sĩ say rượu loạng choạng lách qua, huých vai hắn một cái đau điếng, đẩy hắn chúi thẳng đến bên quầy, chỉ cách chiếc chuông chưa đầy một trượng.

*Đinh.*

Chuông kêu, trong trẻo.

Kêu cho gã tu sĩ say.

Còn với hắn, im lặng.

Tên tiểu nhị chạy qua. *Đinh.* Một vị khách khác đến thanh toán. *Đinh.* Gã chủ quán từ phòng trong ló ra, *đinh.* Chiếc chuông reo rộn ràng như có hội, cho tất cả mọi người, ngoại trừ một thiếu niên đội nón tre đứng ngay dưới nó.

*"…Tiểu tử."* Giọng Lão Chỉ khô khốc. *"Ngươi biết ta đang nhìn gì không?"*

— Biết. — Lục Trầm đáp, không động đậy môi.

Hắn lấy bình giấm, đặt tiền xuống, rồi từ từ xoay người.

Thiếu nữ áo trắng đang nhìn hắn.

Từ phía bên kia sảnh, qua mấy chục cái đầu người, đôi mắt phượng của nàng khóa chặt lên hắn, và lần đầu tiên đôi mắt ấy không còn lạnh. Nó sắc. Sắc như mũi kiếm vừa rút khỏi vỏ.

Nàng buông đũa xuống bàn, rất nhẹ.

Rồi nàng cầm lấy thanh kiếm.
