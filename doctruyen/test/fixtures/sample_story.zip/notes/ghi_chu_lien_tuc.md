# GHI CHÚ LIÊN TỤC: 《Thiên Thư Vô Danh》 (dựng lại từ chương 1–6)

## Nhân vật
- **Lục Trầm** ("hắn"): 15 tuổi, mồ côi, được lão Hoàng nhặt ở bờ suối (lão kể mỗi lần một khác). Điềm tĩnh, mồm độc, tính trước vài bước, "cái gì cũng chết được trừ cái mồm". Đói là bản năng. Luyện Khí tầng 1. Mệnh Giám không hiện chữ. Tay phải có vết bỏng đỏ thẫm (nét 37). Gọi Lão Chỉ là "ngài".
- **Lão Hoàng**: chủ quán rượu "Hoàng Tửu" ở cuối phố Thanh Thạch; say, lôi thôi, "lão tử"; gọi Lục Trầm "tiểu tử". Thực chất cao nhân: thanh đao cũ dài một thước tám, vỏ mục, chém nước mưa thành hai nửa; "ba mươi năm rồi, ngươi vẫn còn sắc". Hàn Mặc gọi lão là **Đao Quỷ**, nói người đó "đã chết ba mươi năm trước". Ch3 lão chém một đao rạch trời, quán biến mất; lão mất tích, sống chết chưa rõ. Lời cuối: "Rượu chua trẻ con uống hại bao tử". Lục Trầm còn bị nợ "ba tháng tiền công quét sân".
- **Hàn Mặc**: Chấp Bút Sứ, ~30 tuổi, bạch y, ô giấy trắng, trâm bút ngọc + bút dài như quạt xếp; Kim Đan (uy áp); viết chữ khổng lồ ("Tử") để giết. Lịch thiệp, nói giết người là "từ bi". Hoảng loạn khi nhận ra Đao Quỷ. Sau ch3 sống chết chưa rõ.
- **Ngô Văn Bình**: chấp sự Thiên Thư Các vùng tây nam, mặt tròn như bánh bao, "y"; đập Mệnh Giám ba lần. Sợ Hàn Mặc.
- **Tiểu Đậu** (con Vương đại nương bán đậu phụ), **Vương đại nương** (bà cho 4 miếng đậu), **lão Mạnh** (giữ miếu Thổ Địa, 80 tuổi): người Thanh Thạch.
- **Tiền Đa Đa** ("gã"): ~16 tuổi, mập tròn, mắt nhỏ lanh, con độc nhất của Tiền Vạn Quán (thương hội Tiền gia, Lâm Giang, ba châu). Mệnh trang "đại phú đại quý, thọ tám mươi". Gọi Lục Trầm là "Lục huynh", xưng "tại hạ"/"ta". Tham, nhát nhưng lanh, có bàn tính/sổ sách bìa da, túi tiền (lấy cả túi thủ lĩnh sơn tặc làm "phí tinh thần"). Chân dung truy nã Lục Trầm trông giống gã hơn.
- **Thẩm Thanh Dao** ("nàng"): chỉ xuất hiện gián tiếp ở ch6: cô nương áo trắng, đeo kiếm, mặt lạnh như sương, hỏi đường tới Thanh Thạch rồi đi ngược hướng nam; hỏi kẻ "không có tên".
- **Lão Từ**: bán bánh bao nhân thịt ở thôn nhỏ gần quan đạo (cách Thanh Thạch hai ngày đường).
- **Lão Chỉ** (xem dưới).

## Lão Chỉ
Linh thức trong mảnh giấy rách vàng ố to bằng lòng bàn tay (lão Hoàng nhét vào ngực áo nhiều năm). Tỉnh vì Lục Trầm là "trang trắng". Tự xưng "bản tọa", "đệ nhất cao nhân vạn cổ, Chí Tôn Chỉ Linh"; gọi hắn "tiểu tử". Nói thẳng vào đầu hắn (chữ nghiêng trong *"..."*); muốn thì viết chữ vàng cho người khác đọc. Mất trí nhớ, khoác lác, nhát, hay mắng người viết sai chữ. Nhớ ra: Chỉ Hạc Truy Tung, Báo Mệnh Linh, Bạch Chỉ Quyết (tự hiện trong đầu). Sợ cái tên "Đao Quỷ" ("đừng nhắc"), nghe "Hoàng" thì thấy "chua". Nói quá nhanh khi che giấu chuyện ba chữ "Vị chung quyển". Thì thầm: "Giấy trắng có người viết trước… tờ giấy trắng này rốt cuộc là của ai?"

## Địa điểm
Trấn Thanh Thạch (đá xanh, mưa dầm; miếu Thổ Địa, chuông đồng, cổng trấn; quán Hoàng Tửu đã bị phá hủy, nứt dài hàng chục trượng). Núi sau trấn (sơn động nơi tu luyện). Trại sơn tặc (đã bị lừa). Thôn nhỏ của lão Từ gần quan đạo. Lâm Giang (nhà Đa Đa).

## Vật phẩm / pháp khí
- **Mệnh Giám**: gương đồng soi mệnh trang (linh căn, thọ nguyên). Bản chính to bằng mâm; có bản nhỏ dự phòng; sơn tặc có mảnh vỡ. Gương của Lục Trầm luôn trắng.
- **Chỉ Hạc Truy Tung**: hạc giấy trắng cỡ bàn tay, ngậm hạt sáng, đọc mệnh số tìm người; với Lục Trầm chỉ tìm được dấu vết (bùn, cành gãy, mùi).
- **Báo Mệnh Linh**: chuông đồng nhỏ khắc ký tự, kêu khi người có tên vào trong ba mươi trượng; không kêu với Lục Trầm.
- **Mảnh giấy Lão Chỉ** (xem trên). Lục Trầm dùng nó viết "VÔ THƯỜNG SỨ GIẢ ĐẾN THU MỆNH" để dọa sơn tặc (Đa Đa chê viết sai chữ "thu").
- Giấy truy nã: "TRUY NÃ DỊ SỐ, LỤC TRẦM, 15 TUỔI, THANH THẠCH, bắt sống thưởng 500 linh thạch", hình vẽ giống Đa Đa.

## Bạch Chỉ Quyết
- Khẩu quyết: "Thiên vô thư, ngã tự thư. Bạch chỉ vô cương."
- Tự "viết" kinh mạch lên người, mỗi nét là một đoạn. Quy tắc: (1) không sao chép, mỗi nét phải hiểu mới viết; nét chưa hiểu mà ép viết thành vết sẹo; (2) không xóa; (3) ban đầu rất chậm, không có bình cảnh định sẵn.
- 108 nét mở linh khiếu đầu tiên. Rất đau (như đục khắc lên xương). Nét 1 mất một canh giờ. Nét 37 viết sai: vệt bỏng đỏ thẫm trên tay phải. Nét 60 linh khí "được mời". Hoàn thành sau ba ngày ba đêm: Luyện Khí tầng 1.
- Khi xong, tay phải hiện chữ vàng rồi tắt; ba chữ cổ triện lớn **"Vị chung quyển"** (chưa hết quyển), không phải Lão Chỉ dạy. Lão Chỉ lảng tránh.
- Công pháp thường (Thái Thanh Dẫn Khí Quyết) vô dụng với hắn.

## Cảnh giới
Lục Trầm Luyện Khí 1. Sơn tặc: sẹo mặt/tay chân tầng 2–3, thủ lĩnh một mắt ~tầng 4. Hàn Mặc Kim Đan. Lão Hoàng không rõ (rất cao). Trúc Cơ có thể tịch cốc.

## Bí ẩn đã gieo
Lão Hoàng/Đao Quỷ là ai, "chết ba mươi năm trước"; mảnh giấy là gì; ba chữ "Vị chung quyển" ai viết; dị số không tên nghĩa là gì; vì sao truy nã "bắt sống"; Lão Chỉ sợ Đao Quỷ.

## Dòng thời gian
Ngày 1: khảo hạch (ch1), chiều/đêm (ch2). Ngày 2: Hàn Mặc đến, lão Hoàng chặn, Lục Trầm bỏ chạy (ch3); đêm trong động, gặp Lão Chỉ (ch4). Ngày 3–5: luyện 108 nét (ch5). Ch6 mở bằng "ngày thứ năm" (hơi lệch với ch5; coi là ngày 5–6): xuống núi, cứu Đa Đa, vào thôn lão Từ lúc canh một.

## Trạng thái cuối ch6
Đêm, trong thôn lão Từ. Lục Trầm + Đa Đa vừa kết bạn đồng hành, ăn bánh bao. Thấy giấy truy nã và biết một nữ kiếm tu Thiên Thư Các hỏi đường Thanh Thạch rồi đi ngược hướng (nam), hỏi kẻ "không có tên". Lão Chỉ cảnh báo người đuổi không còn chỉ là hạc giấy.

---

## Chương 7–10 (mới)

### Thẩm Thanh Dao ("nàng")
- 17 tuổi, đệ tử thiên tài của Thiên Thư Các, **Trúc Cơ hậu kỳ** (Lão Chỉ nhận ra ở ch8). Cao gầy thanh mảnh, bạch y, mắt phượng, mặt lạnh; trong tóc hay dính cỏ. Nói thẳng phũ ("Ngươi mập", "Ngươi che đèn"), không nói dối được (đến ch10 mới có "chưa nói hết": báo chi các là "đang truy, chưa xác nhận mục tiêu"; lời nói dối thật sự đầu tiên vẫn dành cho ch14). Mù đường: luôn làm ngược lời chỉ đường, tin mình "không lạc"; không biết trả tiền/tiền thừa (dùng nén vàng trả mì), không biết nấu (đun cháy nước/cháo), chưa từng ăn mứt quả (ăn xâu mứt đầu tiên ở ch10, "Ngọt").
- Kiếm: thanh kiếm vỏ bạc rèn từ **thiết Thiên Thư**, chỉ chém được thứ có tên trong sổ; không cắt được da Lục Trầm (chỉ trượt như đặt lên mặt nước). Kiếm quyết: **Chiếu Mệnh Kiếm Quyết** (thấy "sợi chỉ mệnh" quanh mỗi người rồi kiếm đi theo; ở Lục Trầm chỉ thấy "khoảng trống như giếng không đáy"). Nhưng thân xác Lục Trầm vẫn bị thương bởi nắm đấm/đòn vật lý bình thường (nàng nói có thể bẻ cổ hắn).
- Mệnh trang: "Kiếm cốt thiên sinh... Tuổi hai mươi, chết dưới kiếm." (đọc từ năm 8 tuổi, trong đại điện Thiên Thư Các). Còn khoảng ba năm. Không sợ chết, chỉ ghét "phải biết trước". Mang **Mệnh Giám cầm tay** (to bằng lòng bàn tay, viền bạc), lệnh bài bạch ngọc, **truyền thư hạc** (khác Chỉ Hạc Truy Tung: chỉ tìm nàng).
- Phát hiện: khi Lục Trầm đứng trong vòng ~1 trượng, dòng cuối mệnh trang của nàng **nhòe** (chữ "chết dưới" gần tan), lùi ra xa thì rõ lại. Đã thử kiểm tra ba lần ở ch9; đến ch10 nàng liếc xuống tay áo hắn như muốn kiểm tra lại.
- Dáng nàng khi đi: cứ chọn đường thẳng; sau ch10 có thói quen liếc nhìn Lục Trầm ở ngã rẽ, chờ hắn gật/lắc. Thỉnh thoảng vành tai ửng hồng khi bị chọc.

### Thỏa thuận (ch9)
Nàng không giết, không trói; đi cùng Lục Trầm đến Lạc Phong để theo dõi; hắn trả lời mọi câu hỏi, không che giấu (hắn vẫn giấu mảnh giấy Lão Chỉ và Bạch Chỉ Quyết). Điều kiện của hắn: hắn chỉ hướng; nàng không nấu ăn; hắn nói "làm ơn dừng" thì nàng dừng khi hợp lý. Bắt tay (chạm đầu ngón tay một nhịp). Nếu nàng kết luận hắn là mối họa thì sẽ ra tay.

### Chi tiết khác
- Lục Trầm dùng tên giả **"Lục A Ngưu"** (người hầu của thiếu gia họ Tiền) ở quán trọ **Thập Lý Đình** (quan đạo chia ba ngả, cách thôn lão Từ ba ngày đường về phía nam; Thanh Thạch cách thôn hai ngày về phía bắc). Trên quầy quán có **Báo Mệnh Linh** kêu cho 17 người nhưng không kêu cho Lục Trầm: đó là chỗ Thanh Dao nhận ra. Lục Trầm đội nón lá. Sau ch8, chủ quán đuổi khéo ba người đi.
- Đa Đa bị Thanh Dao nghi trước vì mặt giống chân dung; soi Mệnh Giám của nàng: "Tiền Đa Đa. Kim linh căn hạ phẩm. Đại phú đại quý. Thọ tám mươi." Đa Đa đỡ kiếm thay Lục Trầm, đề nghị bản đồ có mũi tên; thành thương nhân đại tài ở Lạc Phong (mua cả kho nón lá/áo tơi/lều của lão thương nhân phá sản, bán bản đồ vẽ bừa 10 linh thạch/tờ). Nhà Tiền gia có chi hiệu buôn ở Lạc Phong.
- Giấy truy nã gốc ghi "bắt sống" (500 linh thạch); Lục Trầm suy ra Thiên Thư Các cần hắn còn sống, lý do chưa rõ. Đến ch10, tờ cáo thị mới ở Lạc Phong vẽ đúng mặt Lục Trầm (gầy, cằm nhọn, mắt dài), "thưởng gấp mười".
- Lão Chỉ chỉ nói với Lục Trầm, Thanh Dao chưa biết. Mảnh giấy nóng lên khi đi ngang một tấm bia con khắc cổ ngữ ở sạp đồ cổ Lạc Phong ("Thượng cổ di vật từ Tàng Vân") và nóng rực khi thấy quy định Tàng Vân; Lục Trầm có cảm giác mình "phải vào đó".
- Hàn Mặc **mất liên lạc mười ngày** với Thiên Thư Các sau khi đến Thanh Thạch; chưa rõ sống chết (Kim Đan). Chi các Lạc Phong: bạch tháp bảy tầng, chấp sự áo xám gác.
- **Bí cảnh Tàng Vân**: mở sau bảy ngày nữa (tính từ ngày Thanh Dao báo cáo), ở dãy núi ngoài thành Lạc Phong mười dặm. Thiên Thư Các cử người vào, Thanh Dao có tên trong danh sách. **Quy định**: mọi người phải soi Mệnh Giám tại cổng bí cảnh, kẻ không có tên không được vào (vấn đề cho ch11).
- **Thành Lạc Phong**: tường xám cao ba trượng, nằm trong thung lũng ba mặt núi, mặt còn lại hướng ra sông Bạch Lộ; cổng thành có hai Báo Mệnh Linh to bằng cái chậu, Thanh Dao dùng lệnh bài gọi họ là "tùy tùng của ta" để qua mà không bị soi; chợ Tây, phố bán binh khí, chợ ăn; khách điếm nhỏ gần chợ Tây (thuê hai phòng).
- Cảnh giới nhắc lại: Lục Trầm Luyện Khí 1; Thanh Dao Trúc Cơ hậu kỳ; Hàn Mặc Kim Đan.

### Dòng thời gian (ước)
Ngày ~6 (ch6 đêm, thôn lão Từ). Ngày ~9: Lục Trầm + Đa Đa đã đi ba ngày, tới Thập Lý Đình (ch7–8, tối). Đêm đó (canh hai) ở bờ suối, ký thỏa thuận (ch9). Sáng sau: truyền thư hạc. Hai ngày đường tới Lạc Phong (ngày ~12, ch10). Hôm sau Thanh Dao báo cáo ở chi các (ngày ~13); Tàng Vân mở khoảng 7 ngày sau (ngày ~20).

### Trạng thái cuối ch10
Trước tường chi các Lạc Phong, Lục Trầm đọc quy định "kẻ không có tên không được vào Tàng Vân" và thấy cáo thị mới vẽ đúng mặt mình. Thanh Dao đứng sau hắn chưa đầy một trượng. Đa Đa lo lắng. Mảnh giấy nóng ran. Chưa có cách vào bí cảnh.


---

## Chương 11–14 (mới)

### Giải quyết cổng Tàng Vân (ch11)
- Quy định: mười hai Mệnh Giám đồng trên dãy đài đá trước cổng đá cổ; chấp sự áo xám của Các; soi xong được phát **danh bài** bằng ngọc khắc tên. Lệnh mới sau vụ Ngô chấp sự: "gương lạ thì ĐỔI GƯƠNG, cấm đập" (Các cười Ngô ba tháng).
- Cách qua: Đa Đa đưa mệnh trang phó bản của **Tiền Phúc** (hộ viện Tiền gia, 25 tuổi, mộc linh căn hạ phẩm, thọ 52, hiện ở kho Lâm Giang). Lục Trầm hóa trang mặt tròn (bông nhét má, mày dày, áo vải thô), đặt tay lên gương, **Lão Chỉ viết chữ vàng** qua bàn tay: gương lạ chập chờn lần một (Lão Chỉ chối "gương xoay bút"), đổi gương số 10 thì hiện đủ. Thanh Dao nói đúng sự thật chưa đủ: "Ta đã thấy chữ vàng hiện lên trên gương" (không nói từ đâu ra). Lục Trầm có danh bài ghi *Tiền Phúc*. Thanh Dao biết có gian lận, chọn "không hỏi"; hứa không nói sai những gì mình thấy.
- Rủi ro đã gieo: Tiền Phúc là người thật; tên có thể bị điều tra (Phương đã dò hỏi người Tiền gia ở Lạc Phong, không ai biết hộ viện tên Phúc). Đây là động cơ cho "mệnh trang giả" ở ch15.
- Cổng đá Tàng Vân có TRƯỚC Thiên Thư Các (rêu già hơn); ánh trắng sữa, không vàng. Lúc mở, một sợi sương tách ra "mời" Lục Trầm. Lão Chỉ: "Cái cổng này nó vừa nhận ra ngươi", nhớ "cảm giác bước qua nó". Thanh Dao bị kéo sang cổng phụ cùng đội Các (bảy người, dẫn đầu **Tào Hạc Niên**, chấp sự trung niên mặt gầy như dao).
- Đa Đa kiếm bội tiền bán đấu lạp (nón rộng vành), bản đồ. Đoàn đi dài bảy ngày chờ, Tàng Vân mở lúc hoàng hôn ngày thứ tám (~ngày 20).

### Nhóm tạm thời (ch11–13)
- **Cổ lão Thất** ("lão"): tán tu, lưng còng, râu thưa, Luyện Khí 8, lần thứ ba vào bí cảnh, hay kể chuyện (mất ba ngón chân ở Hàn Vân Động). Ba quy tắc: đừng đi nhanh, đừng nhặt đồ rơi, đừng đáp tiếng gọi trong sương. SỐNG, ra khỏi bí cảnh; hứa kín miệng ("chỉ thấy một hộ viện tốt bụng").
- **Liễu Tri Vi** (nàng): Hồi Xuân Cốc, ~20 tuổi, Luyện Khí 7, đan sư/y sư, nhút nhát, nói chuyện với thảo dược, mang hòm thuốc. SỐNG; nhận chăm Phương, gọi y là "A Thành".
- **Phương Ngọc Thành** ("y"): ngoại môn "Bạch Vân Phái", ~28, Luyện Khí 9, kiếm cực nhanh (kiếm tự bật vỏ), luôn sạch sẽ. Manh mối đã gieo: mùi tro lạnh ở tay áo, liếc cáo thị lâu, chép tên mọi người vào sổ, ngón tay không dính máu khi điểm chỉ, mắt hay nhìn về khe đá chỗ có cổ trận. BẠI: bị cổ trận hút "danh", mất tên và ký ức, còn sống, thân thể không sao ("A Thành"). Lời cuối: có người trả công trước cả khi Thiên Thư Các dán cáo thị, nói Lục Trầm "nhất định vào Tàng Vân"; "người ấy cũng có bút... không mực" (KẺ BÍ ẨN CHƯA RÕ, sợi mồi cho sau này).
- **Huyết Nha song huynh**: áo đỏ sẫm, mặt trắng phấn, răng nanh đeo cổ; huynh Trúc Cơ trung kỳ (Thanh Dao giết bằng một kiếm vào "mệnh tuyến"); đệ Trúc Cơ sơ kỳ (bị kiếm Thanh Dao phóng trúng khi chạy, chết). Đa Đa nhặt túi/răng nanh/bình sứ.

### Trong bí cảnh
- Rừng đá xám (hàng trăm cột đá, rêu, dây leo trắng, trời không mặt trời) nơi nhóm ly tán rơi xuống. **Vân hồ** (cáo sương, bắt chước giọng nói; giả giọng Thanh Dao: "Ta không lạc"). **Bia đá không chữ** giữa khoảng trống tròn. **Tâm cốc**: khe núi hẹp, hố tròn mười trượng, tế đài đá đen, phiến đá đứng giữa. **Hồ linh nhũ trắng đục** (dưới đáy hố).
- Thanh Dao tìm nhóm bằng cách đi theo "sợi chỉ mệnh vàng dày bằng ngón tay" của Đa Đa (thấy từ ba dặm). Cô đã báo đội Các là "dò đường".
- Bí cảnh tống người ra sau ba ngày, đúng giờ Ngọ (chuông cổ).

### Bia đá (ch12): nội dung
Lục Trầm đặt tay phải lên bia, chữ cổ triện hiện màu TRẮNG (chỉ người không tên thấy). Lão Chỉ đọc được ("triện thể Trang Thứ Nhất").
1. **Tư Đồ Hoài Chỉ**, "Kẻ mở trang". 2. **Ôn Cửu Nương**, "Viết bằng máu". 3. **Thạch Bất Ngôn**, "Viết không lời". 4. **Lăng Hư Tử**. 5. **Diệp Trường Ca**. 6. **Ninh Vô Hối**. 7. TÊN BỊ CẠO SẠCH, chỉ còn một vệt chém dài rạch chéo (gợi Đao Quỷ, chưa khẳng định). 8. **Quan Nguyệt Nhi**. 9. **Mặc Trì**. Dưới cùng: một hàng trống; chú nhỏ mờ: *"Chín người vào trang. Một người ra, mang theo bút."* Sát chân bia: **"VỊ CHUNG QUYỂN"** (cùng ba chữ trên tay Lục Trầm) và *"Hậu lai giả, tục thư"* (kẻ đến sau, viết tiếp). Trên sườn bia có vết lõm hình chữ nhật mép xé khớp răng cưa mảnh giấy Lão Chỉ nhưng lớn gấp ba (mảnh giấy chỉ là một góc của một trang).
- Lão Chỉ nghe tên **Tư Đồ Hoài Chỉ** thì mất kiểm soát: thấy "một cái bàn dài, rất nhiều mực, mười người ngồi quanh, người đầu bàn quay lại gọi bản tọa là…" rồi quên sạch, chỉ còn cảm giác lạnh. (Chữ "Chỉ" trong tên cùng chữ với "Lão Chỉ".)
- Thanh Dao: không thấy gì trên bia; Lục Trầm đọc hết tên cho nàng (giữ lời hứa, chỉ giấu mảnh giấy). Nàng bàng hoàng: Các dạy "dị số là lỗi của Thiên Thư" và "Thiên Thư không bao giờ sai"; chín người thì "không còn là lỗi".

### Khế đồng hành và phản bội (ch12–13)
- Phương lập "khế đồng hành" trong sổ nhỏ: mỗi người điểm máu cạnh tên. Giọt máu của Lục Trầm không thấm vào trang (vì "Tiền Phúc" không khớp máu hắn). Thực chất là trận tế danh: ba danh tế mở cổng linh nhũ; Tiền Phúc không bị xích khóa (xích trượt khỏi hắn như nước trên lá sen) nên Phương nhận ra hắn là Lục Trầm.
- Cách lật: Lục Trầm đặt tay lên phiến đá, **Lão Chỉ viết chữ vàng "PHƯƠNG NGỌC THÀNH" làm tế danh** (trận cổ đọc chữ, không phân biệt ai viết). Phương xé/đốt sổ cũng vô ích ("Sổ hỏng thì xé, chữ trên đá ngươi định đập sao?"). Xích hút danh Phương; những người khác được thả. Lục Trầm cảm thấy lạnh: "đây là cái giá khi một người mất tên".
- Giới hạn của Thanh Dao: kiếm thiết Thiên Thư chỉ chém được cái có tên; xích cổ trận vô danh, kiếm bật ngược, nàng bị trói. Kỹ năng: kiếm xuất theo "mệnh tuyến", giết huynh trưởng Huyết Nha giữa ba huyết ảnh bằng một nhát. Hài: Lục Trầm bảo nàng đi bên trái, nàng đi bên phải, rơi xuống "phía sau" nhưng đúng chỗ.

### Bạch Chỉ Quyết và tầng 5 (ch14)
- Hồ linh nhũ là linh khí **chưa có danh** ("đồng nguyên chất chưa ai đóng ấn", Lão Chỉ); người thường chỉ dám uống một chén ở mép (Lão Thất, Tri Vi). Với Lục Trầm, linh khí tràn vào chỗ chừa giữa các nét "chờ hắn dẫn".
- Insight từ bia: không sao chép nét nào; hắn nhìn **cách khắc** và hiểu: "Mỗi nét là một lời hứa với nét kế tiếp"; nét cuối chữ trước chừa đường cho nét đầu chữ sau. Nhờ đó hiểu vì sao nét 37 từng hỏng (viết như nét riêng, không biết nối vào đâu).
- Hắn viết nét 109 trở đi, một ngày một đêm (Thanh Dao canh): tầng 2 lúc canh ba (linh khiếu cổ tay trái), tầng 3, tầng 4 rạng sáng. Nét 280 chưa hiểu mà đánh liều viết, lên **Luyện Khí tầng 5** (linh khiếu thứ năm ở đan điền) nhưng thêm **vết sẹo bạc dài bằng ngón tay như vết rạn trên sứ, sau bả vai trái**; lạnh. Thanh Dao thấy: "Lần sau đừng muốn nhanh."
- Tầng 1: vết bỏng đỏ thẫm tay phải (nét 37). Tầng 5: sẹo bạc vai trái (nét 280). Khi tu luyện ngâm hồ, hơi thở tỏa sương trắng.

### Thanh Dao nói dối lần đầu (ch14)
- Tại tầng ba chi các, **Tào Hạc Niên** hỏi: "Dị số Lục Trầm có xuất hiện trong Tàng Vân không?" Nàng đáp: **"Ta không thấy."** Cổ họng như nuốt cát. Đội Các mất ba người trong bí cảnh (trong bảy). Nàng nói thật rằng mình rời đội "lạc, nhưng đã tìm được đường".
- Bên sông Bạch Lộ, dưới gốc liễu, nàng nói với hắn: nói dối, "ta không muốn nó dễ"; "nếu ta nói thật, ngươi chết. Còn ta không muốn thế." Hắn bẻ đôi xâu mứt chia nàng (ngón tay chạm nhau, không ai rút về ngay). Lục Trầm biết chuyện nàng "ngọt hơn lần trước".
- Lệnh mới của Các: Thanh Dao đi giám sát **đại hội tuyển đồ của Vân Lam Tông, ba mươi ngày nữa, trên núi Vân Lam**; Các sẽ soi lại mệnh trang mọi người dự thi; không mệnh trang thì không có thẻ dự thi.

### Hook và tài sản
- Đa Đa: chợ đen Lạc Phong, **phố Nam**, có người "viết mệnh trang"; giá cắt cổ (Thanh Dao suýt nghẹn mứt); còn đúng một bản "hàng đặc biệt, hơi lỗi". Lão Chỉ tự ái ("chỉ bản tọa mới có tư cách viết").
- Thu hoạch: Đa Đa chín bình sứ linh nhũ pha loãng (bán gấp mười), răng nanh Huyết Nha, túi tiền của hai huynh đệ; Tri Vi cho ba giọt linh nhũ cất bình ngọc.
- Cảnh giới: Lục Trầm Luyện Khí 5; Thanh Dao Trúc Cơ hậu kỳ; Phương Luyện Khí 9 (đã mất danh); Lão Thất LK8 (tăng chút sau khi uống linh nhũ).

### Dòng thời gian (ước)
Ngày ~13 báo cáo chi các; ngày ~13–19 chờ, chuẩn bị; ngày ~20 hoàng hôn Tàng Vân mở (ch11); ngày 20 đêm–ngày 21 trong rừng đá, chiều ngày 21 gặp bia (ch12), tối ngày 21 Tâm cốc (ch13); ngày 21 đêm–22 sáng Lục Trầm ngâm hồ (ch14); ngày 22 hoặc 23 trưa ra khỏi bí cảnh; hoàng hôn cùng ngày Thanh Dao báo cáo. Đại hội Vân Lam ~30 ngày sau.

### Lưu ý liên tục
- Ch10 viết "nón lá"; ch11+ dùng "đấu lạp". Có thể sửa ch7–10 sau.
- Ch13 Phương nói "bốn danh" ban đầu đã sửa thành "ba danh tế + một người bắt sống".
- Mảnh giấy là "một góc của một trang" bị xé (gợi ý cho ch20), nhưng chưa nói rõ là trang Thiên Thư.
- Tào Hạc Niên sẽ có thể xuất hiện lại như người giám sát Thanh Dao; chưa nghi ngờ.