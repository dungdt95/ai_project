# Quy ước giọng văn: 《Thiên Thư Vô Danh》

Người đọc nhận xét bản đầu "hơi thuần Việt quá". Mục tiêu là đọc như **một bộ tiên hiệp Trung Quốc được dịch mượt**: đậm Hán-Việt nhưng vẫn trôi chảy, không phải convert thô.

Giữ nguyên: độ dài khoảng 2000 từ/chương, mức hài hiện tại (vừa phải, chủ yếu qua đối thoại). Người đọc đã xác nhận độ dài và mức hài này là ổn.

## 1. Đại từ người kể
- Người kể gọi nhân vật chính là **"hắn"**, không dùng "cậu". Ví dụ: "Lục Trầm khẽ nhíu mày. Hắn biết…"
- Nữ chính: **"nàng"**. Người già: "lão" / "lão giả". Phản diện: "hắn".
- Tiền Đa Đa: **"gã"** (để không lẫn với "hắn" của Lục Trầm). Ngô chấp sự và các nhân vật phụ nam: "y".
- Lục Trầm gọi Lão Chỉ là "ngài" (nửa kính nửa đùa); Lão Chỉ xưng "bản tọa", gọi hắn "tiểu tử". Đa Đa gọi Lục Trầm là "Lục huynh".

## 2. Xưng hô trong đối thoại
| Quan hệ | Xưng | Gọi |
|---|---|---|
| Lục Trầm ↔ lão Hoàng | Lục Trầm xưng "ta"; lão Hoàng xưng "lão tử" (khi càu nhàu) hoặc "ta" | Lục Trầm gọi "lão Hoàng", lúc trêu gọi "lão đầu"; lão Hoàng gọi "tiểu tử", "thằng nhóc" |
| Ngang hàng / người lạ | ta / ngươi; lịch sự: tại hạ / các hạ, đạo hữu, cô nương | |
| Bề dưới → bề trên | vãn bối / thuộc hạ / tiểu nhân | tiền bối, đại nhân, trưởng lão |
| Trẻ con → Lục Trầm | "đệ" | "Trầm ca" |
| Phụ nữ trung niên | "lão nương" (khi đanh đá) | người khác gọi "đại nương", "thẩm" |
| Tu sĩ cao cấp | "bổn tọa", "lão phu" | |

Tuyệt đối không dùng: con/bố/mẹ kiểu Việt (dùng "nương", "cha"), tao/mày, "em", "ông" để gọi lão Hoàng.

## 3. Từ vựng và cụm quen thuộc của thể loại
Dùng tự nhiên, không nhồi nhét: *thiếu niên, lão giả, khí tức, uy áp, sát ý, linh lực, thần thức, đan điền, kinh mạch, thần sắc, sắc mặt trắng bệch, đồng tử co rút, khóe miệng khẽ nhếch, ánh mắt lóe lên, hít sâu một hơi, trong lòng thầm nghĩ, chậm rãi nói, cười nhạt, hừ lạnh, một chén trà công phu, nửa nén hương, thì ra là thế, quả nhiên…*

Đơn vị: trượng, thước, tấc, dặm; giờ Tý, Sửu, Dần…; canh một, canh hai. Không dùng giây/phút/giờ đồng hồ (dùng nhịp thở, chén trà, nén hương, canh giờ).

## 4. Tránh yếu tố quá Việt
- Thành ngữ và so sánh dân gian Việt như "chân mềm như bún", "hiếm như gà đẻ trứng vàng", "tóc như tổ quạ" → thay bằng cách diễn đạt Hán-Việt hoặc trung tính.
- Đồ vật và món ăn: bánh nếp → bánh bao; lá chuối → lá sen; chõng tre → sập trúc / ghế trúc; mẹt → mâm gỗ; câu đối Tết → câu đối đầu năm.
- Tên người phụ nữ bán đậu phụ: **Vương đại nương** (mẹ của Tiểu Đậu).

## 5. Câu văn
- Có thể dùng một số cấu trúc quen thuộc của văn dịch như "…mà nói", "lập tức", "chỉ thấy…", "nhưng mà…", "lại nói…", nhưng không lạm dụng.
- Đoạn miêu tả có thể dùng câu bốn chữ kiểu Hán-Việt ở chỗ hợp: "mưa gió tiêu điều", "sát khí ngập trời".
- Đối thoại vẫn ngắn gọn, sắc. Lục Trầm vẫn mặt lạnh, nói câu đâm chọt.
- Lời thoại mở đầu bằng "— ".
