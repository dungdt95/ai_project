# 《THIÊN THƯ VÔ DANH》
### Đại cương Quyển 1: *Trang Giấy Trắng* (30 chương)

---

## I. THẾ GIỚI

**Cửu Châu Đại Lục**: chín châu, linh khí dồi dào. Người tu tiên nhiều như cá dưới sông, phàm nhân còn nhiều hơn.

**Thiên Thư**: cuốn sách của Thiên Đạo, ghi tên mọi sinh linh từ lúc chào đời: căn cốt, thọ nguyên, các kiếp nạn lớn. Không ai thấy được bản gốc. Thế gian chỉ có những **"Mệnh Giám"**, tức gương soi mệnh, dùng để đọc trang Thiên Thư của một người.

**Thiên Thư Các**: tổ chức đứng trên mọi tông môn, nắm giữ và phân phát Mệnh Giám. Ai được đi tu tiên, ai phải ở lại làm ruộng đều do một tờ "mệnh trang" quyết định. Thuộc hạ của họ gọi là **Chấp Bút Sứ**, chuyên truy sát "dị số", tức những kẻ không nằm trong Thiên Thư.

**Cảnh giới:** Luyện Khí (1–9 tầng) → Trúc Cơ → Kim Đan → Nguyên Anh → Hóa Thần → Luyện Hư → Hợp Thể → Đại Thừa → Độ Kiếp.
*Quyển 1: nam chính đi từ phàm nhân đến **Trúc Cơ**.*

**Luật ngầm của thế giới:** Thiên kiếp, nhân quả, chú thuật khóa mệnh đều vận hành dựa trên Thiên Thư. Kẻ không có tên thì những thứ đó **không nhắm trúng được**. Đó vừa là lợi thế, vừa là lời nguyền: ai cũng có thể giết dị số mà không phải gánh nhân quả.

---

## II. NHÂN VẬT

**Lục Trầm** (nam chính, 15 tuổi)
- Thiếu niên ở trấn Thanh Thạch. Mồ côi, được lão Hoàng chủ quán rượu nuôi lớn.
- Tính cách: điềm tĩnh, lắm mưu, mồm hơi độc, nhìn thì lười nhưng tính trước ba bước. Hài hước kiểu mặt lạnh nói câu đâm chọt.
- Con đường tu luyện: **《Bạch Chỉ Quyết》**. Hắn không hấp thu linh khí "theo sổ sách" của Thiên Đạo mà tự "viết" con đường của mình lên thân thể. Tu chậm hơn người thường ở giai đoạn đầu, nhưng không có bình cảnh định sẵn.

**Thẩm Thanh Dao** (nữ chính, 17 tuổi)
- Thiên tài kiếm tu của Thiên Thư Các, được cử đi tìm dị số.
- Mệnh trang của nàng ghi rõ: **"Tuổi hai mươi, chết dưới kiếm."** Nàng biết điều đó từ năm 8 tuổi.
- Bề ngoài lạnh như băng, bên trong là người **mù đường nặng**, không biết nấu ăn, và hay nói thật một cách phũ phàng.
- Nàng phát hiện ra khi ở gần Lục Trầm, dòng chữ về cái chết của mình **bị nhòe đi**.

**Lão Chỉ** (linh hồn khí, nguồn hài hước chính)
- Linh thức sống trong một mảnh giấy rách mà lão Hoàng để lại cho Lục Trầm.
- Tự xưng "đệ nhất cao nhân vạn cổ", nhưng mất trí nhớ, nhát gan, thích khoe khoang, mỗi lần nhớ ra được một chuyện lại là một chuyện kinh thiên động địa.

**Tiền Đa Đa** (bạn đồng hành)
- Con trai mập của một thương nhân. Mệnh trang ghi "đại phú đại quý, thọ tám mươi", nên gã… tự tin vô hạn, lao vào chỗ nguy hiểm vì tin mình không thể chết.
- Tham tiền, nhát nhưng trọng nghĩa.

**Lão Hoàng**: người nuôi Lục Trầm, ông chủ quán rượu say xỉn. Thực chất là một cao nhân bí ẩn, bị Hàn Mặc gọi là "Đao Quỷ". Biến mất ở Chương 3.

**Hàn Mặc**: Chấp Bút Sứ, phản diện chính của Quyển 1. Lịch thiệp, tàn nhẫn, tin tuyệt đối rằng "trật tự của Thiên Thư là lòng từ bi lớn nhất".

**Tạ Thiên Hành**: thiên tài của Vân Lam Tông, đối thủ của Lục Trầm ở phần đại hội. Kiêu ngạo nhưng không phải kẻ xấu.

---

## III. CỐT TRUYỆN QUYỂN 1

### Hồi 1: Kẻ Không Tên (Chương 1–6) — ĐÃ VIẾT
1. **Mệnh Giám không sáng**: Thiên Thư Các mở khảo hạch ở trấn Thanh Thạch. Đến lượt Lục Trầm, Mệnh Giám… trắng tinh. Cả trấn náo loạn; người kiểm tra tưởng gương hỏng và đập thử ba lần.
2. **Tiếng chuông trong đêm**: Tin dị số lan ra. Hàng xóm bắt đầu nhìn hắn bằng ánh mắt khác. Lão Hoàng vẫn say, nhưng đêm đó lão mài một thanh đao cũ.
3. **Chấp Bút Sứ**: Hàn Mặc đến. Lão Hoàng lộ ra thực lực kinh người, chặn hắn lại, nhét vào tay Lục Trầm một mảnh giấy rách rồi bảo hắn chạy. Lão Hoàng mất tích.
4. **Mảnh giấy biết nói**: Trốn trong núi, Lục Trầm gặp Lão Chỉ thức tỉnh. Lão vừa tỉnh đã đòi hắn dập đầu bái sư.
5. **Bạch Chỉ Quyết**: Lục Trầm bắt đầu tu luyện lần đầu, đau như bị viết chữ lên xương. Hắn đạt Luyện Khí tầng 1.
6. **Tên mập không sợ chết**: Gặp Tiền Đa Đa bị sơn tặc bắt, Lục Trầm dùng mưu cứu ra. Hai người thành bạn đồng hành, chủ yếu vì Đa Đa có tiền.

### Hồi 2: Người Đã Biết Ngày Chết (Chương 7–14) — ĐÃ VIẾT (chi tiết thực tế xem notes/ghi_chu_lien_tuc.md; nơi nào khác đại cương thì theo ghi chú)
7. **Thiếu nữ lạc đường**: Thẩm Thanh Dao truy dấu dị số… nhưng đi lạc ba ngày, tình cờ ngồi chung bàn với Lục Trầm ở quán trọ mà không nhận ra hắn.
8. **Kiếm chỉ yết hầu**: Nàng nhận ra, một kiếm kề cổ. Lục Trầm thương lượng bằng một câu khiến nàng do dự: *"Cô nương có muốn biết, vì sao kiếm của cô nương không giết được ta không?"*
9. **Dòng chữ bị nhòe**: Thanh Dao soi mệnh trang của mình và thấy chữ "chết" mờ đi khi đứng gần hắn. Hai bên thỏa thuận tạm thời.
10. **Thành Lạc Phong**: Cả nhóm vào thành. Đa Đa kinh doanh, Lão Chỉ khoe khoang, Thanh Dao đi lạc trong chợ.
11. **Bí cảnh Tàng Vân**: Một bí cảnh cổ mở ra ngoài thành, các tu sĩ tranh đoạt.
12. **Bia đá không chữ**: Trong bí cảnh có một tấm bia khắc tên những kẻ dị số từ vạn năm trước. Lục Trầm phát hiện mình **không phải người đầu tiên**.
13. **Phản bội trong bí cảnh**: Đồng đội tạm thời hãm hại cả nhóm. Lục Trầm lợi dụng việc mình "vô hình với nhân quả" để lật ngược thế cờ.
14. **Luyện Khí tầng 5**: Ra khỏi bí cảnh. Thanh Dao báo cáo giả về cho Thiên Thư Các, lần đầu tiên nàng nói dối.

### Hồi 3: Tên Giả, Kiếm Thật (Chương 15–22)
15. **Vân Lam Tông tuyển đồ**: Để có tài nguyên tu luyện, Lục Trầm quyết định trà trộn vào đại hội tuyển đệ tử bằng **mệnh trang giả** do Đa Đa mua chợ đen (giá cắt cổ).
16. **Mệnh trang của một con lừa**: Hóa ra mệnh trang giả bị in nhầm, ghi hắn là một "linh thú hệ lừa". Khủng hoảng nhân thân.
17. **Vòng một**: Lục Trầm vượt qua bằng mưu mẹo thay vì sức mạnh, làm giám khảo tức điên nhưng không bắt lỗi được.
18. **Tạ Thiên Hành**: Đụng độ thiên tài số một. Hai người bắt đầu thành kình địch.
19. **Đêm dưới trăng**: Thanh Dao kể cho hắn nghe về dòng chữ ám ảnh nàng từ năm 8 tuổi. Lục Trầm không an ủi, chỉ nói: *"Vậy thì để ta xé nó đi."*
20. **Lão Chỉ nhớ ra một chuyện**: Mảnh giấy rách chính là **một trang bị xé khỏi Thiên Thư bản gốc**.
21. **Chung kết**: Lục Trầm đấu với Tạ Thiên Hành và thắng sát nút. Thân phận bị nghi ngờ.
22. **Mệnh Giám thứ hai**: Trưởng lão muốn soi lại mệnh trang của nhà vô địch. Thời gian sắp hết.

### Hồi 4: Đêm Không Có Thiên Kiếp (Chương 23–30)
23. **Bại lộ**: Hàn Mặc xuất hiện giữa lễ bái sư. Thân phận dị số bị phơi bày trước cả tông môn.
24. **Thanh Dao chọn phe**: Nàng rút kiếm, đứng về phía Lục Trầm, chính thức phản bội Thiên Thư Các.
25. **Chạy trốn**: Tạ Thiên Hành bất ngờ ngấm ngầm giúp đỡ. Đa Đa đốt tiền (theo nghĩa đen) để mở đường.
26. **Hắc Nhai**: Bị dồn vào vực. Lục Trầm buộc phải đột phá Trúc Cơ ngay giữa vòng vây.
27. **Đột phá không có sấm sét**: Trời không giáng kiếp vì Thiên Đạo không nhìn thấy hắn. Nhưng thứ đến thay thiên kiếp còn đáng sợ hơn.
28. **Viết lên người khác**: Lần đầu tiên Lục Trầm dùng Bạch Chỉ Quyết "viết" lên mệnh trang của Hàn Mặc, xóa đi một dòng. Cái giá là nửa năm thọ nguyên.
29. **Hàn Mặc bại**: Trước khi rút đi, hắn để lại một câu: *"Ngươi nghĩ ai đã xé trang giấy đó? Chính là ngươi."*
30. **Trang giấy trắng**: Kết quyển. Lão Hoàng để lại manh mối dẫn đến Trung Châu. Thanh Dao soi mệnh trang, chỗ ghi ngày chết của nàng giờ là **một khoảng trắng**. Cả nhóm lên đường.

---

## IV. CÁC BÍ ẨN SẼ GIỮ CHO QUYỂN 2 TRỞ ĐI
- "Chính là ngươi" nghĩa là gì? Lục Trầm có phải chuyển thế của một người từng xé Thiên Thư không?
- Lão Hoàng ("Đao Quỷ") là ai? Còn sống không? Vì sao Hàn Mặc nói người như vậy "đã chết ba mươi năm trước"?
- Những dị số trên tấm bia vạn năm trước đã đi đâu?
- Ba chữ "Vị chung quyển" trên tay Lục Trầm do ai viết?
- Ai viết ra Thiên Thư, và Thiên Đạo có thật sự "vô tình"?

---

## V. QUY ƯỚC VIẾT
- Mỗi chương khoảng 2000 từ, lưu file `chuong_XX.md`.
- Giọng văn: xem `quy_uoc_giong_van.md`.
- Tình cảm nhẹ nhàng, phát triển chậm, không cẩu huyết.
- Mỗi chương kết bằng một móc câu nhỏ để kéo người đọc sang chương sau.
